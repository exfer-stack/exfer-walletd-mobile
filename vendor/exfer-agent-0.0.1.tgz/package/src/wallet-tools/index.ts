// First-party WALLET tools for the in-wallet agent.
//
// These are the privileged EXFER wallet operations (balances, transfers, swaps,
// HTLCs, quotes, signing) — the tools that read or move funds. On the desktop
// and mobile apps the NATIVE host runs them in Rust (`native_tools.rs`), which
// stays the source of truth for the installed product. This module is the SAME
// dispatch ported to TypeScript over the `HostBridge`, so a host WITHOUT a
// native tool runtime (the browser-real dev path, and any future thin client)
// runs byte-identical wallet logic — one mapping, not two that drift.
//
// Every entry mirrors an arm of `native_tools.rs::dispatch()` exactly: the same
// walletd method name, the same "omit unset fields" arg selection (`pick`), and
// the same defaults (htlc `output_index` 0, swap `flow` v2, wait timeouts). A
// wrong method or param name here is a silent runtime failure — the tests in
// tests/wallet-tools.test.ts lock the mapping against regressions.
//
// Consent is NOT decided here: the host's policy layer (tools/policy.ts) gates
// transfer/swap_execute/htlc_*/quote_issue/sign_message before `call` runs.

import type { AgentToolResult } from "../agent/session.ts";
import type { ToolDef } from "../types.ts";
import type { HostBridge } from "../capabilities/index.ts";
import MANIFEST from "./manifest.json" with { type: "json" };

type Args = Record<string, unknown>;

function ok(v: unknown): AgentToolResult {
  return { content: typeof v === "string" ? v : JSON.stringify(v), isError: false };
}
function fail(msg: string): AgentToolResult {
  return { content: msg, isError: true };
}

/** Copy the listed keys (present and non-null) into a fresh object — the
 *  "omit unset fields" rule so walletd's `Option<T>` sees absent, not null.
 *  Mirrors `native_tools.rs::pick`. */
function pick(args: Args, keys: string[]): Args {
  const out: Args = {};
  for (const k of keys) {
    const v = args[k];
    if (v !== undefined && v !== null) out[k] = v;
  }
  return out;
}

/** Ensure `key` is present, defaulting to `def`. Mirrors `with_default_u64`. */
function withDefault(p: Args, key: string, def: number): void {
  if (typeof p[key] !== "number") p[key] = def;
}

/** {from_address,to_address,amount,fee?,datum?} → walletd `transfer` params
 *  {from, outputs:[{to,amount}], fee?, datum?}. Mirrors `transfer_params`. */
function transferParams(args: Args): Args {
  const from = args.from_address;
  const to = args.to_address;
  const amount = args.amount;
  if (typeof from !== "string" || !from) throw new Error("missing required arg `from_address`");
  if (typeof to !== "string" || !to) throw new Error("missing required arg `to_address`");
  if (amount === undefined || amount === null) throw new Error("missing required arg `amount`");
  const p: Args = { from, outputs: [{ to, amount }] };
  if (args.fee !== undefined && args.fee !== null) p.fee = args.fee;
  if (args.datum !== undefined && args.datum !== null) p.datum = args.datum;
  return p;
}

// ── the dispatch table (exact 1:1 with native_tools.rs) ──────────────────────

/** No-param reads → rpc(method, {}). */
const NOARG: Record<string, string> = {
  exfer_list_addresses: "list_addresses",
  exfer_get_block_height: "get_block_height",
  exfer_bsc_get_address: "bsc_get_address",
  exfer_bsc_get_balance: "bsc_get_balances", // name remap (native does this)
  exfer_swap_pool_info: "swap_pool_info",
  exfer_swap_list: "swap_list",
  exfer_generate_address: "generate_address",
};

/** Reads/writes that just forward a fixed subset of args → rpc(method, pick). */
const PICK: Record<string, { method: string; keys: string[] }> = {
  exfer_get_balance: { method: "get_balance", keys: ["address"] },
  exfer_quote_verify: { method: "quote_verify", keys: ["quote"] },
  exfer_verify_message: {
    method: "verify_message",
    keys: ["pubkey", "signature", "message", "address"],
  },
  exfer_sign_message: { method: "sign_message", keys: ["address", "message"] },
  exfer_payment_uri_encode: {
    method: "payment_uri_encode",
    keys: ["address", "amount", "memo", "label"],
  },
  exfer_payment_uri_decode: { method: "payment_uri_decode", keys: ["uri"] },
  exfer_quote_issue: {
    method: "quote_issue",
    keys: [
      "address",
      "payee_pubkey",
      "currency",
      "amount_minor",
      "rate_exfers_per_unit",
      "exfer_amount",
      "ttl_secs",
      "payer_pubkey",
      "memo",
      "quote_id",
    ],
  },
  exfer_htlc_lock: {
    method: "htlc_lock",
    keys: ["from", "receiver", "hash_lock", "timeout", "amount", "fee", "fee_rate"],
  },
  exfer_htlc_list: {
    method: "htlc_list",
    keys: ["role", "state", "since_height", "address", "limit", "cursor"],
  },
  exfer_get_address_history: {
    method: "get_address_history",
    keys: ["address", "since_height", "limit", "cursor"],
  },
  exfer_get_output_datum: { method: "get_output_datum", keys: ["tx_id", "output_index"] },
  exfer_find_settlements_by_quote_id: {
    method: "find_settlements_by_quote_id",
    keys: ["quote_id"],
  },
  exfer_swap_status: { method: "swap_status", keys: ["swap_id"] },
  exfer_swap_execute: { method: "swap_execute", keys: ["swap_id"] },
  exfer_swap_refund: { method: "swap_refund", keys: ["swap_id"] },
};

/** Arms with a transform or a default the plain table can't express. */
const CUSTOM: Record<string, (a: Args, b: HostBridge) => Promise<unknown>> = {
  exfer_simulate_transfer: (a, b) => {
    const p = transferParams(a);
    if (a.fee_rate !== undefined && a.fee_rate !== null) p.fee_rate = a.fee_rate;
    return b.rpc("simulate_transfer", p);
  },
  exfer_transfer: (a, b) => b.rpc("transfer", transferParams(a)),
  exfer_htlc_status: (a, b) => {
    const p = pick(a, ["lock_tx_id", "output_index"]);
    withDefault(p, "output_index", 0);
    return b.rpc("htlc_status", p);
  },
  exfer_htlc_claim: (a, b) => {
    const p = pick(a, ["from", "lock_tx_id", "preimage", "sender", "timeout", "output_index", "fee"]);
    withDefault(p, "output_index", 0);
    return b.rpc("htlc_claim", p);
  },
  exfer_htlc_reclaim: (a, b) => {
    const p = pick(a, ["from", "lock_tx_id", "receiver", "hash_lock", "timeout", "output_index", "fee"]);
    withDefault(p, "output_index", 0);
    return b.rpc("htlc_reclaim", p);
  },
  exfer_swap_get_quote: (a, b) => {
    const p = pick(a, ["direction", "amount_in", "from", "flow"]);
    if (typeof p.flow !== "string" || !p.flow) p.flow = "v2";
    return b.rpc("swap_get_quote", p);
  },
  exfer_wait_for_tx: (a, b) => {
    const p = pick(a, ["tx_id", "min_confirmations", "timeout_secs"]);
    withDefault(p, "min_confirmations", 1);
    withDefault(p, "timeout_secs", 60);
    return b.rpc("wait_for_tx", p);
  },
  exfer_wait_for_payment: (a, b) => {
    const p = pick(a, ["address", "min_amount", "timeout_secs"]);
    withDefault(p, "min_amount", 1);
    withDefault(p, "timeout_secs", 60);
    return b.rpc("wait_for_payment", p);
  },
  // The one tool that doesn't touch walletd: a public pool-stats GET, done
  // through the host's CORS-free HTTPS primitive (native uses public_https_client).
  exfer_earn_pool_stats: async (a, b) => {
    const address = a.address;
    if (typeof address !== "string" || !address) throw new Error("missing required arg `address`");
    const pool =
      typeof a.pool === "string" && a.pool ? (a.pool as string) : "exfer-pplns";
    const url = `https://api.ninjaraider.com/${pool}/account/${address}`;
    const r = await b.fetchText(url);
    if (r.status === 404) {
      throw new Error(
        `pool '${pool}' has no account for this address yet (start mining, then retry). pool API: ${url}`,
      );
    }
    if (r.status < 200 || r.status >= 300) {
      throw new Error(
        `pool stats API returned HTTP ${r.status} for '${pool}' — check the pool id ('exfer-pplns' or 'exfer-solo'). pool API: ${url}`,
      );
    }
    try {
      return JSON.parse(r.body);
    } catch (e) {
      throw new Error(`decoding pool stats response: ${String(e)} (pool API: ${url})`);
    }
  },
};

/** Every wallet tool this layer implements — the exact `IMPLEMENTED` set from
 *  native_tools.rs (kept in sync via tests/wallet-tools.test.ts). */
export const WALLET_NAMES: string[] = [
  ...Object.keys(NOARG),
  ...Object.keys(PICK),
  ...Object.keys(CUSTOM),
];

interface ManifestEntry {
  name: string;
  description?: string;
  inputSchema?: Record<string, unknown>;
  parameters?: Record<string, unknown>;
}

/** Build the wallet tool source over a host's `HostBridge`. Same `{defs, has,
 *  call}` contract as `capabilityTools`, so the host merges + routes them the
 *  same way. Tool DEFS come from the bundled native manifest (one source of
 *  truth for names/descriptions/schemas across native and browser). */
export function walletTools(bridge: HostBridge): {
  defs: ToolDef[];
  has(name: string): boolean;
  call(name: string, args: Args): Promise<AgentToolResult>;
} {
  const want = new Set(WALLET_NAMES);
  const defs: ToolDef[] = (MANIFEST as ManifestEntry[])
    .filter((t) => want.has(t.name))
    .map((t) => ({
      name: t.name,
      description: t.description ?? "",
      parameters: (t.inputSchema ?? t.parameters ?? { type: "object", properties: {} }) as Record<
        string,
        unknown
      >,
    }));
  return {
    defs,
    has: (name) => want.has(name),
    call: async (name, args) => {
      const a = args ?? {};
      try {
        if (NOARG[name]) return ok(await bridge.rpc(NOARG[name], {}));
        const p = PICK[name];
        if (p) return ok(await bridge.rpc(p.method, pick(a, p.keys)));
        const c = CUSTOM[name];
        if (c) return ok(await c(a, bridge));
        return fail(`unknown wallet tool: ${name}`);
      } catch (e) {
        return fail(e instanceof Error ? e.message : String(e));
      }
    },
  };
}

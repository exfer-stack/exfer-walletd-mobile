// Provider-agnostic LLM interface for the in-wallet agent harness.
//
// One small surface every provider implements (OpenAI-compatible, Anthropic,
// ...), so the agent loop is written once and users bring their own LLM.
// Tool schemas are the exfer-mcp tool shape (name + JSON-Schema params), so the
// 35 exfer tools flow through unchanged.

/** A tool the model may call. Mirrors the exfer-mcp `Tool` shape. */
export interface ToolDef {
  name: string;
  description: string;
  /** JSON Schema object for the tool's input. */
  parameters: Record<string, unknown>;
}

/** One concrete tool call the model emitted. `args` is parsed JSON. */
export interface ToolCall {
  id: string;
  name: string;
  args: Record<string, unknown>;
}

/** A conversation turn. `tool` carries a single tool result keyed by id. */
export type ChatMessage =
  | { role: "user"; content: string }
  | { role: "assistant"; content: string; toolCalls?: ToolCall[] }
  | { role: "tool"; toolCallId: string; name: string; content: string; isError?: boolean };

/**
 * Streaming events the agent loop consumes. A turn streams zero or more
 * `thinking`/`text` deltas, then zero or more complete `tool_call`s, then `done`.
 */
export type StreamEvent =
  | { type: "thinking_delta"; text: string }
  | { type: "text_delta"; text: string }
  | { type: "tool_call"; call: ToolCall }
  | { type: "done"; stopReason: "end_turn" | "tool_use" | "max_tokens" | "refusal" | "other"; usage?: Usage }
  | { type: "error"; message: string };

export interface Usage {
  inputTokens?: number;
  outputTokens?: number;
}

export interface StreamParams {
  model: string;
  /** System prompt (provider places it correctly). */
  system?: string;
  messages: ChatMessage[];
  tools?: ToolDef[];
  /** Hard ceiling on output tokens. */
  maxTokens?: number;
  /** Abort the in-flight request. */
  signal?: AbortSignal;
}

/** Every provider is just: turn params into a stream of events. */
export interface LLMProvider {
  readonly kind: ProviderKind;
  stream(params: StreamParams): AsyncIterable<StreamEvent>;
}

export type ProviderKind = "openai" | "anthropic";

/**
 * User-configured provider. `kind` selects the wire format; `baseUrl`, `apiKey`,
 * and `model` are the three fields every "bring your own LLM" UI collects.
 *
 *  - openai    → OpenAI, OpenRouter, Groq, DeepSeek, Together, Mistral, xAI,
 *                Ollama / LM Studio / vLLM, Gemini's OpenAI-compat endpoint, ...
 *  - anthropic → Claude (native Messages API)
 */
export interface ProviderConfig {
  id: string;
  label: string;
  kind: ProviderKind;
  /** e.g. https://api.openai.com/v1 , https://api.anthropic.com , http://localhost:11434/v1 */
  baseUrl: string;
  apiKey: string;
  model: string;
}

/**
 * Injectable fetch. In Tauri, pass the `@tauri-apps/plugin-http` fetch so calls
 * go through Rust and skip browser CORS (Anthropic blocks direct browser calls
 * unless `anthropic-dangerous-direct-browser-access` is set). Defaults to
 * `globalThis.fetch` for tests / web.
 */
export type FetchLike = typeof fetch;

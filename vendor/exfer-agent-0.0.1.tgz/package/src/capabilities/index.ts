// First-party capability tools for the in-wallet agent.
//
// These are Exfer's OWN capabilities (price, chain explorer, web read/search,
// time, mining) — implemented ONCE here and shared by both apps. They are NOT
// third-party marketplace tools (those are remote URLs handled by the host's
// mcp/httptool layer). Nothing new is served: everything runs on plumbing the
// app ALREADY reaches, via a small injected HostBridge:
//
//   - rpc()       → walletd JSON-RPC (loopback): chain + pool reads
//   - command()   → a native host command (Tauri invoke): get_bnb_price, mine_*
//   - fetchText() → CORS-free HTTPS through the host (Rust): read the public web
//
// So `exfer_price` reuses the pool's `swap_price_klines` + Binance BNB/USD
// (`get_bnb_price`), the explorer tools reuse walletd's node RPC, and `web_*`
// hit the public internet directly. No `tools.exfer.dev`, no serverless shim.
// The agent core stays transport-agnostic; the host supplies the 3 primitives.

import type { AgentToolResult } from "../agent/session.ts";
import type { ToolDef } from "../types.ts";

/** The 3 primitives a host provides so first-party tools can reach existing
 *  plumbing. Desktop/mobile wrap Tauri `invoke`; browser-dev wraps proxies. */
export interface HostBridge {
  /** walletd JSON-RPC (loopback), e.g. `swap_price_klines`, `get_status`. */
  rpc<T = unknown>(method: string, params?: Record<string, unknown>): Promise<T>;
  /** A native host command (Tauri), e.g. `get_bnb_price`, `mine_start`. */
  command<T = unknown>(name: string, args?: Record<string, unknown>): Promise<T>;
  /** CORS-free HTTPS through the host (Rust), for reading the public web. */
  fetchText(
    url: string,
    init?: { method?: string; body?: string; headers?: Record<string, string> },
  ): Promise<{ status: number; body: string }>;
}

/** Which web-search backend web_search should use. The HOST resolves the
 *  effective provider + key (user's own key, else a built-in default) and passes
 *  it in; exfer-agent stays keyless itself. "free" (or no key) = the keyless
 *  DuckDuckGo -> Wikipedia cascade. A paid provider that errors falls back to
 *  the free cascade so search never hard-fails. */
export interface SearchConfig {
  provider?: "tavily" | "brave" | "free";
  apiKey?: string;
}
export interface CapabilityOpts {
  search?: SearchConfig;
  /** Etherscan V2 (multichain) API key for crypto_contract_source. Optional —
   *  without it the tool reports "source unavailable" (honestly) instead of
   *  letting the model fabricate contract code. Host-resolved, like search. */
  etherscanKey?: string;
}

interface Capability {
  def: ToolDef;
  run(args: Record<string, unknown>, bridge: HostBridge, opts?: CapabilityOpts): Promise<AgentToolResult>;
}

const EXFER_UNIT = 100_000_000; // 1 EXFER = 1e8 exfers
const HALF_LIFE = 6_307_200; // blocks (~2 years at 10s) — matches the node

function ok(v: unknown): AgentToolResult {
  return { content: typeof v === "string" ? v : JSON.stringify(v), isError: false };
}
function fail(msg: string): AgentToolResult {
  return { content: msg, isError: true };
}

/** Total EXFER emitted through `height`: perpetual 1-EXFER tail + a decaying
 *  99-EXFER bonus (closed form, same curve as the desktop dashboard). */
function circulatingSupplyExfer(height: number): number {
  if (!isFinite(height) || height < 0) return 0;
  const n = height + 1;
  const r = Math.pow(2, -1 / HALF_LIFE);
  return n + 99 * ((1 - Math.pow(r, n)) / (1 - r));
}

/** Block reward at a given height: R(h) = 1 + 99·2^(−h/HALF_LIFE) EXFER — a
 *  perpetual 1-EXFER tail plus a 99-EXFER bonus that halves every HALF_LIFE
 *  blocks (~2 years). Pure emission math, independently verifiable. */
function blockRewardExfer(height: number): number {
  if (!isFinite(height) || height < 0) return 1;
  return 1 + 99 * Math.pow(2, -height / HALF_LIFE);
}

/** Parse a walletd/swap-backend `swap_pool_info` payload (shape varies across
 *  the proxy) into BNB/EXFER reserves + mid price. EXFER's CANONICAL liquidity
 *  is this native pool — CoinGecko/DexScreener don't index it, so generic tools
 *  wrongly report ~$0. Returns null if reserves aren't present/positive. */
function parsePoolInfo(raw: unknown): { bnb: number; exfer: number; midPriceBnbPerExfer: number } | null {
  const p = (raw ?? {}) as Record<string, unknown>;
  const res = ((p.reserves ?? p) ?? {}) as Record<string, unknown>;
  const bnb = cnum(res.bnb ?? res.bnb_reserve ?? res.reserve_bnb ?? res.bnbReserve);
  const exfer = cnum(res.exfer ?? res.exfer_reserve ?? res.reserve_exfer ?? res.exferReserve);
  if (!(bnb > 0) || !(exfer > 0)) return null;
  const mid = cnum(p.mid_price_bnb_per_exfer ?? p.mid_price ?? p.price);
  return { bnb, exfer, midPriceBnbPerExfer: mid > 0 ? mid : bnb / exfer };
}

function htmlToText(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, " ")
    .trim();
}

// ── price: pool klines (USD close) + Binance BNB/USD + closed-form supply ────
const price: Capability = {
  def: {
    name: "exfer_price",
    description:
      "Current EXFER market price and market cap. Returns USD per EXFER (from the swap pool's own price history), 24h change, the BNB/USD anchor, circulating supply, and market cap. Read-only, no key. Use whenever the user asks what EXFER is worth.",
    parameters: { type: "object", properties: {} },
  },
  async run(_args, bridge) {
    try {
      const kl = await bridge.rpc<{ items?: { c: number | string }[] }>("swap_price_klines", {
        interval: "1d",
        limit: 2,
      });
      const items = Array.isArray(kl?.items) ? kl.items : [];
      const usd = items.length ? Number(items[items.length - 1].c) : NaN;
      if (!isFinite(usd) || usd <= 0) {
        return fail("EXFER price is unavailable right now (the pool returned no price).");
      }
      const prev = items.length >= 2 ? Number(items[items.length - 2].c) : usd;
      const change24h = isFinite(prev) && prev > 0 ? ((usd - prev) / prev) * 100 : 0;

      let bnbUsd: number | null = null;
      try {
        const raw = await bridge.command<string>("get_bnb_price");
        const p = Number((JSON.parse(raw) as { price?: string }).price);
        bnbUsd = isFinite(p) && p > 0 ? p : null;
      } catch {
        /* best-effort anchor */
      }
      let supply: number | null = null;
      try {
        const h = await bridge.rpc<{ height?: number }>("get_block_height");
        if (typeof h?.height === "number") supply = circulatingSupplyExfer(h.height);
      } catch {
        /* best-effort */
      }
      return ok({
        usd_per_exfer: usd,
        change_24h_pct: Number(change24h.toFixed(2)),
        bnb_usd: bnbUsd,
        circulating_supply_exfer: supply != null ? Math.round(supply) : null,
        market_cap_usd: supply != null ? Math.round(supply * usd) : null,
        unit_note: "1 EXFER = 1e8 base exfers",
        _unit: EXFER_UNIT,
      });
    } catch (e) {
      return fail(`price lookup failed: ${String(e)}`);
    }
  },
};

const TARGET_BLOCK_SECS = 10; // node TARGET_BLOCK_TIME_SECS
const BLOCKS_PER_DAY = Math.round(86400 / TARGET_BLOCK_SECS); // 8640

// Audit EXFER itself with the SAME scanner honesty we point at any other token.
// Real-user dogfooding found the agent could research every OTHER coin but had
// nothing verifiable to say about its own chain — and its differentiator (native
// PoW mining / settlement) was exactly the blank. This turns EXFER's on-chain
// economics into concrete, independently-checkable numbers, and pairs them with a
// blunt statement that the MARKET side (liquidity) is thin — never a buy pitch.
const selfAudit: Capability = {
  def: {
    name: "exfer_self_audit",
    description:
      "Audit EXFER itself, held to the SAME neutral scrutiny as any other token. Returns EXFER's verifiable on-chain economics from the node — current height, block reward now (R(h)=1+99·2^(−h/half_life)), blocks/day, daily emission, approx circulating supply — plus a CPU mining-yield estimate when a network hashrate is supplied (get it from exfer_network_hashrate). It also reads EXFER's CANONICAL liquidity from its OWN native EXFER↔BNB swap pool (canonical_liquidity: real BNB/EXFER reserves + TVL) — CoinGecko/DexScreener do NOT index this pool, so generic tools wrongly report ~$0; use canonical_liquidity, not those. States plainly it's a small pool (not on major CEX/DEX) and is explicitly NOT a buy recommendation. Use when the user asks whether EXFER itself is worth mining/holding. Read-only.",
    parameters: {
      type: "object",
      properties: {
        your_hashrate_hs: { type: "number", description: "Your mining hashrate in H/s (Argon2id). Phone ≈ 10-15 H/s; a desktop CPU is higher. Default 1500." },
        network_hashrate_hs: { type: "number", description: "Current network hashrate in H/s, if known (from exfer_network_hashrate). Needed to estimate your share of emission." },
      },
    },
  },
  async run(args, bridge) {
    try {
      const h = await bridge.rpc<{ height?: number }>("get_block_height");
      const height = typeof h?.height === "number" ? h.height : null;
      if (height == null) return fail("Could not read the EXFER chain height from the node.");
      const reward = blockRewardExfer(height);
      const dailyEmission = reward * BLOCKS_PER_DAY;
      const supply = circulatingSupplyExfer(height);

      // Best-effort raw status (difficulty) for extra verifiability — the node
      // surface varies, so never block the audit on it.
      let difficulty: unknown = null;
      try {
        const st = (await bridge.rpc<Record<string, unknown>>("get_status")) ?? {};
        difficulty = st.difficulty ?? st.difficulty_target ?? null;
      } catch {
        /* best-effort */
      }

      // EXFER's CANONICAL liquidity is its OWN native EXFER<->BNB swap pool —
      // CoinGecko/DexScreener don't index it, so generic research undercounts it
      // to ~$0. Read the REAL pool depth and anchor to USD via the BNB price.
      let liquidity: CryptoJson | null = null;
      try {
        const pool = parsePoolInfo(await bridge.rpc("swap_pool_info"));
        if (pool) {
          let bnbUsd: number | null = null;
          try {
            const raw = await bridge.command<string>("get_bnb_price");
            const bp = Number((JSON.parse(raw) as { price?: string }).price);
            bnbUsd = isFinite(bp) && bp > 0 ? bp : null;
          } catch {
            /* best-effort anchor */
          }
          const priceUsd = bnbUsd != null ? pool.midPriceBnbPerExfer * bnbUsd : null;
          liquidity = {
            source: "exfer-native swap pool (EXFER<->BNB AMM)",
            bnb_reserve: Math.round(pool.bnb * 1e6) / 1e6,
            exfer_reserve: Math.round(pool.exfer),
            mid_price_bnb_per_exfer: pool.midPriceBnbPerExfer,
            price_usd_per_exfer: priceUsd != null ? Number(priceUsd.toPrecision(4)) : null,
            approx_tvl_usd: bnbUsd != null ? Math.round(pool.bnb * bnbUsd * 2) : null, // AMM TVL ≈ 2× one side
          };
        }
      } catch {
        /* best-effort */
      }

      const yourHs = args.your_hashrate_hs != null && cnum(args.your_hashrate_hs) > 0 ? cnum(args.your_hashrate_hs) : 1500;
      const netHs = args.network_hashrate_hs != null && cnum(args.network_hashrate_hs) > 0 ? cnum(args.network_hashrate_hs) : null;
      const mining = netHs
        ? {
            your_hashrate_hs: yourHs,
            network_hashrate_hs: netHs,
            your_share_pct: Math.round((yourHs / netHs) * 1e6) / 1e4,
            est_exfer_per_day: Math.round((yourHs / netHs) * dailyEmission * 100) / 100,
            note: "Estimate = your share of network hashrate × daily emission, at steady difficulty and proportional payout. Real payout varies with luck and difficulty.",
          }
        : {
            your_hashrate_hs: yourHs,
            network_hashrate_hs: null,
            est_exfer_per_day: null,
            note: `Provide network_hashrate_hs (from exfer_network_hashrate) to estimate EXFER/day. Yield = (your_hs / network_hs) × ${Math.round(dailyEmission)} EXFER/day.`,
          };

      return ok({
        asset: "EXFER",
        chain_note: "EXFER is a native Layer-1 Argon2id PoW coin (NOT an ERC-20).",
        height,
        block_reward_now_exfer: Math.round(reward * 1e6) / 1e6,
        blocks_per_day: BLOCKS_PER_DAY,
        block_time_secs: TARGET_BLOCK_SECS,
        daily_emission_exfer: Math.round(dailyEmission),
        approx_circulating_supply_exfer: Math.round(supply),
        emission_curve: "R(h) = 1 + 99·2^(−h/6,307,200) EXFER — starts near 100, halves toward a perpetual 1-EXFER tail every ~2 years. Uncapped supply, perpetual tail, no premine.",
        difficulty,
        mining_economics: mining,
        canonical_liquidity: liquidity,
        // The load-bearing honesty: report EXFER's OWN pool depth (real), and
        // explicitly reject the generic-tool "~$0" that misses the native pool.
        liquidity_reality: liquidity
          ? `EXFER's canonical liquidity is its OWN native EXFER↔BNB swap pool: ~${liquidity.bnb_reserve} BNB and ${liquidity.exfer_reserve} EXFER${liquidity.approx_tvl_usd != null ? ` (≈$${liquidity.approx_tvl_usd} total TVL)` : ""}. CoinGecko/DexScreener do NOT index this pool, so generic tools miss it and wrongly imply ~$0 — do not repeat that. It is real but SMALL: a shallow pool means a large sell moves the price hard, and EXFER is not on major CEX/DEX. This native pool is where you actually buy/sell EXFER.`
          : "EXFER's liquidity is its OWN native swap pool, which CoinGecko/DexScreener do NOT index — so a '~$0 / not listed' from generic tools is misleading, not the truth. The pool wasn't reachable this session; use exfer_swap_pool_info for its real depth before concluding anything about liquidity.",
        not_advice: "This is an honest audit, NOT a recommendation to mine, buy, or hold EXFER. Judge it on the verifiable facts above, not on hype.",
      });
    } catch (e) {
      return fail(`exfer_self_audit failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

// ── explorer: raw pass-through of walletd node RPC (no reshaping guesswork) ──
const networkStatus: Capability = {
  def: {
    name: "exfer_network_status",
    description:
      "EXFER network status from the node: chain tip height, difficulty, and chain/node info. Read-only. Use for questions about the EXFER chain itself (how many blocks, current difficulty/hashrate).",
    parameters: { type: "object", properties: {} },
  },
  async run(_a, bridge) {
    try {
      return ok(await bridge.rpc("get_status"));
    } catch (e) {
      return fail(`network status failed: ${String(e)}`);
    }
  },
};

const getBlock: Capability = {
  def: {
    name: "exfer_get_block",
    description: "Look up an EXFER block by height or by block id/hash. Read-only explorer.",
    parameters: {
      type: "object",
      properties: {
        height: { type: "number", description: "Block height." },
        id: { type: "string", description: "Block id/hash (hex)." },
      },
    },
  },
  async run(args, bridge) {
    try {
      if (typeof args.height === "number") {
        return ok(await bridge.rpc("get_block_by_height", { height: args.height }));
      }
      if (args.id) return ok(await bridge.rpc("get_block_by_id", { block_id: String(args.id) }));
      return fail("exfer_get_block needs a height or an id.");
    } catch (e) {
      return fail(`get_block failed: ${String(e)}`);
    }
  },
};

const getTransaction: Capability = {
  def: {
    name: "exfer_get_transaction",
    description:
      "Look up an EXFER transaction by tx id (searches the mempool first, then the confirmed chain). Read-only explorer.",
    parameters: {
      type: "object",
      properties: { tx_id: { type: "string", description: "Transaction id (hex)." } },
      required: ["tx_id"],
    },
  },
  async run(args, bridge) {
    try {
      return ok(await bridge.rpc("get_transaction", { tx_id: String(args.tx_id ?? args.id ?? "") }));
    } catch (e) {
      return fail(`get_transaction failed: ${String(e)}`);
    }
  },
};

// ── web: read any public page / search (keyless, host-side HTTPS) ────────────
const webFetch: Capability = {
  def: {
    name: "web_fetch",
    description:
      "Fetch a public web page or JSON API by URL and return its text (HTML stripped, truncated). Read-only, runs host-side (works on desktop and mobile, no CORS). Use to read a specific page, article, forum thread (e.g. a bitcointalk topic), or API the user references.",
    parameters: {
      type: "object",
      properties: { url: { type: "string", description: "The https URL to fetch." } },
      required: ["url"],
    },
  },
  async run(args, bridge) {
    const url = String(args.url ?? "").trim();
    if (!/^https?:\/\//i.test(url)) return fail("web_fetch needs an http(s) URL.");
    try {
      const r = await bridge.fetchText(url, { headers: { "user-agent": "Mozilla/5.0 (exfer-agent)" } });
      if (r.status >= 400) return fail(`web_fetch got HTTP ${r.status} for ${url}`);
      // Strip HTML for full documents AND fragments (e.g. a bare <table> of
      // <td>/<tr>): a doc marker in the head, or several closing tags anywhere,
      // means it's markup the user shouldn't see raw. JSON/plain text (no tag
      // soup) passes through untouched.
      const head = r.body.slice(0, 500);
      const closingTags = r.body.match(/<\/[a-z][a-z0-9]*>/gi)?.length ?? 0;
      const looksHtml = /<html|<body|<!doctype|<head/i.test(head) || closingTags >= 3;
      const text = looksHtml ? htmlToText(r.body) : r.body;
      const MAX = 12000;
      return ok({ url, status: r.status, truncated: text.length > MAX, text: text.slice(0, MAX) });
    } catch (e) {
      return fail(`web_fetch failed: ${String(e)}`);
    }
  },
};

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

/** Unwrap DuckDuckGo's `//duckduckgo.com/l/?uddg=<encoded>` redirect wrapper to
 *  the real destination, and protocol-relative `//host` to https. */
function unwrapDdgHref(href: string): string {
  const uddg = /[?&]uddg=([^&]+)/.exec(href);
  if (uddg) {
    try {
      return decodeURIComponent(uddg[1]);
    } catch {
      /* keep raw */
    }
  }
  return href.startsWith("//") ? `https:${href}` : href;
}

/** Parse DuckDuckGo's Instant Answer JSON (stable, documented, keyless). Covers
 *  entity/definition queries: an Abstract plus a flat list of RelatedTopics.
 *  Returns [] for queries with no instant answer (the caller then falls back). */
interface DdgIa {
  Heading?: string;
  AbstractText?: string;
  AbstractURL?: string;
  RelatedTopics?: unknown[];
}
function parseInstantAnswer(j: DdgIa): SearchResult[] {
  const out: SearchResult[] = [];
  if (j.AbstractText && j.AbstractURL) {
    out.push({ title: j.Heading ?? "", url: j.AbstractURL, snippet: j.AbstractText });
  }
  const walk = (arr: unknown[]): void => {
    for (const t of arr) {
      const o = t as { Topics?: unknown[]; FirstURL?: string; Text?: string };
      if (Array.isArray(o.Topics)) walk(o.Topics);
      else if (o.FirstURL) {
        out.push({ title: (o.Text ?? "").split(" - ")[0], url: o.FirstURL, snippet: o.Text ?? "" });
      }
    }
  };
  if (Array.isArray(j.RelatedTopics)) walk(j.RelatedTopics);
  return out;
}

/** Parse the `lite.duckduckgo.com/lite/` results page — a minimal HTML table
 *  designed for old browsers, far more stable than the full search page. */
function parseDdgLite(html: string): SearchResult[] {
  const out: SearchResult[] = [];
  const re = /<a[^>]+class="result-link"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html)) && out.length < 12) {
    out.push({ title: htmlToText(m[2]), url: unwrapDdgHref(m[1]), snippet: "" });
  }
  const snips: string[] = [];
  const sre = /class="result-snippet"[^>]*>([\s\S]*?)<\/td>/gi;
  let sm: RegExpExecArray | null;
  while ((sm = sre.exec(html)) && snips.length < out.length) snips.push(htmlToText(sm[1]));
  out.forEach((r, i) => {
    if (snips[i]) r.snippet = snips[i];
  });
  return out;
}

/** Parse Wikipedia's REST search (`/w/rest.php/v1/search/page`) — a reliable,
 *  keyless, structured source that is never bot-challenged. Good coverage for
 *  entity/concept queries (coins, protocols, people); not general web/news. */
interface WikiSearch {
  pages?: { title?: string; key?: string; excerpt?: string; description?: string }[];
}
function parseWikipedia(j: WikiSearch): SearchResult[] {
  return (j.pages ?? [])
    .map((p) => ({
      title: p.title ?? p.key ?? "",
      url: p.key ? `https://en.wikipedia.org/wiki/${encodeURIComponent(p.key)}` : "",
      snippet: htmlToText(p.excerpt ?? p.description ?? ""),
    }))
    .filter((r) => r.url);
}

/** Tavily — the agent-purpose-built search API; returns LLM-ready results.
 *  POST https://api.tavily.com/search with a Bearer key. */
async function tavilySearch(bridge: HostBridge, query: string, apiKey: string): Promise<SearchResult[]> {
  const r = await bfetch(bridge, "https://api.tavily.com/search", {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ query, max_results: 8, search_depth: "basic" }),
  });
  if (r.status >= 400 || !r.body.trim()) throw new Error(`tavily HTTP ${r.status}`);
  const j = JSON.parse(r.body) as { results?: { title?: string; url?: string; content?: string }[] };
  return (j.results ?? [])
    .filter((x) => x.url)
    .slice(0, 8)
    .map((x) => ({ title: String(x.title ?? x.url), url: String(x.url), snippet: String(x.content ?? "") }));
}

/** Brave Search API — an independent web index. GET with an X-Subscription-Token. */
async function braveSearch(bridge: HostBridge, query: string, apiKey: string): Promise<SearchResult[]> {
  const r = await bfetch(
    bridge,
    `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=8`,
    { headers: { accept: "application/json", "x-subscription-token": apiKey } },
  );
  if (r.status >= 400 || !r.body.trim()) throw new Error(`brave HTTP ${r.status}`);
  const j = JSON.parse(r.body) as { web?: { results?: { title?: string; url?: string; description?: string }[] } };
  return (j.web?.results ?? [])
    .filter((x) => x.url)
    .slice(0, 8)
    .map((x) => ({ title: String(x.title ?? x.url), url: String(x.url), snippet: String(x.description ?? "") }));
}

const webSearch: Capability = {
  def: {
    name: "web_search",
    description:
      "Search the public web and return the top results (title, url, snippet). Keyless, runs host-side. Use for current information: news, other coins' prices, forum posts (e.g. bitcointalk), docs. For a specific known URL, use web_fetch instead.",
    parameters: {
      type: "object",
      properties: { query: { type: "string", description: "The search query." } },
      required: ["query"],
    },
  },
  async run(args, bridge, opts) {
    const q = String(args.query ?? "").trim();
    if (!q) return fail("web_search needs a query.");
    const enc = encodeURIComponent(q);

    // Preferred: a configured search API. The host resolves the effective
    // provider + key (the user's own key, else a built-in default). On ANY
    // error we fall through to the free cascade below, so search never
    // hard-fails and a bad/expired key degrades gracefully.
    const sc = opts?.search;
    if (sc?.apiKey && (sc.provider === "tavily" || sc.provider === "brave")) {
      try {
        const results =
          sc.provider === "tavily"
            ? await tavilySearch(bridge, q, sc.apiKey)
            : await braveSearch(bridge, q, sc.apiKey);
        if (results.length) return ok({ query: q, source: sc.provider, results });
      } catch {
        /* fall through to the keyless cascade */
      }
    }

    // Keyless fallback: run all sources CONCURRENTLY and take the first with
    // results. On a blocked/slow network this fails in ~8s instead of stacking
    // three 15s timeouts (~45s hang). A configured key above is tried first.
    const hit = await firstResults(
      [
        async () => {
          const ia = await bfetch(
            bridge,
            `https://api.duckduckgo.com/?q=${enc}&format=json&no_html=1&no_redirect=1&t=exfer-agent`,
            { headers: { "user-agent": "Mozilla/5.0 (exfer-agent)" } },
            8000,
          );
          if (ia.status < 400 && ia.body.trim()) {
            const results = parseInstantAnswer(JSON.parse(ia.body) as DdgIa).slice(0, 8);
            if (results.length) return { source: "duckduckgo-instant-answer", results };
          }
          return null;
        },
        async () => {
          const r = await bfetch(bridge, `https://lite.duckduckgo.com/lite/?q=${enc}`, { headers: { "user-agent": "Mozilla/5.0 (exfer-agent)" } }, 8000);
          if (r.status < 400) {
            const results = parseDdgLite(r.body).slice(0, 8);
            if (results.length) return { source: "duckduckgo-lite", results };
          }
          return null;
        },
        async () => {
          const w = await bfetch(
            bridge,
            `https://en.wikipedia.org/w/rest.php/v1/search/page?q=${enc}&limit=8`,
            { headers: { "user-agent": "exfer-agent/0.1 (in-wallet assistant; https://exfer.dev)" } },
            8000,
          );
          if (w.status < 400) {
            const results = parseWikipedia(JSON.parse(w.body) as WikiSearch).slice(0, 8);
            if (results.length) return { source: "wikipedia", results };
          }
          return null;
        },
      ],
      8500,
    );
    if (hit) return ok({ query: q, source: hit.source, results: hit.results });
    return ok({
      query: q,
      results: [],
      note: "No results from keyless sources right now — they may be slow or blocked on this network. Set a search key in Settings for reliable results, or use web_fetch on a specific URL.",
    });
  },
};

const time: Capability = {
  def: {
    name: "time",
    description: "The current date and time (device clock: UTC + local + unix seconds). Read-only.",
    parameters: { type: "object", properties: {} },
  },
  async run() {
    const now = new Date();
    return ok({
      iso_utc: now.toISOString(),
      unix_seconds: Math.floor(now.getTime() / 1000),
      local: now.toString(),
    });
  },
};

// ── mining: native in-app miner (migrated here from each app's agentHost) ────
function miner(name: string, cmd: string, description: string, params: Record<string, unknown>): Capability {
  return {
    def: { name, description, parameters: params },
    async run(args, bridge) {
      try {
        return ok(await bridge.command(cmd, args));
      } catch (e) {
        return fail(`miner error: ${String(e)}`);
      }
    },
  };
}

const mineStart = miner(
  "exfer_mine_start",
  "mine_start",
  "Start mining EXFER on this device's CPU, paying out to your address. Defaults to the SOLO pool (full block reward to you; no shared-pool threshold). Uses CPU. Generate an address first with exfer_generate_address.",
  {
    type: "object",
    properties: {
      address: { type: "string", description: "Your 64-hex payout address." },
      pool: { type: "string", description: "Optional stratum pool URL (ssl://host:port). Default: the solo pool." },
      threads: { type: "number", description: "CPU threads (1-4). Default 1 — Argon2id is memory-hard." },
    },
    required: ["address"],
  },
);
const mineStop = miner("exfer_mine_stop", "mine_stop", "Stop the in-app miner.", {
  type: "object",
  properties: {},
});
const mineStatus = miner(
  "exfer_mine_status",
  "mine_status",
  "Current in-app miner status: running, hashrate, shares accepted/rejected, pool authorization, uptime.",
  { type: "object", properties: {} },
);

// ── crypto discovery: multichain gem-finder capabilities (keyless) ───────────
// Backed by free public APIs the host reaches CORS-free: GeckoTerminal (new /
// trending pools, token overview, search — multichain) and GoPlus (token
// security / honeypot). BSC by default. Gives the agent GMGN-style discovery it
// can REASON over + fuse, rather than a dashboard. All read-only, no key.

type CryptoJson = Record<string, unknown>;

function cnum(v: unknown): number {
  const n = Number(v);
  return isFinite(n) ? n : 0;
}
function isYes(v: unknown): boolean {
  return String(v ?? "") === "1";
}
/** Reject after `ms` so a slow/blocked upstream fails fast instead of stacking
 *  the host's 15s-per-request budget into a long UI hang. */
function raceTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout>;
  const timeout = new Promise<T>((_, reject) => {
    timer = setTimeout(() => reject(new Error(`timeout ${ms}ms`)), ms);
  });
  return Promise.race([p, timeout]).finally(() => clearTimeout(timer));
}
/** fetchText with a hard client-side timeout, for discovery/search upstreams. */
function bfetch(
  bridge: HostBridge,
  url: string,
  init?: { method?: string; body?: string; headers?: Record<string, string> },
  ms = 9000,
): Promise<{ status: number; body: string }> {
  return raceTimeout(bridge.fetchText(url, init), ms);
}
const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms));
/** Run search tasks CONCURRENTLY; resolve with the first that yields results
 *  (else null when all fail or `ms` elapses). Turns a sequential blocked-source
 *  cascade (~45s of stacked timeouts) into one ~ms wait. */
function firstResults(
  tasks: Array<() => Promise<{ source: string; results: SearchResult[] } | null>>,
  ms: number,
): Promise<{ source: string; results: SearchResult[] } | null> {
  return new Promise((resolve) => {
    let pending = tasks.length;
    let done = false;
    const finish = (v: { source: string; results: SearchResult[] } | null) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      resolve(v);
    };
    const timer = setTimeout(() => finish(null), ms);
    for (const t of tasks) {
      t()
        .then((r) => {
          if (r && r.results.length) finish(r);
          else if (--pending === 0) finish(null);
        })
        .catch(() => {
          if (--pending === 0) finish(null);
        });
    }
  });
}
/** Top-10 holder concentration (%) from a GoPlus `holders` array (fractions). */
function top10Concentration(t: CryptoJson): number {
  const h = Array.isArray(t.holders) ? (t.holders as CryptoJson[]) : [];
  return Math.round(h.slice(0, 10).reduce((s, x) => s + cnum(x.percent), 0) * 10000) / 100;
}

/** Chain alias -> GeckoTerminal network id (default bsc). */
function gtNet(chain?: unknown): string {
  const c = String(chain ?? "bsc").toLowerCase().trim();
  const m: Record<string, string> = {
    bsc: "bsc", bnb: "bsc", binance: "bsc",
    eth: "eth", ethereum: "eth", ether: "eth",
    base: "base",
    sol: "solana", solana: "solana",
    arb: "arbitrum", arbitrum: "arbitrum",
    polygon: "polygon_pos", matic: "polygon_pos",
    avax: "avax", avalanche: "avax",
  };
  return m[c] ?? c;
}

/** Chain alias -> GoPlus chain id (EVM only; "" when unsupported, e.g. solana). */
function goplusChain(chain?: unknown): string {
  const c = String(chain ?? "bsc").toLowerCase().trim();
  const m: Record<string, string> = {
    bsc: "56", bnb: "56", binance: "56", eth: "1", ethereum: "1",
    base: "8453", arb: "42161", arbitrum: "42161",
    polygon: "137", matic: "137", avax: "43114", avalanche: "43114",
  };
  return m[c] ?? "";
}

/** Flatten a GeckoTerminal pool object into a compact summary. */
function poolSummary(p: CryptoJson): CryptoJson {
  const a = (p.attributes ?? {}) as CryptoJson;
  const rel = (p.relationships ?? {}) as CryptoJson;
  const baseId = String((((rel.base_token as CryptoJson)?.data as CryptoJson)?.id) ?? "");
  const tokenAddr = baseId.includes("_") ? baseId.slice(baseId.indexOf("_") + 1) : baseId;
  const vol = (a.volume_usd ?? {}) as CryptoJson;
  const chg = (a.price_change_percentage ?? {}) as CryptoJson;
  const tx = ((a.transactions ?? {}) as CryptoJson).h24 as CryptoJson | undefined;
  const created = String(a.pool_created_at ?? "");
  const ageMin = created ? Math.max(0, Math.round((Date.now() - new Date(created).getTime()) / 60000)) : null;
  return {
    name: a.name,
    token_address: tokenAddr,
    pool_address: a.address,
    price_usd: cnum(a.base_token_price_usd),
    fdv_usd: cnum(a.fdv_usd),
    market_cap_usd: a.market_cap_usd != null ? cnum(a.market_cap_usd) : null,
    liquidity_usd: cnum(a.reserve_in_usd),
    volume_1h: cnum(vol.h1),
    volume_24h: cnum(vol.h24),
    change_1h: cnum(chg.h1),
    change_24h: cnum(chg.h24),
    buys_24h: tx ? cnum(tx.buys) : null,
    sells_24h: tx ? cnum(tx.sells) : null,
    buyers_24h: tx ? cnum(tx.buyers) : null,
    sellers_24h: tx ? cnum(tx.sellers) : null,
    age_minutes: ageMin,
    created_at: created || null,
  };
}

// GeckoTerminal is the only keyless source for chain-wide new/trending pools and
// per-pool trades, and it rate-limits + intermittently resets datacenter
// connections. Retry with backoff so a transient block/429 doesn't kill the call.
async function gtRaw(bridge: HostBridge, url: string): Promise<CryptoJson> {
  let lastErr: unknown;
  for (let attempt = 0; attempt < 3; attempt++) {
    if (attempt > 0) await sleep(300 * attempt);
    try {
      const r = await bfetch(bridge, url, { headers: { accept: "application/json" } });
      if (r.status >= 400 || !r.body.trim()) throw new Error(`GeckoTerminal HTTP ${r.status}`);
      return JSON.parse(r.body) as CryptoJson;
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error(String(lastErr));
}

async function gtPools(bridge: HostBridge, path: string): Promise<CryptoJson[]> {
  const j = await gtRaw(bridge, `https://api.geckoterminal.com/api/v2/${path}`);
  return Array.isArray(j.data) ? (j.data as CryptoJson[]) : [];
}

/** Plain keyless JSON GET (CoinGecko / alternative.me for market data). */
async function jsonGet(bridge: HostBridge, url: string): Promise<CryptoJson> {
  const r = await bfetch(bridge, url, { headers: { accept: "application/json" } });
  if (r.status >= 400 || !r.body.trim()) throw new Error(`HTTP ${r.status}`);
  return JSON.parse(r.body) as CryptoJson;
}

async function goplusSecurity(bridge: HostBridge, chainId: string, address: string): Promise<CryptoJson | null> {
  const r = await bfetch(
    bridge,
    `https://api.gopluslabs.io/api/v1/token_security/${chainId}?contract_addresses=${address}`,
    { headers: { accept: "application/json" } },
  );
  if (r.status >= 400 || !r.body.trim()) throw new Error(`GoPlus HTTP ${r.status}`);
  const j = JSON.parse(r.body) as { result?: Record<string, CryptoJson> };
  const res = j.result ?? {};
  const lc = address.toLowerCase();
  const key = Object.keys(res).find((k) => k.toLowerCase() === lc) ?? Object.keys(res)[0];
  return key ? res[key] : null;
}

// ── DexScreener: a keyless, high-availability SECOND source for the discovery
//    tools. GeckoTerminal rate-limits hard (and intermittently blocks datacenter
//    IPs), and it was the ONLY source — one GT hiccup took the whole "go find
//    gems" engine dark. DexScreener covers the same chains, needs no key, and
//    batches token lookups (≤30 addresses/call). GT stays primary (richer new-
//    pool feed); DexScreener is the fallback so discovery degrades instead of
//    dying. Every tool that can fall over tags its output with `source_api`. ──

/** Chain alias -> DexScreener chain slug (default bsc). */
function dsChain(chain?: unknown): string {
  const c = String(chain ?? "bsc").toLowerCase().trim();
  const m: Record<string, string> = {
    bsc: "bsc", bnb: "bsc", binance: "bsc",
    eth: "ethereum", ethereum: "ethereum", ether: "ethereum",
    base: "base",
    sol: "solana", solana: "solana",
    arb: "arbitrum", arbitrum: "arbitrum",
    polygon: "polygon", matic: "polygon",
    avax: "avalanche", avalanche: "avalanche",
  };
  return m[c] ?? c;
}

/** Flatten a DexScreener pair into the SAME compact summary as poolSummary, so a
 *  caller can't tell which source served it. */
function dsPairSummary(p: CryptoJson): CryptoJson {
  const base = (p.baseToken ?? {}) as CryptoJson;
  const quote = (p.quoteToken ?? {}) as CryptoJson;
  const vol = (p.volume ?? {}) as CryptoJson;
  const chg = (p.priceChange ?? {}) as CryptoJson;
  const tx24 = (((p.txns ?? {}) as CryptoJson).h24 ?? {}) as CryptoJson;
  const liq = (p.liquidity ?? {}) as CryptoJson;
  const createdMs = cnum(p.pairCreatedAt);
  const ageMin = createdMs > 0 ? Math.max(0, Math.round((Date.now() - createdMs) / 60000)) : null;
  return {
    name: base.symbol && quote.symbol ? `${String(base.symbol)} / ${String(quote.symbol)}` : (base.name ?? null),
    token_address: base.address ?? "",
    pool_address: p.pairAddress ?? null,
    price_usd: cnum(p.priceUsd),
    fdv_usd: p.fdv != null ? cnum(p.fdv) : null,
    market_cap_usd: p.marketCap != null ? cnum(p.marketCap) : null,
    liquidity_usd: cnum(liq.usd),
    volume_1h: cnum(vol.h1),
    volume_24h: cnum(vol.h24),
    change_1h: cnum(chg.h1),
    change_24h: cnum(chg.h24),
    buys_24h: tx24.buys != null ? cnum(tx24.buys) : null,
    sells_24h: tx24.sells != null ? cnum(tx24.sells) : null,
    buyers_24h: null, // DexScreener does not report unique buyers/sellers
    sellers_24h: null,
    age_minutes: ageMin,
    created_at: createdMs > 0 ? new Date(createdMs).toISOString() : null,
  };
}

async function dsFetch(bridge: HostBridge, path: string): Promise<unknown> {
  const r = await bfetch(bridge, `https://api.dexscreener.com${path}`, { headers: { accept: "application/json" } });
  if (r.status >= 400 || !r.body.trim()) throw new Error(`DexScreener HTTP ${r.status}`);
  return JSON.parse(r.body);
}

/** Deepest-liquidity pair per token address from a DexScreener pairs[] (optionally
 *  filtered to one chain slug). */
function dsBestPerToken(pairs: CryptoJson[], chainSlug?: string): CryptoJson[] {
  const byToken = new Map<string, CryptoJson>();
  for (const p of pairs) {
    if (chainSlug && String(p.chainId) !== chainSlug) continue;
    const addr = String(((p.baseToken ?? {}) as CryptoJson).address ?? "").toLowerCase();
    if (!addr) continue;
    const cur = byToken.get(addr);
    if (!cur || cnum(((p.liquidity ?? {}) as CryptoJson).usd) > cnum(((cur.liquidity ?? {}) as CryptoJson).usd)) byToken.set(addr, p);
  }
  return [...byToken.values()];
}

/** DexScreener overview for a token address: its deepest pair on the chain. */
async function dsOverview(bridge: HostBridge, chain: unknown, addr: string): Promise<CryptoJson | null> {
  const j = (await dsFetch(bridge, `/latest/dex/tokens/${addr}`)) as { pairs?: CryptoJson[] };
  const pairs = Array.isArray(j.pairs) ? j.pairs : [];
  const best = dsBestPerToken(pairs, dsChain(chain)).sort(
    (a, b) => cnum(((b.liquidity ?? {}) as CryptoJson).usd) - cnum(((a.liquidity ?? {}) as CryptoJson).usd),
  )[0];
  return best ? dsPairSummary(best) : null;
}

/** DexScreener search by name / symbol / address -> pair summaries. */
async function dsSearch(bridge: HostBridge, query: string, chain?: unknown): Promise<CryptoJson[]> {
  const j = (await dsFetch(bridge, `/latest/dex/search?q=${encodeURIComponent(query)}`)) as { pairs?: CryptoJson[] };
  const pairs = Array.isArray(j.pairs) ? j.pairs : [];
  return dsBestPerToken(pairs, chain ? dsChain(chain) : undefined).map(dsPairSummary);
}

/** DexScreener discovery fallback: latest token profiles (new) or boosts
 *  (trending), filtered to the chain and resolved to summaries in one batched
 *  tokens call (≤30 addresses). */
async function dsDiscover(bridge: HostBridge, chain: unknown, source: "new" | "trending"): Promise<CryptoJson[]> {
  const slug = dsChain(chain);
  const feed = source === "trending" ? "/token-boosts/latest/v1" : "/token-profiles/latest/v1";
  const arr = await dsFetch(bridge, feed);
  const list = Array.isArray(arr) ? (arr as CryptoJson[]) : [];
  const addrs: string[] = [];
  for (const it of list) {
    if (String(it.chainId) !== slug) continue;
    const a = String(it.tokenAddress ?? "");
    if (a && !addrs.includes(a)) addrs.push(a);
    if (addrs.length >= 30) break;
  }
  if (!addrs.length) return [];
  const j = (await dsFetch(bridge, `/latest/dex/tokens/${addrs.join(",")}`)) as { pairs?: CryptoJson[] };
  const pairs = Array.isArray(j.pairs) ? j.pairs : [];
  const summaries = dsBestPerToken(pairs, slug).map(dsPairSummary);
  if (source === "trending") summaries.sort((a, b) => cnum(b.volume_24h) - cnum(a.volume_24h));
  else summaries.sort((a, b) => (cnum(a.age_minutes) || 1e12) - (cnum(b.age_minutes) || 1e12));
  return summaries;
}

/** Discover pools with resilience: GeckoTerminal first (richer feed), DexScreener
 *  on any failure or empty result. Returns SUMMARIES (poolSummary shape) plus the
 *  source that actually served them. */
async function discoverPools(
  bridge: HostBridge,
  chain: unknown,
  source: "new" | "trending",
): Promise<{ pools: CryptoJson[]; source_api: string }> {
  try {
    const path = source === "trending" ? `networks/${gtNet(chain)}/trending_pools?page=1` : `networks/${gtNet(chain)}/new_pools?page=1`;
    const raw = await gtPools(bridge, path);
    if (raw.length) return { pools: raw.map(poolSummary), source_api: "geckoterminal" };
    throw new Error("empty");
  } catch {
    return { pools: await dsDiscover(bridge, chain, source), source_api: "dexscreener" };
  }
}

/** Turn raw GoPlus fields into a compact verdict + human-readable risk flags.
 *
 *  GoPlus returns a SPARSE (often empty) record for tokens it has not fully
 *  analyzed — which is exactly the brand-new "gem" case a rug check matters
 *  most for. The old code coerced every missing boolean to false and every
 *  missing number to 0, so the card read "0% buy tax, 0% sell tax, owner 0%,
 *  0 holders" and the model reported the token as CLEAN when the truth was
 *  UNKNOWN. That false-safe is the worst possible failure for this tool. So:
 *  absent fields stay `null` (unknown, never 0/false), a record with no core
 *  signals verdicts as "unknown" (NOT "ok"), thin coverage can't earn "ok",
 *  and only definitive positives raise a risk flag. */
function securityVerdict(t: CryptoJson): CryptoJson {
  const present = (v: unknown) => v != null && String(v).trim() !== "";
  const onP = (v: unknown): boolean | null => (present(v) ? String(v) === "1" : null);
  const numP = (v: unknown): number | null => (present(v) ? cnum(v) : null);
  const tokenName = t.token_symbol ?? t.token_name ?? null;

  // Coverage: how many core GoPlus signals actually came back. Zero => the
  // token is not indexed; do NOT dress its absent fields up as safe zeros.
  const core = [
    t.is_honeypot, t.buy_tax, t.sell_tax, t.is_open_source, t.is_mintable,
    t.owner_address, t.holder_count, t.total_supply, t.is_in_dex, t.cannot_sell_all,
  ];
  const covered = core.filter(present).length;
  if (covered === 0) {
    return {
      verdict: "unknown",
      data_coverage: "none",
      flags: [
        "GoPlus has NO security data for this token — treat as UNVERIFIED, NOT as safe. Confirm with crypto_honeypot_check (real sell simulation) and crypto_contract_source before trusting it.",
      ],
      honeypot: null,
      buy_tax_pct: null,
      sell_tax_pct: null,
      open_source: null,
      owner_renounced: null,
      owner_percent: null,
      mintable: null,
      can_take_back: null,
      hidden_owner: null,
      blacklist: null,
      transfer_pausable: null,
      holder_count: null,
      lp_holder_count: null,
      top10_concentration_pct: null,
      token: tokenName,
    };
  }

  const honeypot = onP(t.is_honeypot);
  const cannotSell = onP(t.cannot_sell_all);
  const buyTaxPct = numP(t.buy_tax) != null ? (numP(t.buy_tax) as number) * 100 : null;
  const sellTaxPct = numP(t.sell_tax) != null ? (numP(t.sell_tax) as number) * 100 : null;
  const openSource = onP(t.is_open_source);
  const mintable = onP(t.is_mintable);
  const canTakeBack = onP(t.can_take_back_ownership);
  const hiddenOwner = onP(t.hidden_owner);
  const blacklist = onP(t.is_blacklisted);
  const pausable = onP(t.transfer_pausable);
  const ownerRaw = t.owner_address;
  const owner = String(ownerRaw ?? "");
  // Only decide renounce when GoPlus actually reported an owner. An EMPTY
  // owner_address is ambiguous (unreported vs. genuinely none) => unknown.
  const renounced = present(ownerRaw) ? /^0x0+$/i.test(owner) || /0*dead$/i.test(owner) : null;
  const ownerPct = numP(t.owner_percent) != null ? (numP(t.owner_percent) as number) * 100 : null;
  const top10 = top10Concentration(t);

  const flags: string[] = [];
  if (honeypot === true) flags.push("HONEYPOT");
  if (cannotSell === true) flags.push("cannot sell all");
  if (sellTaxPct != null && sellTaxPct > 10) flags.push(`high sell tax ${sellTaxPct.toFixed(0)}%`);
  if (buyTaxPct != null && buyTaxPct > 10) flags.push(`high buy tax ${buyTaxPct.toFixed(0)}%`);
  if (openSource === false) flags.push("not open source");
  if (mintable === true) flags.push("mintable");
  if (canTakeBack === true) flags.push("owner can reclaim ownership");
  if (hiddenOwner === true) flags.push("hidden owner");
  if (blacklist === true) flags.push("has blacklist");
  if (pausable === true) flags.push("transfers pausable");
  if (renounced === false && ownerPct != null && ownerPct > 5) flags.push(`owner holds ${ownerPct.toFixed(0)}%`);
  if (top10 >= 80) flags.push(`top 10 hold ${top10.toFixed(0)}%`);

  // Thin coverage is itself a caution — some core signals are simply missing,
  // so "ok" would overclaim. Require broad coverage before ever saying "ok".
  const partial = covered < 6;
  const verdict =
    honeypot === true || cannotSell === true
      ? "danger"
      : flags.length >= 2
        ? "caution"
        : flags.length === 1
          ? "watch"
          : partial
            ? "watch"
            : "ok";
  return {
    verdict,
    data_coverage: partial ? "partial" : "full",
    flags,
    honeypot,
    buy_tax_pct: buyTaxPct != null ? Math.round(buyTaxPct * 10) / 10 : null,
    sell_tax_pct: sellTaxPct != null ? Math.round(sellTaxPct * 10) / 10 : null,
    open_source: openSource,
    owner_renounced: renounced,
    owner_percent: ownerPct != null ? Math.round(ownerPct * 10) / 10 : null,
    mintable,
    can_take_back: canTakeBack,
    hidden_owner: hiddenOwner,
    blacklist,
    transfer_pausable: pausable,
    holder_count: numP(t.holder_count),
    lp_holder_count: t.lp_holder_count != null ? cnum(t.lp_holder_count) : null,
    top10_concentration_pct: top10,
    token: tokenName,
  };
}

/** A small allowlist of well-known official contracts whose "risky-looking"
 *  privileges (mint authority, concentrated top holders) are the expected
 *  custody/bridge/stablecoin mechanism — NOT an owner rug backdoor. We LABEL
 *  these (attach context) rather than override the raw flags, so a cautious user
 *  isn't scared off a canonical asset. This never marks an UNKNOWN token safe. */
const KNOWN_CONTRACTS: Record<string, { label: string; note: string }> = {
  // BSC — Binance-Peg bridge assets + canonical DEX tokens
  "0x2170ed0880ac9a755fd29b2688956bd959f933f8": { label: "Binance-Peg Ethereum (ETH)", note: "Official Binance-Peg bridge asset — its mint authority and concentrated top holders are the bridge custody/mint-burn mechanism, not an owner rug backdoor." },
  "0x7130d2a12b9bcbfae4f2634d864a1ee1ce3ead9c": { label: "Binance-Peg BTCB", note: "Official Binance-Peg bridge asset — mint authority is the bridge mint/burn, not an owner backdoor." },
  "0x55d398326f99059ff775485246999027b3197955": { label: "Binance-Peg USDT (BSC)", note: "Canonical bridged USDT on BSC — issuer-controlled by design (a centralized stablecoin), not an anonymous project rug." },
  "0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d": { label: "Binance-Peg USDC (BSC)", note: "Canonical bridged USDC on BSC — issuer-controlled by design (a centralized stablecoin)." },
  "0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c": { label: "Wrapped BNB (WBNB)", note: "Canonical wrapped BNB — the standard gas wrapper, not a project token." },
  "0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82": { label: "PancakeSwap (CAKE)", note: "PancakeSwap governance token — 'mintable' is protocol emission (audited, well-known); top holders are typically the burn address and known contracts." },
  // Ethereum — canonical majors
  "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2": { label: "Wrapped Ether (WETH)", note: "Canonical wrapped ETH — the standard gas wrapper, not a project token." },
  "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48": { label: "USD Coin (USDC)", note: "Canonical USDC — issuer-controlled by design (a centralized stablecoin)." },
  "0xdac17f958d2ee523a2206206994597c13d831ec7": { label: "Tether (USDT)", note: "Canonical USDT — issuer-controlled by design (a centralized stablecoin)." },
  "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599": { label: "Wrapped BTC (WBTC)", note: "Canonical wrapped BTC — custodian mint/burn by design, not an anonymous rug." },
};
function knownContract(address: string): { label: string; note: string } | null {
  return KNOWN_CONTRACTS[address.toLowerCase()] ?? null;
}

const cryptoNewPools: Capability = {
  def: {
    name: "crypto_new_pools",
    description:
      "Freshly launched DEX pools (brand-new tokens) on a chain — the raw feed for finding early gems. Defaults to BSC. Returns name, token address, price, liquidity, 24h/1h volume, buys/sells, price change, and age in minutes. Read-only, keyless. Chains: bsc (default), eth, base, solana, arbitrum, polygon, avax.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "Chain, default bsc." },
        limit: { type: "number", description: "How many pools (default 10, max 20)." },
      },
    },
  },
  async run(args, bridge) {
    try {
      const limit = Math.min(20, Math.max(1, cnum(args.limit) || 10));
      const { pools, source_api } = await discoverPools(bridge, args.chain, "new");
      return ok({ chain: gtNet(args.chain), source_api, count: Math.min(limit, pools.length), pools: pools.slice(0, limit) });
    } catch (e) {
      return fail(`crypto_new_pools failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const cryptoTrending: Capability = {
  def: {
    name: "crypto_trending",
    description:
      "Trending / hottest DEX pools on a chain right now (by momentum + volume). Defaults to BSC. Same fields as crypto_new_pools. Read-only, keyless. Use for 'what's hot' vs crypto_new_pools for 'what's brand new'.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "Chain, default bsc." },
        limit: { type: "number", description: "How many (default 10, max 20)." },
      },
    },
  },
  async run(args, bridge) {
    try {
      const limit = Math.min(20, Math.max(1, cnum(args.limit) || 10));
      const { pools, source_api } = await discoverPools(bridge, args.chain, "trending");
      return ok({ chain: gtNet(args.chain), source_api, count: Math.min(limit, pools.length), pools: pools.slice(0, limit) });
    } catch (e) {
      return fail(`crypto_trending failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const cryptoSearchToken: Capability = {
  def: {
    name: "crypto_search_token",
    description:
      "Find a token / trading pool by name, symbol, or contract address, across DEXs. Returns matching pools with price, liquidity, volume, and change. Read-only, keyless. Optionally restrict to a chain.",
    parameters: {
      type: "object",
      properties: {
        query: { type: "string", description: "Name, symbol, or contract address." },
        chain: { type: "string", description: "Optional chain filter, e.g. bsc." },
      },
      required: ["query"],
    },
  },
  async run(args, bridge) {
    const q = String(args.query ?? "").trim();
    if (!q) return fail("crypto_search_token needs a query.");
    try {
      const netParam = args.chain ? `&network=${gtNet(args.chain)}` : "";
      const pools = await gtPools(bridge, `search/pools?query=${encodeURIComponent(q)}${netParam}`);
      if (pools.length) return ok({ query: q, source_api: "geckoterminal", count: Math.min(10, pools.length), results: pools.slice(0, 10).map(poolSummary) });
      throw new Error("empty");
    } catch {
      try {
        const results = (await dsSearch(bridge, q, args.chain)).slice(0, 10);
        return ok({ query: q, source_api: "dexscreener", count: results.length, results });
      } catch (e) {
        return fail(`crypto_search_token failed: ${e instanceof Error ? e.message : String(e)}`);
      }
    }
  },
};

const cryptoTokenOverview: Capability = {
  def: {
    name: "crypto_token_overview",
    description:
      "Market overview for a specific token by contract address: price, FDV, market cap, liquidity, 24h/1h volume, buys/sells, price change, and pool age. Uses the token's deepest pool. Defaults to BSC. Read-only, keyless.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "Chain, default bsc." },
        address: { type: "string", description: "Token contract address." },
      },
      required: ["address"],
    },
  },
  async run(args, bridge) {
    const addr = String(args.address ?? "").trim();
    if (!addr) return fail("crypto_token_overview needs a token address.");
    const chain = gtNet(args.chain);
    try {
      const pools = await gtPools(bridge, `networks/${chain}/tokens/${addr}/pools?page=1`);
      // Keep only pools where the QUERIED token is the base — otherwise poolSummary
      // reports the OTHER token's price/name (the USDC → "UB/USDC" → $0.088 bug).
      const mine = pools.map(poolSummary).filter((s) => String(s.token_address).toLowerCase() === addr.toLowerCase());
      if (mine.length) {
        const best = mine.sort((a, b) => cnum(b.liquidity_usd) - cnum(a.liquidity_usd))[0];
        return ok({ chain, token_address: addr, source_api: "geckoterminal", ...best });
      }
      throw new Error("no base-side pool"); // → DexScreener (base-correct) fallback
    } catch {
      try {
        const best = await dsOverview(bridge, args.chain, addr);
        if (!best) return fail(`No pool found for ${addr} on ${chain}.`);
        return ok({ chain, token_address: addr, source_api: "dexscreener", ...best });
      } catch (e) {
        return fail(`crypto_token_overview failed: ${e instanceof Error ? e.message : String(e)}`);
      }
    }
  },
};

const cryptoTokenSecurity: Capability = {
  def: {
    name: "crypto_token_security",
    description:
      "Safety / rug check for a token contract (GoPlus): honeypot, buy/sell tax, mintable, open-source, owner renounced, owner %, hidden owner, blacklist, pausable transfers, LP/holder counts — with an overall verdict (ok / watch / caution / danger / unknown) and plain risk flags. Missing fields come back as null (unknown), never as safe zeros, and an unindexed token returns verdict 'unknown' with data_coverage 'none' — that means UNVERIFIED, NOT safe; confirm with crypto_honeypot_check + crypto_contract_source. For well-known official contracts (bridge assets, canonical stablecoins/wrappers) a known_contract {label, note} is attached — use it to CONTEXTUALIZE the raw flags (e.g. a bridge's mint authority is the mechanism, not a rug) instead of scaring the user off a canonical asset. ALWAYS run this before treating a token as a gem. Defaults to BSC. EVM chains only. Read-only, keyless.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "EVM chain, default bsc." },
        address: { type: "string", description: "Token contract address." },
      },
      required: ["address"],
    },
  },
  async run(args, bridge) {
    const addr = String(args.address ?? "").trim();
    if (!addr) return fail("crypto_token_security needs a token address.");
    const cid = goplusChain(args.chain);
    if (!cid) return fail(`Security checks cover EVM chains (bsc/eth/base/…). '${String(args.chain)}' is not supported by GoPlus.`);
    try {
      const t = await goplusSecurity(bridge, cid, addr);
      if (!t) return fail(`No security data for ${addr} (not indexed yet).`);
      // Context (not an override): if this is a known official contract, attach a
      // label so the model doesn't scare the user off a canonical asset whose
      // "risky" privileges are the bridge/stablecoin mechanism. Raw flags stand.
      const known = knownContract(addr);
      return ok({ chain: gtNet(args.chain), token_address: addr, ...(known ? { known_contract: known } : {}), ...securityVerdict(t) });
    } catch (e) {
      return fail(`crypto_token_security failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const cryptoTokenHolders: Capability = {
  def: {
    name: "crypto_token_holders",
    description:
      "Holder structure / concentration risk for a token (GoPlus): total holders, LP holder count, top-10 concentration %, and the top holders with their %, whether locked, and whether a contract. High top-holder concentration = dump / rug risk. Defaults to BSC. EVM only. Read-only, keyless.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "EVM chain, default bsc." },
        address: { type: "string", description: "Token contract address." },
      },
      required: ["address"],
    },
  },
  async run(args, bridge) {
    const addr = String(args.address ?? "").trim();
    if (!addr) return fail("crypto_token_holders needs a token address.");
    const cid = goplusChain(args.chain);
    if (!cid) return fail(`Holder data covers EVM chains (bsc/eth/base/…). '${String(args.chain)}' is not supported.`);
    try {
      const t = await goplusSecurity(bridge, cid, addr);
      if (!t) return fail(`No holder data for ${addr} (not indexed yet).`);
      const holders = Array.isArray(t.holders) ? (t.holders as CryptoJson[]) : [];
      const top = holders.slice(0, 10).map((h) => ({
        address: h.address,
        percent: Math.round(cnum(h.percent) * 10000) / 100,
        tag: h.tag || null,
        is_locked: isYes(h.is_locked),
        is_contract: isYes(h.is_contract),
      }));
      return ok({
        chain: gtNet(args.chain),
        token_address: addr,
        holder_count: cnum(t.holder_count),
        lp_holder_count: t.lp_holder_count != null ? cnum(t.lp_holder_count) : null,
        top10_concentration_pct: top10Concentration(t),
        top_holders: top,
      });
    } catch (e) {
      return fail(`crypto_token_holders failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const cryptoTokenTrades: Capability = {
  def: {
    name: "crypto_token_trades",
    description:
      "Recent trade flow for a token (money-flow / whale signal): from the token's deepest pool's latest ~300 DEX trades — buy vs sell USD volume, net flow, unique buyers/sellers, and the biggest recent buys/sells with wallet + time. A keyless proxy for 'who's buying / is money flowing in'. If GeckoTerminal is rate-limited it falls back to DexScreener's coarser AGGREGATE 24h flow (buy/sell counts + volume, marked degraded:true, source_api:'dexscreener') with no per-wallet detail — so check source_api. Defaults to BSC. Read-only, keyless.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "Chain, default bsc." },
        address: { type: "string", description: "Token contract address." },
      },
      required: ["address"],
    },
  },
  async run(args, bridge) {
    const addr = String(args.address ?? "").trim();
    if (!addr) return fail("crypto_token_trades needs a token address.");
    const net = gtNet(args.chain);
    // 1) Primary: GeckoTerminal per-trade data (wallets + biggest trades).
    try {
      const pools = await gtPools(bridge, `networks/${net}/tokens/${addr}/pools?page=1`);
      if (!pools.length) throw new Error("no GeckoTerminal pool");
      const pool = String(pools.map(poolSummary).sort((a, b) => cnum(b.liquidity_usd) - cnum(a.liquidity_usd))[0].pool_address);
      const tj = await gtRaw(bridge, `https://api.geckoterminal.com/api/v2/networks/${net}/pools/${pool}/trades`);
      const trades = Array.isArray(tj.data) ? (tj.data as CryptoJson[]) : [];
      let buyV = 0;
      let sellV = 0;
      const buyers = new Set<string>();
      const sellers = new Set<string>();
      const all: CryptoJson[] = [];
      for (const tr of trades) {
        const a = (tr.attributes ?? {}) as CryptoJson;
        const v = cnum(a.volume_in_usd);
        const kind = String(a.kind);
        const w = String(a.tx_from_address ?? "");
        if (kind === "buy") {
          buyV += v;
          if (w) buyers.add(w);
        } else {
          sellV += v;
          if (w) sellers.add(w);
        }
        all.push({ kind, usd: Math.round(v * 100) / 100, wallet: w, time: a.block_timestamp });
      }
      all.sort((x, y) => cnum(y.usd) - cnum(x.usd));
      return ok({
        chain: net,
        token_address: addr,
        source_api: "geckoterminal",
        trades: trades.length,
        buy_vol_usd: Math.round(buyV * 100) / 100,
        sell_vol_usd: Math.round(sellV * 100) / 100,
        net_flow_usd: Math.round((buyV - sellV) * 100) / 100,
        unique_buyers: buyers.size,
        unique_sellers: sellers.size,
        biggest_trades: all.slice(0, 6),
      });
    } catch (gtErr) {
      // 2) Fallback: GeckoTerminal rate-limited (429) or has no pool — this is the
      //    tool that 429s most. DexScreener has no per-TRADE data (no wallets /
      //    biggest trades), but it does have the AGGREGATE 24h buy/sell counts +
      //    volume, so give a coarser money-flow signal marked degraded instead of
      //    dying. Per-wallet fields are null (honestly unavailable), not faked.
      try {
        const ds = await dsOverview(bridge, args.chain, addr);
        if (ds) {
          const buys = ds.buys_24h != null ? cnum(ds.buys_24h) : null;
          const sells = ds.sells_24h != null ? cnum(ds.sells_24h) : null;
          return ok({
            chain: net,
            token_address: addr,
            source_api: "dexscreener",
            degraded: true,
            note: "GeckoTerminal was rate-limited; using DexScreener's aggregate 24h flow (buy/sell counts + volume). Per-trade detail (wallets, biggest trades, unique buyers/sellers) is not available from this source.",
            buys_24h: buys,
            sells_24h: sells,
            buy_sell_ratio: buys != null && sells != null && buys + sells > 0 ? Math.round((buys / (buys + sells)) * 100) / 100 : null,
            volume_24h_usd: ds.volume_24h != null ? cnum(ds.volume_24h) : null,
            unique_buyers: null,
            unique_sellers: null,
            biggest_trades: null,
          });
        }
        return fail(`crypto_token_trades failed: ${gtErr instanceof Error ? gtErr.message : String(gtErr)} (DexScreener has no data for ${addr} either).`);
      } catch {
        return fail(`crypto_token_trades failed: ${gtErr instanceof Error ? gtErr.message : String(gtErr)}`);
      }
    }
  },
};

const cryptoGemScan: Capability = {
  def: {
    name: "crypto_gem_scan",
    description:
      "One-shot gem discovery: scans the newest (or trending) pools on a chain, runs a security/honeypot check on the most active ones, DROPS obvious rugs (honeypots / cannot-sell), and returns the top candidates ranked by momentum + liquidity, each with its risk flags and a score. Defaults to BSC / new pools. This is the main 'find me gems / 金狗' tool. Read-only, keyless.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "Chain, default bsc." },
        source: { type: "string", description: "'new' (default) or 'trending'." },
        limit: { type: "number", description: "How many candidates to return (default 5, max 10)." },
      },
    },
  },
  async run(args, bridge) {
    try {
      const chain = gtNet(args.chain);
      const cid = goplusChain(args.chain);
      const source = String(args.source ?? "new").toLowerCase() === "trending" ? "trending" : "new";
      const limit = Math.min(10, Math.max(1, cnum(args.limit) || 5));
      const { pools, source_api } = await discoverPools(bridge, args.chain, source);
      // Spend the security budget on the most ACTIVE pools (by 24h volume).
      const consider = pools
        .filter((s) => s.token_address)
        .sort((a, b) => cnum(b.volume_24h) - cnum(a.volume_24h))
        .slice(0, 8);
      // Run the security checks CONCURRENTLY (was sequential — up to 8 stacked
      // 15s calls = a long hang on a slow network; now one round).
      const secResults = await Promise.all(
        consider.map(async (s) => {
          if (!cid) return null;
          try {
            const t = await goplusSecurity(bridge, cid, String(s.token_address));
            return t ? securityVerdict(t) : null;
          } catch {
            return null;
          }
        }),
      );
      const scored: CryptoJson[] = [];
      for (let i = 0; i < consider.length; i++) {
        const s = consider[i];
        const sec = secResults[i];
        if (sec?.verdict === "danger") continue; // drop honeypots / cannot-sell
        const vol = cnum(s.volume_24h);
        const liq = cnum(s.liquidity_usd);
        const c1 = cnum(s.change_1h);
        const buys = cnum(s.buys_24h);
        const sells = cnum(s.sells_24h);
        const buyRatio = buys + sells > 0 ? buys / (buys + sells) : 0.5;
        const penalty = sec ? (sec.flags as string[]).length : 1;
        const score =
          Math.log10(vol + 10) * 2 +
          Math.log10(liq + 10) +
          Math.max(-2, Math.min(6, c1 / 10)) +
          (buyRatio - 0.5) * 4 -
          penalty;
        scored.push({ ...s, security: sec ?? { verdict: cid ? "unknown" : "unsupported_chain", flags: [] }, score: Math.round(score * 100) / 100 });
      }
      scored.sort((a, b) => cnum(b.score) - cnum(a.score));
      return ok({ chain, source: args.source ?? "new", source_api, scanned: consider.length, candidates: scored.slice(0, limit) });
    } catch (e) {
      return fail(`crypto_gem_scan failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const cryptoHoneypotCheck: Capability = {
  def: {
    name: "crypto_honeypot_check",
    description:
      "Can you SELL this token? A real buy→sell simulation. Primary source honeypot.is actually simulates a BUY then a SELL against the live pool to PROVE sellability, the true buy/sell tax, a risk level, and how many recent holders managed to sell. honeypot.is does NOT index brand-new pools (it 404s on tokens minutes old) — in that case this falls back to GoPlus's own buy/sell simulation and marks sim_source:'goplus' + not_indexed:true (a weaker signal). If NEITHER source has the token, it returns sim_source:'none' + can_sell:null and says sellability is UNVERIFIED — it never fabricates a 'you can sell'. Use this to answer 'is it a honeypot / can I get out'. Defaults to BSC. EVM only, keyless.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "EVM chain, default bsc." },
        address: { type: "string", description: "Token contract address." },
      },
      required: ["address"],
    },
  },
  async run(args, bridge) {
    const addr = String(args.address ?? "").trim();
    if (!addr) return fail("crypto_honeypot_check needs a token address.");
    const cid = goplusChain(args.chain); // EVM chain-id map (bsc→56, eth→1, base→8453, …)
    if (!cid) return fail(`Honeypot simulation covers EVM chains (bsc/eth/base/…). '${String(args.chain)}' is not supported.`);
    const pct = (v: unknown) => (v != null ? Math.round(cnum(v) * 100) / 100 : null);

    // 1) Primary: honeypot.is — a live buy→sell simulation.
    try {
      const j = (await jsonGet(bridge, `https://api.honeypot.is/v2/IsHoneypot?address=${addr}&chainID=${cid}`)) as CryptoJson;
      const hr = (j.honeypotResult ?? {}) as CryptoJson;
      const sim = (j.simulationResult ?? {}) as CryptoJson;
      const sum = (j.summary ?? {}) as CryptoJson;
      const ha = (j.holderAnalysis ?? {}) as CryptoJson;
      const cc = (j.contractCode ?? {}) as CryptoJson;
      const simOk = j.simulationSuccess === true;
      return ok({
        chain: gtNet(args.chain),
        token_address: addr,
        sim_source: "honeypot.is",
        token: ((j.token as CryptoJson)?.symbol ?? (j.token as CryptoJson)?.name) ?? null,
        simulation_success: simOk,
        is_honeypot: hr.isHoneypot === true,
        honeypot_reason: hr.honeypotReason ?? null,
        // The load-bearing answer: could the simulated sell go through?
        can_sell: simOk && hr.isHoneypot !== true,
        buy_tax_pct: pct(sim.buyTax),
        sell_tax_pct: pct(sim.sellTax),
        transfer_tax_pct: pct(sim.transferTax),
        risk: sum.risk ?? null,
        risk_level: sum.riskLevel != null ? cnum(sum.riskLevel) : null,
        flags: Array.isArray(sum.flags) ? sum.flags : [],
        holders_tested: ha.holders != null ? cnum(ha.holders) : null,
        holders_sold_ok: ha.successful != null ? cnum(ha.successful) : null,
        holders_failed_to_sell: ha.failed != null ? cnum(ha.failed) : null,
        average_tax_pct: pct(ha.averageTax),
        open_source: cc.openSource === true ? true : cc.openSource === false ? false : null,
      });
    } catch (primaryErr) {
      // 2) Fallback: honeypot.is has no data (it 404s on brand-new pools — exactly
      //    the case that matters most). Use GoPlus's OWN buy/sell simulation fields
      //    instead of dying with a bare "HTTP 404", and mark not_indexed so the model
      //    reports the weaker source honestly rather than as a live honeypot.is sim.
      try {
        const t = await goplusSecurity(bridge, cid, addr);
        const present = (v: unknown) => v != null && String(v).trim() !== "";
        const on = (v: unknown): boolean | null => (present(v) ? String(v) === "1" : null);
        const hasSim = t != null && (present(t.is_honeypot) || present(t.buy_tax) || present(t.sell_tax) || present(t.cannot_sell_all));
        if (t && hasSim) {
          const isHp = on(t.is_honeypot);
          const cannotSell = on(t.cannot_sell_all);
          return ok({
            chain: gtNet(args.chain),
            token_address: addr,
            sim_source: "goplus",
            not_indexed: true,
            note: "honeypot.is has not indexed this token yet (likely brand-new) — using GoPlus's own buy/sell simulation, a weaker signal than a live honeypot.is sim.",
            token: t.token_symbol ?? t.token_name ?? null,
            simulation_success: null,
            is_honeypot: isHp,
            can_sell: isHp === true || cannotSell === true ? false : isHp === false ? true : null,
            // GoPlus tax fields are FRACTIONS (0.05 = 5%), unlike honeypot.is which is already a percent.
            buy_tax_pct: present(t.buy_tax) ? Math.round(cnum(t.buy_tax) * 1000) / 10 : null,
            sell_tax_pct: present(t.sell_tax) ? Math.round(cnum(t.sell_tax) * 1000) / 10 : null,
            open_source: on(t.is_open_source),
          });
        }
        // 3) Neither source has it — honest UNKNOWN, never a bare error and never a
        //    fabricated "safe". A brand-new token with no sim source = unverified.
        return ok({
          chain: gtNet(args.chain),
          token_address: addr,
          sim_source: "none",
          not_indexed: true,
          is_honeypot: null,
          can_sell: null,
          note: "No simulation source has this token yet (honeypot.is 404'd, GoPlus has no data) — it is almost certainly brand-new. Sellability is UNVERIFIED: do NOT assume you can sell. A live on-chain buy→sell simulation would be needed to confirm.",
        });
      } catch (fallbackErr) {
        // Both sources errored (e.g. GoPlus rate-limited) — surface it honestly.
        return ok({
          chain: gtNet(args.chain),
          token_address: addr,
          sim_source: "none",
          not_indexed: true,
          is_honeypot: null,
          can_sell: null,
          note: `Could not run any sellability check right now (honeypot.is: ${primaryErr instanceof Error ? primaryErr.message : String(primaryErr)}; GoPlus also unavailable: ${fallbackErr instanceof Error ? fallbackErr.message : String(fallbackErr)}). Sellability UNVERIFIED — do not assume you can sell.`,
        });
      }
    }
  },
};

// Owner-privileged / rug-relevant patterns to surface from verified source, so
// the model reports GROUNDED facts ("has a mint() function") instead of inventing
// contract code (which it did when web_fetch only returned explorer nav chrome).
const SOURCE_RISK_PATTERNS: Array<[string, RegExp]> = [
  ["mintable (can create new supply)", /function\s+_?mint\s*\(/i],
  ["blacklist / bot-deny list", /blacklist|blackList|_isBlacklisted|denylist|isBot\b|_bots\b/i],
  ["pausable transfers", /function\s+pause\s*\(|whenNotPaused|_paused\b/i],
  ["owner-adjustable fee/tax", /function\s+set(Fee|Fees|Tax|Taxes|BuyTax|SellTax)\w*\s*\(/i],
  ["max-tx / max-wallet limit", /maxTx|maxWallet|maxTransaction/i],
  ["owner can enable/disable trading", /function\s+(enableTrading|setTrading|openTrading|startTrading)\s*\(|tradingEnabled/i],
  ["fee exclusions (owner favoritism)", /excludeFromFee|isExcludedFromFee/i],
  ["ownership can be transferred", /function\s+transferOwnership\s*\(/i],
];

const cryptoContractSource: Capability = {
  def: {
    name: "crypto_contract_source",
    description:
      "Read a token's VERIFIED contract source from the block explorer (Etherscan V2) and scan it for owner-privileged / rug-relevant functions (mint, blacklist, pausable, owner-adjustable tax, trading toggle, max-tx). Returns whether the source is verified, the contract name/compiler, proxy status, and the concrete risky functions found. NEVER invent contract code — if this returns unverified or unavailable, say so. Defaults to BSC. EVM only.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "EVM chain, default bsc." },
        address: { type: "string", description: "Contract address." },
      },
      required: ["address"],
    },
  },
  async run(args, bridge, opts) {
    const addr = String(args.address ?? "").trim();
    if (!addr) return fail("crypto_contract_source needs a contract address.");
    const cid = goplusChain(args.chain);
    if (!cid) return fail(`Source reads cover EVM chains (bsc/eth/base/…). '${String(args.chain)}' is not supported.`);
    const key = opts?.etherscanKey;
    if (!key) {
      // Fail HONESTLY (not a fabricated success) so the model reports it can't
      // read the source rather than inventing it.
      return fail("Contract source is unavailable: no Etherscan API key configured. Do NOT guess the contract's code — tell the user source verification isn't available.");
    }
    try {
      const j = (await jsonGet(
        bridge,
        `https://api.etherscan.io/v2/api?chainid=${cid}&module=contract&action=getsourcecode&address=${addr}&apikey=${key}`,
      )) as { status?: string; result?: Array<CryptoJson> };
      const row = Array.isArray(j.result) ? j.result[0] : undefined;
      const src = String(row?.SourceCode ?? "");
      if (j.status !== "1" || !row || !src.trim()) {
        return ok({ chain: gtNet(args.chain), address: addr, is_verified: false, note: "Contract source is NOT verified on the explorer — its code cannot be independently checked. Treat unverified as a real risk; do not describe code you cannot see." });
      }
      const risky = SOURCE_RISK_PATTERNS.filter(([, re]) => re.test(src)).map(([label]) => label);
      const impl = String(row.Implementation ?? "");
      return ok({
        chain: gtNet(args.chain),
        address: addr,
        is_verified: true,
        contract_name: row.ContractName ?? null,
        compiler: row.CompilerVersion ?? null,
        is_proxy: String(row.Proxy ?? "") === "1",
        implementation: impl || null,
        risky_functions: risky,
        source_chars: src.length,
      });
    } catch (e) {
      return fail(`crypto_contract_source failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

// Symbol / id → CoinGecko id for the majors an agent asks about by ticker.
const CG_IDS: Record<string, string> = {
  btc: "bitcoin", bitcoin: "bitcoin", xbt: "bitcoin",
  eth: "ethereum", ethereum: "ethereum",
  bnb: "binancecoin", binancecoin: "binancecoin",
  sol: "solana", solana: "solana",
  xrp: "ripple", ripple: "ripple",
  doge: "dogecoin", dogecoin: "dogecoin",
  ada: "cardano", cardano: "cardano",
  avax: "avalanche-2", avalanche: "avalanche-2",
  matic: "matic-network", pol: "matic-network", polygon: "matic-network",
  ton: "the-open-network", trx: "tron", tron: "tron",
  link: "chainlink", chainlink: "chainlink", sui: "sui",
};

const cryptoMarketData: Capability = {
  def: {
    name: "crypto_market_data",
    description:
      "Overall crypto market snapshot (keyless): spot USD price + 24h change for BTC, ETH, BNB (plus any coins you pass), total crypto market cap, BTC dominance, and the Fear & Greed index. Use this for macro / 'risk-on vs risk-off' context — do NOT recall majors' prices from memory, call this instead.",
    parameters: {
      type: "object",
      properties: {
        coins: { type: "string", description: "Optional comma-separated tickers/ids, e.g. 'btc,eth,sol'. Default btc,eth,bnb." },
      },
    },
  },
  async run(args, bridge) {
    try {
      const raw = String(args.coins ?? "btc,eth,bnb").toLowerCase();
      let ids = [...new Set(raw.split(/[,\s]+/).map((s) => s.trim()).filter(Boolean).map((s) => CG_IDS[s] ?? s))];
      if (!ids.length) ids = ["bitcoin", "ethereum", "binancecoin"];
      const priceJson = (await jsonGet(
        bridge,
        `https://api.coingecko.com/api/v3/simple/price?ids=${ids.join(",")}&vs_currencies=usd&include_24hr_change=true`,
      )) as Record<string, { usd?: number; usd_24h_change?: number }>;
      const coins: CryptoJson[] = [];
      for (const id of ids) {
        const p = priceJson[id];
        if (p && p.usd != null) coins.push({ id, price_usd: cnum(p.usd), change_24h_pct: Math.round(cnum(p.usd_24h_change) * 100) / 100 });
      }
      // Global context + Fear&Greed are best-effort (CoinGecko /global rate-limits).
      let total_market_cap_usd: number | null = null;
      let btc_dominance_pct: number | null = null;
      try {
        const g = (await jsonGet(bridge, `https://api.coingecko.com/api/v3/global`)) as {
          data?: { total_market_cap?: { usd?: number }; market_cap_percentage?: { btc?: number }; market_cap_change_percentage_24h_usd?: number };
        };
        if (g.data?.total_market_cap?.usd != null) total_market_cap_usd = Math.round(cnum(g.data.total_market_cap.usd));
        if (g.data?.market_cap_percentage?.btc != null) btc_dominance_pct = Math.round(cnum(g.data.market_cap_percentage.btc) * 10) / 10;
      } catch {
        /* optional */
      }
      let fear_greed: CryptoJson | null = null;
      try {
        const f = (await jsonGet(bridge, `https://api.alternative.me/fng/?limit=1`)) as {
          data?: Array<{ value?: string; value_classification?: string }>;
        };
        const d0 = f.data?.[0];
        if (d0) fear_greed = { value: cnum(d0.value), classification: d0.value_classification ?? null };
      } catch {
        /* optional */
      }
      if (!coins.length && total_market_cap_usd == null && !fear_greed) return fail("crypto_market_data: no data reachable.");
      return ok({ coins, total_market_cap_usd, btc_dominance_pct, fear_greed });
    } catch (e) {
      return fail(`crypto_market_data failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const CAPABILITIES: Capability[] = [
  price,
  selfAudit,
  cryptoMarketData,
  networkStatus,
  getBlock,
  getTransaction,
  webFetch,
  webSearch,
  time,
  cryptoNewPools,
  cryptoTrending,
  cryptoSearchToken,
  cryptoTokenOverview,
  cryptoTokenSecurity,
  cryptoTokenHolders,
  cryptoTokenTrades,
  cryptoHoneypotCheck,
  cryptoContractSource,
  cryptoGemScan,
  mineStart,
  mineStop,
  mineStatus,
];

/** All first-party capability tool names (stable list for the host + tests). */
export const CAPABILITY_NAMES: string[] = CAPABILITIES.map((c) => c.def.name);

/** Build the first-party capability tool source over a host's primitives. The
 *  host merges `defs` into `listTools` and routes any `has(name)` call to
 *  `call(...)`; everything else falls through to the remote (mcp/httptool)
 *  layer. Runs identically on desktop and mobile. */
export function capabilityTools(
  bridge: HostBridge,
  opts?: CapabilityOpts,
): {
  defs: ToolDef[];
  has(name: string): boolean;
  call(name: string, args: Record<string, unknown>): Promise<AgentToolResult>;
} {
  const byName = new Map(CAPABILITIES.map((c) => [c.def.name, c]));
  return {
    defs: CAPABILITIES.map((c) => c.def),
    has: (name) => byName.has(name),
    call: (name, args) => {
      const c = byName.get(name);
      return c ? c.run(args ?? {}, bridge, opts) : Promise.resolve(fail(`unknown capability: ${name}`));
    },
  };
}

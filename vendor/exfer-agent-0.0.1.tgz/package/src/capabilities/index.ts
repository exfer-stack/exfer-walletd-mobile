// First-party capability tools for the in-wallet agent.
//
// These are Exfer's OWN capabilities (price, chain explorer, web read/search,
// time, mining) — implemented ONCE here and shared by both apps. They are NOT
// third-party marketplace tools (those are remote URLs handled by the host's
// mcp/httptool layer). Nothing new is served: everything runs on plumbing the
// app ALREADY reaches, via a small injected HostBridge:
//
//   - rpc()       → walletd JSON-RPC (loopback): chain + pool reads
//   - command()   → a native host command (Tauri invoke): get_bnb_price, mine_*
//   - fetchText() → CORS-free HTTPS through the host (Rust): read the public web
//
// So `exfer_price` reuses the pool's `swap_price_klines` + Binance BNB/USD
// (`get_bnb_price`), the explorer tools reuse walletd's node RPC, and `web_*`
// hit the public internet directly. No `tools.exfer.dev`, no serverless shim.
// The agent core stays transport-agnostic; the host supplies the 3 primitives.

import type { AgentToolResult } from "../agent/session.ts";
import type { ToolDef } from "../types.ts";

/** The 3 primitives a host provides so first-party tools can reach existing
 *  plumbing. Desktop/mobile wrap Tauri `invoke`; browser-dev wraps proxies. */
export interface HostBridge {
  /** walletd JSON-RPC (loopback), e.g. `swap_price_klines`, `get_status`. */
  rpc<T = unknown>(method: string, params?: Record<string, unknown>): Promise<T>;
  /** A native host command (Tauri), e.g. `get_bnb_price`, `mine_start`. */
  command<T = unknown>(name: string, args?: Record<string, unknown>): Promise<T>;
  /** CORS-free HTTPS through the host (Rust), for reading the public web. */
  fetchText(
    url: string,
    init?: { method?: string; body?: string; headers?: Record<string, string> },
  ): Promise<{ status: number; body: string }>;
}

/** Which web-search backend web_search should use. The HOST resolves the
 *  effective provider + key (user's own key, else a built-in default) and passes
 *  it in; exfer-agent stays keyless itself. "free" (or no key) = the keyless
 *  DuckDuckGo -> Wikipedia cascade. A paid provider that errors falls back to
 *  the free cascade so search never hard-fails. */
export interface SearchConfig {
  provider?: "tavily" | "brave" | "free";
  apiKey?: string;
}
export interface CapabilityOpts {
  search?: SearchConfig;
}

interface Capability {
  def: ToolDef;
  run(args: Record<string, unknown>, bridge: HostBridge, opts?: CapabilityOpts): Promise<AgentToolResult>;
}

const EXFER_UNIT = 100_000_000; // 1 EXFER = 1e8 exfers
const HALF_LIFE = 6_307_200; // blocks (~2 years at 10s) — matches the node

function ok(v: unknown): AgentToolResult {
  return { content: typeof v === "string" ? v : JSON.stringify(v), isError: false };
}
function fail(msg: string): AgentToolResult {
  return { content: msg, isError: true };
}

/** Total EXFER emitted through `height`: perpetual 1-EXFER tail + a decaying
 *  99-EXFER bonus (closed form, same curve as the desktop dashboard). */
function circulatingSupplyExfer(height: number): number {
  if (!isFinite(height) || height < 0) return 0;
  const n = height + 1;
  const r = Math.pow(2, -1 / HALF_LIFE);
  return n + 99 * ((1 - Math.pow(r, n)) / (1 - r));
}

function htmlToText(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, " ")
    .trim();
}

// ── price: pool klines (USD close) + Binance BNB/USD + closed-form supply ────
const price: Capability = {
  def: {
    name: "exfer_price",
    description:
      "Current EXFER market price and market cap. Returns USD per EXFER (from the swap pool's own price history), 24h change, the BNB/USD anchor, circulating supply, and market cap. Read-only, no key. Use whenever the user asks what EXFER is worth.",
    parameters: { type: "object", properties: {} },
  },
  async run(_args, bridge) {
    try {
      const kl = await bridge.rpc<{ items?: { c: number | string }[] }>("swap_price_klines", {
        interval: "1d",
        limit: 2,
      });
      const items = Array.isArray(kl?.items) ? kl.items : [];
      const usd = items.length ? Number(items[items.length - 1].c) : NaN;
      if (!isFinite(usd) || usd <= 0) {
        return fail("EXFER price is unavailable right now (the pool returned no price).");
      }
      const prev = items.length >= 2 ? Number(items[items.length - 2].c) : usd;
      const change24h = isFinite(prev) && prev > 0 ? ((usd - prev) / prev) * 100 : 0;

      let bnbUsd: number | null = null;
      try {
        const raw = await bridge.command<string>("get_bnb_price");
        const p = Number((JSON.parse(raw) as { price?: string }).price);
        bnbUsd = isFinite(p) && p > 0 ? p : null;
      } catch {
        /* best-effort anchor */
      }
      let supply: number | null = null;
      try {
        const h = await bridge.rpc<{ height?: number }>("get_block_height");
        if (typeof h?.height === "number") supply = circulatingSupplyExfer(h.height);
      } catch {
        /* best-effort */
      }
      return ok({
        usd_per_exfer: usd,
        change_24h_pct: Number(change24h.toFixed(2)),
        bnb_usd: bnbUsd,
        circulating_supply_exfer: supply != null ? Math.round(supply) : null,
        market_cap_usd: supply != null ? Math.round(supply * usd) : null,
        unit_note: "1 EXFER = 1e8 base exfers",
        _unit: EXFER_UNIT,
      });
    } catch (e) {
      return fail(`price lookup failed: ${String(e)}`);
    }
  },
};

// ── explorer: raw pass-through of walletd node RPC (no reshaping guesswork) ──
const networkStatus: Capability = {
  def: {
    name: "exfer_network_status",
    description:
      "EXFER network status from the node: chain tip height, difficulty, and chain/node info. Read-only. Use for questions about the EXFER chain itself (how many blocks, current difficulty/hashrate).",
    parameters: { type: "object", properties: {} },
  },
  async run(_a, bridge) {
    try {
      return ok(await bridge.rpc("get_status"));
    } catch (e) {
      return fail(`network status failed: ${String(e)}`);
    }
  },
};

const getBlock: Capability = {
  def: {
    name: "exfer_get_block",
    description: "Look up an EXFER block by height or by block id/hash. Read-only explorer.",
    parameters: {
      type: "object",
      properties: {
        height: { type: "number", description: "Block height." },
        id: { type: "string", description: "Block id/hash (hex)." },
      },
    },
  },
  async run(args, bridge) {
    try {
      if (typeof args.height === "number") {
        return ok(await bridge.rpc("get_block_by_height", { height: args.height }));
      }
      if (args.id) return ok(await bridge.rpc("get_block_by_id", { block_id: String(args.id) }));
      return fail("exfer_get_block needs a height or an id.");
    } catch (e) {
      return fail(`get_block failed: ${String(e)}`);
    }
  },
};

const getTransaction: Capability = {
  def: {
    name: "exfer_get_transaction",
    description:
      "Look up an EXFER transaction by tx id (searches the mempool first, then the confirmed chain). Read-only explorer.",
    parameters: {
      type: "object",
      properties: { tx_id: { type: "string", description: "Transaction id (hex)." } },
      required: ["tx_id"],
    },
  },
  async run(args, bridge) {
    try {
      return ok(await bridge.rpc("get_transaction", { tx_id: String(args.tx_id ?? args.id ?? "") }));
    } catch (e) {
      return fail(`get_transaction failed: ${String(e)}`);
    }
  },
};

// ── web: read any public page / search (keyless, host-side HTTPS) ────────────
const webFetch: Capability = {
  def: {
    name: "web_fetch",
    description:
      "Fetch a public web page or JSON API by URL and return its text (HTML stripped, truncated). Read-only, runs host-side (works on desktop and mobile, no CORS). Use to read a specific page, article, forum thread (e.g. a bitcointalk topic), or API the user references.",
    parameters: {
      type: "object",
      properties: { url: { type: "string", description: "The https URL to fetch." } },
      required: ["url"],
    },
  },
  async run(args, bridge) {
    const url = String(args.url ?? "").trim();
    if (!/^https?:\/\//i.test(url)) return fail("web_fetch needs an http(s) URL.");
    try {
      const r = await bridge.fetchText(url, { headers: { "user-agent": "Mozilla/5.0 (exfer-agent)" } });
      if (r.status >= 400) return fail(`web_fetch got HTTP ${r.status} for ${url}`);
      // Strip HTML for full documents AND fragments (e.g. a bare <table> of
      // <td>/<tr>): a doc marker in the head, or several closing tags anywhere,
      // means it's markup the user shouldn't see raw. JSON/plain text (no tag
      // soup) passes through untouched.
      const head = r.body.slice(0, 500);
      const closingTags = r.body.match(/<\/[a-z][a-z0-9]*>/gi)?.length ?? 0;
      const looksHtml = /<html|<body|<!doctype|<head/i.test(head) || closingTags >= 3;
      const text = looksHtml ? htmlToText(r.body) : r.body;
      const MAX = 12000;
      return ok({ url, status: r.status, truncated: text.length > MAX, text: text.slice(0, MAX) });
    } catch (e) {
      return fail(`web_fetch failed: ${String(e)}`);
    }
  },
};

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

/** Unwrap DuckDuckGo's `//duckduckgo.com/l/?uddg=<encoded>` redirect wrapper to
 *  the real destination, and protocol-relative `//host` to https. */
function unwrapDdgHref(href: string): string {
  const uddg = /[?&]uddg=([^&]+)/.exec(href);
  if (uddg) {
    try {
      return decodeURIComponent(uddg[1]);
    } catch {
      /* keep raw */
    }
  }
  return href.startsWith("//") ? `https:${href}` : href;
}

/** Parse DuckDuckGo's Instant Answer JSON (stable, documented, keyless). Covers
 *  entity/definition queries: an Abstract plus a flat list of RelatedTopics.
 *  Returns [] for queries with no instant answer (the caller then falls back). */
interface DdgIa {
  Heading?: string;
  AbstractText?: string;
  AbstractURL?: string;
  RelatedTopics?: unknown[];
}
function parseInstantAnswer(j: DdgIa): SearchResult[] {
  const out: SearchResult[] = [];
  if (j.AbstractText && j.AbstractURL) {
    out.push({ title: j.Heading ?? "", url: j.AbstractURL, snippet: j.AbstractText });
  }
  const walk = (arr: unknown[]): void => {
    for (const t of arr) {
      const o = t as { Topics?: unknown[]; FirstURL?: string; Text?: string };
      if (Array.isArray(o.Topics)) walk(o.Topics);
      else if (o.FirstURL) {
        out.push({ title: (o.Text ?? "").split(" - ")[0], url: o.FirstURL, snippet: o.Text ?? "" });
      }
    }
  };
  if (Array.isArray(j.RelatedTopics)) walk(j.RelatedTopics);
  return out;
}

/** Parse the `lite.duckduckgo.com/lite/` results page — a minimal HTML table
 *  designed for old browsers, far more stable than the full search page. */
function parseDdgLite(html: string): SearchResult[] {
  const out: SearchResult[] = [];
  const re = /<a[^>]+class="result-link"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html)) && out.length < 12) {
    out.push({ title: htmlToText(m[2]), url: unwrapDdgHref(m[1]), snippet: "" });
  }
  const snips: string[] = [];
  const sre = /class="result-snippet"[^>]*>([\s\S]*?)<\/td>/gi;
  let sm: RegExpExecArray | null;
  while ((sm = sre.exec(html)) && snips.length < out.length) snips.push(htmlToText(sm[1]));
  out.forEach((r, i) => {
    if (snips[i]) r.snippet = snips[i];
  });
  return out;
}

/** Parse Wikipedia's REST search (`/w/rest.php/v1/search/page`) — a reliable,
 *  keyless, structured source that is never bot-challenged. Good coverage for
 *  entity/concept queries (coins, protocols, people); not general web/news. */
interface WikiSearch {
  pages?: { title?: string; key?: string; excerpt?: string; description?: string }[];
}
function parseWikipedia(j: WikiSearch): SearchResult[] {
  return (j.pages ?? [])
    .map((p) => ({
      title: p.title ?? p.key ?? "",
      url: p.key ? `https://en.wikipedia.org/wiki/${encodeURIComponent(p.key)}` : "",
      snippet: htmlToText(p.excerpt ?? p.description ?? ""),
    }))
    .filter((r) => r.url);
}

/** Tavily — the agent-purpose-built search API; returns LLM-ready results.
 *  POST https://api.tavily.com/search with a Bearer key. */
async function tavilySearch(bridge: HostBridge, query: string, apiKey: string): Promise<SearchResult[]> {
  const r = await bridge.fetchText("https://api.tavily.com/search", {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ query, max_results: 8, search_depth: "basic" }),
  });
  if (r.status >= 400 || !r.body.trim()) throw new Error(`tavily HTTP ${r.status}`);
  const j = JSON.parse(r.body) as { results?: { title?: string; url?: string; content?: string }[] };
  return (j.results ?? [])
    .filter((x) => x.url)
    .slice(0, 8)
    .map((x) => ({ title: String(x.title ?? x.url), url: String(x.url), snippet: String(x.content ?? "") }));
}

/** Brave Search API — an independent web index. GET with an X-Subscription-Token. */
async function braveSearch(bridge: HostBridge, query: string, apiKey: string): Promise<SearchResult[]> {
  const r = await bridge.fetchText(
    `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=8`,
    { headers: { accept: "application/json", "x-subscription-token": apiKey } },
  );
  if (r.status >= 400 || !r.body.trim()) throw new Error(`brave HTTP ${r.status}`);
  const j = JSON.parse(r.body) as { web?: { results?: { title?: string; url?: string; description?: string }[] } };
  return (j.web?.results ?? [])
    .filter((x) => x.url)
    .slice(0, 8)
    .map((x) => ({ title: String(x.title ?? x.url), url: String(x.url), snippet: String(x.description ?? "") }));
}

const webSearch: Capability = {
  def: {
    name: "web_search",
    description:
      "Search the public web and return the top results (title, url, snippet). Keyless, runs host-side. Use for current information: news, other coins' prices, forum posts (e.g. bitcointalk), docs. For a specific known URL, use web_fetch instead.",
    parameters: {
      type: "object",
      properties: { query: { type: "string", description: "The search query." } },
      required: ["query"],
    },
  },
  async run(args, bridge, opts) {
    const q = String(args.query ?? "").trim();
    if (!q) return fail("web_search needs a query.");
    const enc = encodeURIComponent(q);

    // Preferred: a configured search API. The host resolves the effective
    // provider + key (the user's own key, else a built-in default). On ANY
    // error we fall through to the free cascade below, so search never
    // hard-fails and a bad/expired key degrades gracefully.
    const sc = opts?.search;
    if (sc?.apiKey && (sc.provider === "tavily" || sc.provider === "brave")) {
      try {
        const results =
          sc.provider === "tavily"
            ? await tavilySearch(bridge, q, sc.apiKey)
            : await braveSearch(bridge, q, sc.apiKey);
        if (results.length) return ok({ query: q, source: sc.provider, results });
      } catch {
        /* fall through to the keyless cascade */
      }
    }

    // Cascade keyless sources; return the first that yields results. On a user's
    // device DuckDuckGo usually answers (general web); some networks bot-challenge
    // it (empty/202 body), so Wikipedia is a reliable structured floor for
    // entity/concept queries. web_fetch covers any specific URL beyond these.

    // 1. DuckDuckGo Instant Answer JSON (structured, stable shape).
    try {
      const ia = await bridge.fetchText(
        `https://api.duckduckgo.com/?q=${enc}&format=json&no_html=1&no_redirect=1&t=exfer-agent`,
        { headers: { "user-agent": "Mozilla/5.0 (exfer-agent)" } },
      );
      if (ia.status < 400 && ia.body.trim()) {
        const results = parseInstantAnswer(JSON.parse(ia.body) as DdgIa).slice(0, 8);
        if (results.length) return ok({ query: q, source: "duckduckgo-instant-answer", results });
      }
    } catch {
      /* next source */
    }
    // 2. DuckDuckGo lite (minimal, stable HTML) for general web results.
    try {
      const r = await bridge.fetchText(`https://lite.duckduckgo.com/lite/?q=${enc}`, {
        headers: { "user-agent": "Mozilla/5.0 (exfer-agent)" },
      });
      if (r.status < 400) {
        const results = parseDdgLite(r.body).slice(0, 8);
        if (results.length) return ok({ query: q, source: "duckduckgo-lite", results });
      }
    } catch {
      /* next source */
    }
    // 3. Wikipedia REST search (reliable, keyless, never bot-challenged).
    try {
      const w = await bridge.fetchText(
        `https://en.wikipedia.org/w/rest.php/v1/search/page?q=${enc}&limit=8`,
        { headers: { "user-agent": "exfer-agent/0.1 (in-wallet assistant; https://exfer.dev)" } },
      );
      if (w.status < 400) {
        const results = parseWikipedia(JSON.parse(w.body) as WikiSearch).slice(0, 8);
        if (results.length) return ok({ query: q, source: "wikipedia", results });
      }
    } catch {
      /* fall through to the empty note */
    }
    return ok({
      query: q,
      results: [],
      note: "No results from keyless search sources right now. Try web_fetch on a specific URL.",
    });
  },
};

const time: Capability = {
  def: {
    name: "time",
    description: "The current date and time (device clock: UTC + local + unix seconds). Read-only.",
    parameters: { type: "object", properties: {} },
  },
  async run() {
    const now = new Date();
    return ok({
      iso_utc: now.toISOString(),
      unix_seconds: Math.floor(now.getTime() / 1000),
      local: now.toString(),
    });
  },
};

// ── mining: native in-app miner (migrated here from each app's agentHost) ────
function miner(name: string, cmd: string, description: string, params: Record<string, unknown>): Capability {
  return {
    def: { name, description, parameters: params },
    async run(args, bridge) {
      try {
        return ok(await bridge.command(cmd, args));
      } catch (e) {
        return fail(`miner error: ${String(e)}`);
      }
    },
  };
}

const mineStart = miner(
  "exfer_mine_start",
  "mine_start",
  "Start mining EXFER on this device's CPU, paying out to your address. Defaults to the SOLO pool (full block reward to you; no shared-pool threshold). Uses CPU. Generate an address first with exfer_generate_address.",
  {
    type: "object",
    properties: {
      address: { type: "string", description: "Your 64-hex payout address." },
      pool: { type: "string", description: "Optional stratum pool URL (ssl://host:port). Default: the solo pool." },
      threads: { type: "number", description: "CPU threads (1-4). Default 1 — Argon2id is memory-hard." },
    },
    required: ["address"],
  },
);
const mineStop = miner("exfer_mine_stop", "mine_stop", "Stop the in-app miner.", {
  type: "object",
  properties: {},
});
const mineStatus = miner(
  "exfer_mine_status",
  "mine_status",
  "Current in-app miner status: running, hashrate, shares accepted/rejected, pool authorization, uptime.",
  { type: "object", properties: {} },
);

// ── crypto discovery: multichain gem-finder capabilities (keyless) ───────────
// Backed by free public APIs the host reaches CORS-free: GeckoTerminal (new /
// trending pools, token overview, search — multichain) and GoPlus (token
// security / honeypot). BSC by default. Gives the agent GMGN-style discovery it
// can REASON over + fuse, rather than a dashboard. All read-only, no key.

type CryptoJson = Record<string, unknown>;

function cnum(v: unknown): number {
  const n = Number(v);
  return isFinite(n) ? n : 0;
}
function isYes(v: unknown): boolean {
  return String(v ?? "") === "1";
}
/** Top-10 holder concentration (%) from a GoPlus `holders` array (fractions). */
function top10Concentration(t: CryptoJson): number {
  const h = Array.isArray(t.holders) ? (t.holders as CryptoJson[]) : [];
  return Math.round(h.slice(0, 10).reduce((s, x) => s + cnum(x.percent), 0) * 10000) / 100;
}

/** Chain alias -> GeckoTerminal network id (default bsc). */
function gtNet(chain?: unknown): string {
  const c = String(chain ?? "bsc").toLowerCase().trim();
  const m: Record<string, string> = {
    bsc: "bsc", bnb: "bsc", binance: "bsc",
    eth: "eth", ethereum: "eth", ether: "eth",
    base: "base",
    sol: "solana", solana: "solana",
    arb: "arbitrum", arbitrum: "arbitrum",
    polygon: "polygon_pos", matic: "polygon_pos",
    avax: "avax", avalanche: "avax",
  };
  return m[c] ?? c;
}

/** Chain alias -> GoPlus chain id (EVM only; "" when unsupported, e.g. solana). */
function goplusChain(chain?: unknown): string {
  const c = String(chain ?? "bsc").toLowerCase().trim();
  const m: Record<string, string> = {
    bsc: "56", bnb: "56", binance: "56", eth: "1", ethereum: "1",
    base: "8453", arb: "42161", arbitrum: "42161",
    polygon: "137", matic: "137", avax: "43114", avalanche: "43114",
  };
  return m[c] ?? "";
}

/** Flatten a GeckoTerminal pool object into a compact summary. */
function poolSummary(p: CryptoJson): CryptoJson {
  const a = (p.attributes ?? {}) as CryptoJson;
  const rel = (p.relationships ?? {}) as CryptoJson;
  const baseId = String((((rel.base_token as CryptoJson)?.data as CryptoJson)?.id) ?? "");
  const tokenAddr = baseId.includes("_") ? baseId.slice(baseId.indexOf("_") + 1) : baseId;
  const vol = (a.volume_usd ?? {}) as CryptoJson;
  const chg = (a.price_change_percentage ?? {}) as CryptoJson;
  const tx = ((a.transactions ?? {}) as CryptoJson).h24 as CryptoJson | undefined;
  const created = String(a.pool_created_at ?? "");
  const ageMin = created ? Math.max(0, Math.round((Date.now() - new Date(created).getTime()) / 60000)) : null;
  return {
    name: a.name,
    token_address: tokenAddr,
    pool_address: a.address,
    price_usd: cnum(a.base_token_price_usd),
    fdv_usd: cnum(a.fdv_usd),
    market_cap_usd: a.market_cap_usd != null ? cnum(a.market_cap_usd) : null,
    liquidity_usd: cnum(a.reserve_in_usd),
    volume_1h: cnum(vol.h1),
    volume_24h: cnum(vol.h24),
    change_1h: cnum(chg.h1),
    change_24h: cnum(chg.h24),
    buys_24h: tx ? cnum(tx.buys) : null,
    sells_24h: tx ? cnum(tx.sells) : null,
    buyers_24h: tx ? cnum(tx.buyers) : null,
    sellers_24h: tx ? cnum(tx.sellers) : null,
    age_minutes: ageMin,
    created_at: created || null,
  };
}

async function gtPools(bridge: HostBridge, path: string): Promise<CryptoJson[]> {
  const r = await bridge.fetchText(`https://api.geckoterminal.com/api/v2/${path}`, {
    headers: { accept: "application/json" },
  });
  if (r.status >= 400 || !r.body.trim()) throw new Error(`GeckoTerminal HTTP ${r.status}`);
  const j = JSON.parse(r.body) as { data?: CryptoJson[] };
  return Array.isArray(j.data) ? j.data : [];
}

async function goplusSecurity(bridge: HostBridge, chainId: string, address: string): Promise<CryptoJson | null> {
  const r = await bridge.fetchText(
    `https://api.gopluslabs.io/api/v1/token_security/${chainId}?contract_addresses=${address}`,
    { headers: { accept: "application/json" } },
  );
  if (r.status >= 400 || !r.body.trim()) throw new Error(`GoPlus HTTP ${r.status}`);
  const j = JSON.parse(r.body) as { result?: Record<string, CryptoJson> };
  const res = j.result ?? {};
  const lc = address.toLowerCase();
  const key = Object.keys(res).find((k) => k.toLowerCase() === lc) ?? Object.keys(res)[0];
  return key ? res[key] : null;
}

/** Turn raw GoPlus fields into a compact verdict + human-readable risk flags. */
function securityVerdict(t: CryptoJson): CryptoJson {
  const on = (v: unknown) => String(v ?? "") === "1";
  const honeypot = on(t.is_honeypot);
  const cannotSell = on(t.cannot_sell_all);
  const buyTax = cnum(t.buy_tax) * 100;
  const sellTax = cnum(t.sell_tax) * 100;
  const openSource = on(t.is_open_source);
  const mintable = on(t.is_mintable);
  const canTakeBack = on(t.can_take_back_ownership);
  const hiddenOwner = on(t.hidden_owner);
  const blacklist = on(t.is_blacklisted);
  const pausable = on(t.transfer_pausable);
  const owner = String(t.owner_address ?? "");
  const renounced = owner === "" || /^0x0+$/i.test(owner) || /0*dead$/i.test(owner);
  const ownerPct = cnum(t.owner_percent) * 100;
  const top10 = top10Concentration(t);
  const flags: string[] = [];
  if (honeypot) flags.push("HONEYPOT");
  if (cannotSell) flags.push("cannot sell all");
  if (sellTax > 10) flags.push(`high sell tax ${sellTax.toFixed(0)}%`);
  if (buyTax > 10) flags.push(`high buy tax ${buyTax.toFixed(0)}%`);
  if (!openSource) flags.push("not open source");
  if (mintable) flags.push("mintable");
  if (canTakeBack) flags.push("owner can reclaim ownership");
  if (hiddenOwner) flags.push("hidden owner");
  if (blacklist) flags.push("has blacklist");
  if (pausable) flags.push("transfers pausable");
  if (!renounced && ownerPct > 5) flags.push(`owner holds ${ownerPct.toFixed(0)}%`);
  if (top10 >= 80) flags.push(`top 10 hold ${top10.toFixed(0)}%`);
  const verdict = honeypot || cannotSell ? "danger" : flags.length >= 2 ? "caution" : flags.length === 1 ? "watch" : "ok";
  return {
    verdict,
    flags,
    honeypot,
    buy_tax_pct: Math.round(buyTax * 10) / 10,
    sell_tax_pct: Math.round(sellTax * 10) / 10,
    open_source: openSource,
    owner_renounced: renounced,
    owner_percent: Math.round(ownerPct * 10) / 10,
    mintable,
    can_take_back: canTakeBack,
    hidden_owner: hiddenOwner,
    blacklist,
    transfer_pausable: pausable,
    holder_count: cnum(t.holder_count),
    lp_holder_count: t.lp_holder_count != null ? cnum(t.lp_holder_count) : null,
    top10_concentration_pct: top10,
    token: t.token_symbol ?? t.token_name ?? null,
  };
}

const cryptoNewPools: Capability = {
  def: {
    name: "crypto_new_pools",
    description:
      "Freshly launched DEX pools (brand-new tokens) on a chain — the raw feed for finding early gems. Defaults to BSC. Returns name, token address, price, liquidity, 24h/1h volume, buys/sells, price change, and age in minutes. Read-only, keyless. Chains: bsc (default), eth, base, solana, arbitrum, polygon, avax.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "Chain, default bsc." },
        limit: { type: "number", description: "How many pools (default 10, max 20)." },
      },
    },
  },
  async run(args, bridge) {
    try {
      const chain = gtNet(args.chain);
      const limit = Math.min(20, Math.max(1, cnum(args.limit) || 10));
      const pools = await gtPools(bridge, `networks/${chain}/new_pools?page=1`);
      return ok({ chain, count: Math.min(limit, pools.length), pools: pools.slice(0, limit).map(poolSummary) });
    } catch (e) {
      return fail(`crypto_new_pools failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const cryptoTrending: Capability = {
  def: {
    name: "crypto_trending",
    description:
      "Trending / hottest DEX pools on a chain right now (by momentum + volume). Defaults to BSC. Same fields as crypto_new_pools. Read-only, keyless. Use for 'what's hot' vs crypto_new_pools for 'what's brand new'.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "Chain, default bsc." },
        limit: { type: "number", description: "How many (default 10, max 20)." },
      },
    },
  },
  async run(args, bridge) {
    try {
      const chain = gtNet(args.chain);
      const limit = Math.min(20, Math.max(1, cnum(args.limit) || 10));
      const pools = await gtPools(bridge, `networks/${chain}/trending_pools?page=1`);
      return ok({ chain, count: Math.min(limit, pools.length), pools: pools.slice(0, limit).map(poolSummary) });
    } catch (e) {
      return fail(`crypto_trending failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const cryptoSearchToken: Capability = {
  def: {
    name: "crypto_search_token",
    description:
      "Find a token / trading pool by name, symbol, or contract address, across DEXs. Returns matching pools with price, liquidity, volume, and change. Read-only, keyless. Optionally restrict to a chain.",
    parameters: {
      type: "object",
      properties: {
        query: { type: "string", description: "Name, symbol, or contract address." },
        chain: { type: "string", description: "Optional chain filter, e.g. bsc." },
      },
      required: ["query"],
    },
  },
  async run(args, bridge) {
    const q = String(args.query ?? "").trim();
    if (!q) return fail("crypto_search_token needs a query.");
    try {
      const netParam = args.chain ? `&network=${gtNet(args.chain)}` : "";
      const pools = await gtPools(bridge, `search/pools?query=${encodeURIComponent(q)}${netParam}`);
      return ok({ query: q, count: Math.min(10, pools.length), results: pools.slice(0, 10).map(poolSummary) });
    } catch (e) {
      return fail(`crypto_search_token failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const cryptoTokenOverview: Capability = {
  def: {
    name: "crypto_token_overview",
    description:
      "Market overview for a specific token by contract address: price, FDV, market cap, liquidity, 24h/1h volume, buys/sells, price change, and pool age. Uses the token's deepest pool. Defaults to BSC. Read-only, keyless.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "Chain, default bsc." },
        address: { type: "string", description: "Token contract address." },
      },
      required: ["address"],
    },
  },
  async run(args, bridge) {
    const addr = String(args.address ?? "").trim();
    if (!addr) return fail("crypto_token_overview needs a token address.");
    try {
      const chain = gtNet(args.chain);
      const pools = await gtPools(bridge, `networks/${chain}/tokens/${addr}/pools?page=1`);
      if (!pools.length) return fail(`No pool found for ${addr} on ${chain}.`);
      const best = pools
        .map(poolSummary)
        .sort((a, b) => cnum(b.liquidity_usd) - cnum(a.liquidity_usd))[0];
      return ok({ chain, token_address: addr, ...best });
    } catch (e) {
      return fail(`crypto_token_overview failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const cryptoTokenSecurity: Capability = {
  def: {
    name: "crypto_token_security",
    description:
      "Safety / rug check for a token contract (GoPlus): honeypot, buy/sell tax, mintable, open-source, owner renounced, owner %, hidden owner, blacklist, pausable transfers, LP/holder counts — with an overall verdict (ok / watch / caution / danger) and plain risk flags. ALWAYS run this before treating a token as a gem. Defaults to BSC. EVM chains only. Read-only, keyless.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "EVM chain, default bsc." },
        address: { type: "string", description: "Token contract address." },
      },
      required: ["address"],
    },
  },
  async run(args, bridge) {
    const addr = String(args.address ?? "").trim();
    if (!addr) return fail("crypto_token_security needs a token address.");
    const cid = goplusChain(args.chain);
    if (!cid) return fail(`Security checks cover EVM chains (bsc/eth/base/…). '${String(args.chain)}' is not supported by GoPlus.`);
    try {
      const t = await goplusSecurity(bridge, cid, addr);
      if (!t) return fail(`No security data for ${addr} (not indexed yet).`);
      return ok({ chain: gtNet(args.chain), token_address: addr, ...securityVerdict(t) });
    } catch (e) {
      return fail(`crypto_token_security failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const cryptoTokenHolders: Capability = {
  def: {
    name: "crypto_token_holders",
    description:
      "Holder structure / concentration risk for a token (GoPlus): total holders, LP holder count, top-10 concentration %, and the top holders with their %, whether locked, and whether a contract. High top-holder concentration = dump / rug risk. Defaults to BSC. EVM only. Read-only, keyless.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "EVM chain, default bsc." },
        address: { type: "string", description: "Token contract address." },
      },
      required: ["address"],
    },
  },
  async run(args, bridge) {
    const addr = String(args.address ?? "").trim();
    if (!addr) return fail("crypto_token_holders needs a token address.");
    const cid = goplusChain(args.chain);
    if (!cid) return fail(`Holder data covers EVM chains (bsc/eth/base/…). '${String(args.chain)}' is not supported.`);
    try {
      const t = await goplusSecurity(bridge, cid, addr);
      if (!t) return fail(`No holder data for ${addr} (not indexed yet).`);
      const holders = Array.isArray(t.holders) ? (t.holders as CryptoJson[]) : [];
      const top = holders.slice(0, 10).map((h) => ({
        address: h.address,
        percent: Math.round(cnum(h.percent) * 10000) / 100,
        tag: h.tag || null,
        is_locked: isYes(h.is_locked),
        is_contract: isYes(h.is_contract),
      }));
      return ok({
        chain: gtNet(args.chain),
        token_address: addr,
        holder_count: cnum(t.holder_count),
        lp_holder_count: t.lp_holder_count != null ? cnum(t.lp_holder_count) : null,
        top10_concentration_pct: top10Concentration(t),
        top_holders: top,
      });
    } catch (e) {
      return fail(`crypto_token_holders failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const cryptoTokenTrades: Capability = {
  def: {
    name: "crypto_token_trades",
    description:
      "Recent trade flow for a token (money-flow / whale signal): from the token's deepest pool's latest ~300 DEX trades — buy vs sell USD volume, net flow, unique buyers/sellers, and the biggest recent buys/sells with wallet + time. A keyless proxy for 'who's buying / is money flowing in'. Defaults to BSC. Read-only, keyless.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "Chain, default bsc." },
        address: { type: "string", description: "Token contract address." },
      },
      required: ["address"],
    },
  },
  async run(args, bridge) {
    const addr = String(args.address ?? "").trim();
    if (!addr) return fail("crypto_token_trades needs a token address.");
    try {
      const net = gtNet(args.chain);
      const pools = await gtPools(bridge, `networks/${net}/tokens/${addr}/pools?page=1`);
      if (!pools.length) return fail(`No pool found for ${addr} on ${net}.`);
      const pool = String(pools.map(poolSummary).sort((a, b) => cnum(b.liquidity_usd) - cnum(a.liquidity_usd))[0].pool_address);
      const r = await bridge.fetchText(`https://api.geckoterminal.com/api/v2/networks/${net}/pools/${pool}/trades`, {
        headers: { accept: "application/json" },
      });
      if (r.status >= 400 || !r.body.trim()) throw new Error(`trades HTTP ${r.status}`);
      const trades = (JSON.parse(r.body) as { data?: CryptoJson[] }).data ?? [];
      let buyV = 0;
      let sellV = 0;
      const buyers = new Set<string>();
      const sellers = new Set<string>();
      const all: CryptoJson[] = [];
      for (const tr of trades) {
        const a = (tr.attributes ?? {}) as CryptoJson;
        const v = cnum(a.volume_in_usd);
        const kind = String(a.kind);
        const w = String(a.tx_from_address ?? "");
        if (kind === "buy") {
          buyV += v;
          if (w) buyers.add(w);
        } else {
          sellV += v;
          if (w) sellers.add(w);
        }
        all.push({ kind, usd: Math.round(v * 100) / 100, wallet: w, time: a.block_timestamp });
      }
      all.sort((x, y) => cnum(y.usd) - cnum(x.usd));
      return ok({
        chain: net,
        token_address: addr,
        trades: trades.length,
        buy_vol_usd: Math.round(buyV * 100) / 100,
        sell_vol_usd: Math.round(sellV * 100) / 100,
        net_flow_usd: Math.round((buyV - sellV) * 100) / 100,
        unique_buyers: buyers.size,
        unique_sellers: sellers.size,
        biggest_trades: all.slice(0, 6),
      });
    } catch (e) {
      return fail(`crypto_token_trades failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const cryptoGemScan: Capability = {
  def: {
    name: "crypto_gem_scan",
    description:
      "One-shot gem discovery: scans the newest (or trending) pools on a chain, runs a security/honeypot check on the most active ones, DROPS obvious rugs (honeypots / cannot-sell), and returns the top candidates ranked by momentum + liquidity, each with its risk flags and a score. Defaults to BSC / new pools. This is the main 'find me gems / 金狗' tool. Read-only, keyless.",
    parameters: {
      type: "object",
      properties: {
        chain: { type: "string", description: "Chain, default bsc." },
        source: { type: "string", description: "'new' (default) or 'trending'." },
        limit: { type: "number", description: "How many candidates to return (default 5, max 10)." },
      },
    },
  },
  async run(args, bridge) {
    try {
      const chain = gtNet(args.chain);
      const cid = goplusChain(args.chain);
      const source = String(args.source ?? "new").toLowerCase() === "trending" ? "trending_pools" : "new_pools";
      const limit = Math.min(10, Math.max(1, cnum(args.limit) || 5));
      const raw = await gtPools(bridge, `networks/${chain}/${source}?page=1`);
      // Spend the security budget on the most ACTIVE pools (by 24h volume).
      const consider = raw
        .map(poolSummary)
        .filter((s) => s.token_address)
        .sort((a, b) => cnum(b.volume_24h) - cnum(a.volume_24h))
        .slice(0, 8);
      const scored: CryptoJson[] = [];
      for (const s of consider) {
        let sec: CryptoJson | null = null;
        if (cid) {
          try {
            const t = await goplusSecurity(bridge, cid, String(s.token_address));
            sec = t ? securityVerdict(t) : null;
          } catch {
            sec = null;
          }
        }
        if (sec?.verdict === "danger") continue; // drop honeypots / cannot-sell
        const vol = cnum(s.volume_24h);
        const liq = cnum(s.liquidity_usd);
        const c1 = cnum(s.change_1h);
        const buys = cnum(s.buys_24h);
        const sells = cnum(s.sells_24h);
        const buyRatio = buys + sells > 0 ? buys / (buys + sells) : 0.5;
        const penalty = sec ? (sec.flags as string[]).length : 1;
        const score =
          Math.log10(vol + 10) * 2 +
          Math.log10(liq + 10) +
          Math.max(-2, Math.min(6, c1 / 10)) +
          (buyRatio - 0.5) * 4 -
          penalty;
        scored.push({ ...s, security: sec ?? { verdict: cid ? "unknown" : "unsupported_chain", flags: [] }, score: Math.round(score * 100) / 100 });
      }
      scored.sort((a, b) => cnum(b.score) - cnum(a.score));
      return ok({ chain, source: args.source ?? "new", scanned: consider.length, candidates: scored.slice(0, limit) });
    } catch (e) {
      return fail(`crypto_gem_scan failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  },
};

const CAPABILITIES: Capability[] = [
  price,
  networkStatus,
  getBlock,
  getTransaction,
  webFetch,
  webSearch,
  time,
  cryptoNewPools,
  cryptoTrending,
  cryptoSearchToken,
  cryptoTokenOverview,
  cryptoTokenSecurity,
  cryptoTokenHolders,
  cryptoTokenTrades,
  cryptoGemScan,
  mineStart,
  mineStop,
  mineStatus,
];

/** All first-party capability tool names (stable list for the host + tests). */
export const CAPABILITY_NAMES: string[] = CAPABILITIES.map((c) => c.def.name);

/** Build the first-party capability tool source over a host's primitives. The
 *  host merges `defs` into `listTools` and routes any `has(name)` call to
 *  `call(...)`; everything else falls through to the remote (mcp/httptool)
 *  layer. Runs identically on desktop and mobile. */
export function capabilityTools(
  bridge: HostBridge,
  opts?: CapabilityOpts,
): {
  defs: ToolDef[];
  has(name: string): boolean;
  call(name: string, args: Record<string, unknown>): Promise<AgentToolResult>;
} {
  const byName = new Map(CAPABILITIES.map((c) => [c.def.name, c]));
  return {
    defs: CAPABILITIES.map((c) => c.def),
    has: (name) => byName.has(name),
    call: (name, args) => {
      const c = byName.get(name);
      return c ? c.run(args ?? {}, bridge, opts) : Promise.resolve(fail(`unknown capability: ${name}`));
    },
  };
}

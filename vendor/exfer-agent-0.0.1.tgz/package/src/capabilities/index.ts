// First-party capability tools for the in-wallet agent.
//
// These are Exfer's OWN capabilities (price, chain explorer, web read/search,
// time, mining) — implemented ONCE here and shared by both apps. They are NOT
// third-party marketplace tools (those are remote URLs handled by the host's
// mcp/httptool layer). Nothing new is served: everything runs on plumbing the
// app ALREADY reaches, via a small injected HostBridge:
//
//   - rpc()       → walletd JSON-RPC (loopback): chain + pool reads
//   - command()   → a native host command (Tauri invoke): get_bnb_price, mine_*
//   - fetchText() → CORS-free HTTPS through the host (Rust): read the public web
//
// So `exfer_price` reuses the pool's `swap_price_klines` + Binance BNB/USD
// (`get_bnb_price`), the explorer tools reuse walletd's node RPC, and `web_*`
// hit the public internet directly. No `tools.exfer.dev`, no serverless shim.
// The agent core stays transport-agnostic; the host supplies the 3 primitives.

import type { AgentToolResult } from "../agent/session.ts";
import type { ToolDef } from "../types.ts";

/** The 3 primitives a host provides so first-party tools can reach existing
 *  plumbing. Desktop/mobile wrap Tauri `invoke`; browser-dev wraps proxies. */
export interface HostBridge {
  /** walletd JSON-RPC (loopback), e.g. `swap_price_klines`, `get_status`. */
  rpc<T = unknown>(method: string, params?: Record<string, unknown>): Promise<T>;
  /** A native host command (Tauri), e.g. `get_bnb_price`, `mine_start`. */
  command<T = unknown>(name: string, args?: Record<string, unknown>): Promise<T>;
  /** CORS-free HTTPS through the host (Rust), for reading the public web. */
  fetchText(
    url: string,
    init?: { method?: string; body?: string; headers?: Record<string, string> },
  ): Promise<{ status: number; body: string }>;
}

/** Which web-search backend web_search should use. The HOST resolves the
 *  effective provider + key (user's own key, else a built-in default) and passes
 *  it in; exfer-agent stays keyless itself. "free" (or no key) = the keyless
 *  DuckDuckGo -> Wikipedia cascade. A paid provider that errors falls back to
 *  the free cascade so search never hard-fails. */
export interface SearchConfig {
  provider?: "tavily" | "brave" | "free";
  apiKey?: string;
}
export interface CapabilityOpts {
  search?: SearchConfig;
}

interface Capability {
  def: ToolDef;
  run(args: Record<string, unknown>, bridge: HostBridge, opts?: CapabilityOpts): Promise<AgentToolResult>;
}

const EXFER_UNIT = 100_000_000; // 1 EXFER = 1e8 exfers
const HALF_LIFE = 6_307_200; // blocks (~2 years at 10s) — matches the node

function ok(v: unknown): AgentToolResult {
  return { content: typeof v === "string" ? v : JSON.stringify(v), isError: false };
}
function fail(msg: string): AgentToolResult {
  return { content: msg, isError: true };
}

/** Total EXFER emitted through `height`: perpetual 1-EXFER tail + a decaying
 *  99-EXFER bonus (closed form, same curve as the desktop dashboard). */
function circulatingSupplyExfer(height: number): number {
  if (!isFinite(height) || height < 0) return 0;
  const n = height + 1;
  const r = Math.pow(2, -1 / HALF_LIFE);
  return n + 99 * ((1 - Math.pow(r, n)) / (1 - r));
}

function htmlToText(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, " ")
    .trim();
}

// ── price: pool klines (USD close) + Binance BNB/USD + closed-form supply ────
const price: Capability = {
  def: {
    name: "exfer_price",
    description:
      "Current EXFER market price and market cap. Returns USD per EXFER (from the swap pool's own price history), 24h change, the BNB/USD anchor, circulating supply, and market cap. Read-only, no key. Use whenever the user asks what EXFER is worth.",
    parameters: { type: "object", properties: {} },
  },
  async run(_args, bridge) {
    try {
      const kl = await bridge.rpc<{ items?: { c: number | string }[] }>("swap_price_klines", {
        interval: "1d",
        limit: 2,
      });
      const items = Array.isArray(kl?.items) ? kl.items : [];
      const usd = items.length ? Number(items[items.length - 1].c) : NaN;
      if (!isFinite(usd) || usd <= 0) {
        return fail("EXFER price is unavailable right now (the pool returned no price).");
      }
      const prev = items.length >= 2 ? Number(items[items.length - 2].c) : usd;
      const change24h = isFinite(prev) && prev > 0 ? ((usd - prev) / prev) * 100 : 0;

      let bnbUsd: number | null = null;
      try {
        const raw = await bridge.command<string>("get_bnb_price");
        const p = Number((JSON.parse(raw) as { price?: string }).price);
        bnbUsd = isFinite(p) && p > 0 ? p : null;
      } catch {
        /* best-effort anchor */
      }
      let supply: number | null = null;
      try {
        const h = await bridge.rpc<{ height?: number }>("get_block_height");
        if (typeof h?.height === "number") supply = circulatingSupplyExfer(h.height);
      } catch {
        /* best-effort */
      }
      return ok({
        usd_per_exfer: usd,
        change_24h_pct: Number(change24h.toFixed(2)),
        bnb_usd: bnbUsd,
        circulating_supply_exfer: supply != null ? Math.round(supply) : null,
        market_cap_usd: supply != null ? Math.round(supply * usd) : null,
        unit_note: "1 EXFER = 1e8 base exfers",
        _unit: EXFER_UNIT,
      });
    } catch (e) {
      return fail(`price lookup failed: ${String(e)}`);
    }
  },
};

// ── explorer: raw pass-through of walletd node RPC (no reshaping guesswork) ──
const networkStatus: Capability = {
  def: {
    name: "exfer_network_status",
    description:
      "EXFER network status from the node: chain tip height, difficulty, and chain/node info. Read-only. Use for questions about the EXFER chain itself (how many blocks, current difficulty/hashrate).",
    parameters: { type: "object", properties: {} },
  },
  async run(_a, bridge) {
    try {
      return ok(await bridge.rpc("get_status"));
    } catch (e) {
      return fail(`network status failed: ${String(e)}`);
    }
  },
};

const getBlock: Capability = {
  def: {
    name: "exfer_get_block",
    description: "Look up an EXFER block by height or by block id/hash. Read-only explorer.",
    parameters: {
      type: "object",
      properties: {
        height: { type: "number", description: "Block height." },
        id: { type: "string", description: "Block id/hash (hex)." },
      },
    },
  },
  async run(args, bridge) {
    try {
      if (typeof args.height === "number") {
        return ok(await bridge.rpc("get_block_by_height", { height: args.height }));
      }
      if (args.id) return ok(await bridge.rpc("get_block_by_id", { block_id: String(args.id) }));
      return fail("exfer_get_block needs a height or an id.");
    } catch (e) {
      return fail(`get_block failed: ${String(e)}`);
    }
  },
};

const getTransaction: Capability = {
  def: {
    name: "exfer_get_transaction",
    description:
      "Look up an EXFER transaction by tx id (searches the mempool first, then the confirmed chain). Read-only explorer.",
    parameters: {
      type: "object",
      properties: { tx_id: { type: "string", description: "Transaction id (hex)." } },
      required: ["tx_id"],
    },
  },
  async run(args, bridge) {
    try {
      return ok(await bridge.rpc("get_transaction", { tx_id: String(args.tx_id ?? args.id ?? "") }));
    } catch (e) {
      return fail(`get_transaction failed: ${String(e)}`);
    }
  },
};

// ── web: read any public page / search (keyless, host-side HTTPS) ────────────
const webFetch: Capability = {
  def: {
    name: "web_fetch",
    description:
      "Fetch a public web page or JSON API by URL and return its text (HTML stripped, truncated). Read-only, runs host-side (works on desktop and mobile, no CORS). Use to read a specific page, article, forum thread (e.g. a bitcointalk topic), or API the user references.",
    parameters: {
      type: "object",
      properties: { url: { type: "string", description: "The https URL to fetch." } },
      required: ["url"],
    },
  },
  async run(args, bridge) {
    const url = String(args.url ?? "").trim();
    if (!/^https?:\/\//i.test(url)) return fail("web_fetch needs an http(s) URL.");
    try {
      const r = await bridge.fetchText(url, { headers: { "user-agent": "Mozilla/5.0 (exfer-agent)" } });
      if (r.status >= 400) return fail(`web_fetch got HTTP ${r.status} for ${url}`);
      // Strip HTML for full documents AND fragments (e.g. a bare <table> of
      // <td>/<tr>): a doc marker in the head, or several closing tags anywhere,
      // means it's markup the user shouldn't see raw. JSON/plain text (no tag
      // soup) passes through untouched.
      const head = r.body.slice(0, 500);
      const closingTags = r.body.match(/<\/[a-z][a-z0-9]*>/gi)?.length ?? 0;
      const looksHtml = /<html|<body|<!doctype|<head/i.test(head) || closingTags >= 3;
      const text = looksHtml ? htmlToText(r.body) : r.body;
      const MAX = 12000;
      return ok({ url, status: r.status, truncated: text.length > MAX, text: text.slice(0, MAX) });
    } catch (e) {
      return fail(`web_fetch failed: ${String(e)}`);
    }
  },
};

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

/** Unwrap DuckDuckGo's `//duckduckgo.com/l/?uddg=<encoded>` redirect wrapper to
 *  the real destination, and protocol-relative `//host` to https. */
function unwrapDdgHref(href: string): string {
  const uddg = /[?&]uddg=([^&]+)/.exec(href);
  if (uddg) {
    try {
      return decodeURIComponent(uddg[1]);
    } catch {
      /* keep raw */
    }
  }
  return href.startsWith("//") ? `https:${href}` : href;
}

/** Parse DuckDuckGo's Instant Answer JSON (stable, documented, keyless). Covers
 *  entity/definition queries: an Abstract plus a flat list of RelatedTopics.
 *  Returns [] for queries with no instant answer (the caller then falls back). */
interface DdgIa {
  Heading?: string;
  AbstractText?: string;
  AbstractURL?: string;
  RelatedTopics?: unknown[];
}
function parseInstantAnswer(j: DdgIa): SearchResult[] {
  const out: SearchResult[] = [];
  if (j.AbstractText && j.AbstractURL) {
    out.push({ title: j.Heading ?? "", url: j.AbstractURL, snippet: j.AbstractText });
  }
  const walk = (arr: unknown[]): void => {
    for (const t of arr) {
      const o = t as { Topics?: unknown[]; FirstURL?: string; Text?: string };
      if (Array.isArray(o.Topics)) walk(o.Topics);
      else if (o.FirstURL) {
        out.push({ title: (o.Text ?? "").split(" - ")[0], url: o.FirstURL, snippet: o.Text ?? "" });
      }
    }
  };
  if (Array.isArray(j.RelatedTopics)) walk(j.RelatedTopics);
  return out;
}

/** Parse the `lite.duckduckgo.com/lite/` results page — a minimal HTML table
 *  designed for old browsers, far more stable than the full search page. */
function parseDdgLite(html: string): SearchResult[] {
  const out: SearchResult[] = [];
  const re = /<a[^>]+class="result-link"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html)) && out.length < 12) {
    out.push({ title: htmlToText(m[2]), url: unwrapDdgHref(m[1]), snippet: "" });
  }
  const snips: string[] = [];
  const sre = /class="result-snippet"[^>]*>([\s\S]*?)<\/td>/gi;
  let sm: RegExpExecArray | null;
  while ((sm = sre.exec(html)) && snips.length < out.length) snips.push(htmlToText(sm[1]));
  out.forEach((r, i) => {
    if (snips[i]) r.snippet = snips[i];
  });
  return out;
}

/** Parse Wikipedia's REST search (`/w/rest.php/v1/search/page`) — a reliable,
 *  keyless, structured source that is never bot-challenged. Good coverage for
 *  entity/concept queries (coins, protocols, people); not general web/news. */
interface WikiSearch {
  pages?: { title?: string; key?: string; excerpt?: string; description?: string }[];
}
function parseWikipedia(j: WikiSearch): SearchResult[] {
  return (j.pages ?? [])
    .map((p) => ({
      title: p.title ?? p.key ?? "",
      url: p.key ? `https://en.wikipedia.org/wiki/${encodeURIComponent(p.key)}` : "",
      snippet: htmlToText(p.excerpt ?? p.description ?? ""),
    }))
    .filter((r) => r.url);
}

/** Tavily — the agent-purpose-built search API; returns LLM-ready results.
 *  POST https://api.tavily.com/search with a Bearer key. */
async function tavilySearch(bridge: HostBridge, query: string, apiKey: string): Promise<SearchResult[]> {
  const r = await bridge.fetchText("https://api.tavily.com/search", {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ query, max_results: 8, search_depth: "basic" }),
  });
  if (r.status >= 400 || !r.body.trim()) throw new Error(`tavily HTTP ${r.status}`);
  const j = JSON.parse(r.body) as { results?: { title?: string; url?: string; content?: string }[] };
  return (j.results ?? [])
    .filter((x) => x.url)
    .slice(0, 8)
    .map((x) => ({ title: String(x.title ?? x.url), url: String(x.url), snippet: String(x.content ?? "") }));
}

/** Brave Search API — an independent web index. GET with an X-Subscription-Token. */
async function braveSearch(bridge: HostBridge, query: string, apiKey: string): Promise<SearchResult[]> {
  const r = await bridge.fetchText(
    `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=8`,
    { headers: { accept: "application/json", "x-subscription-token": apiKey } },
  );
  if (r.status >= 400 || !r.body.trim()) throw new Error(`brave HTTP ${r.status}`);
  const j = JSON.parse(r.body) as { web?: { results?: { title?: string; url?: string; description?: string }[] } };
  return (j.web?.results ?? [])
    .filter((x) => x.url)
    .slice(0, 8)
    .map((x) => ({ title: String(x.title ?? x.url), url: String(x.url), snippet: String(x.description ?? "") }));
}

const webSearch: Capability = {
  def: {
    name: "web_search",
    description:
      "Search the public web and return the top results (title, url, snippet). Keyless, runs host-side. Use for current information: news, other coins' prices, forum posts (e.g. bitcointalk), docs. For a specific known URL, use web_fetch instead.",
    parameters: {
      type: "object",
      properties: { query: { type: "string", description: "The search query." } },
      required: ["query"],
    },
  },
  async run(args, bridge, opts) {
    const q = String(args.query ?? "").trim();
    if (!q) return fail("web_search needs a query.");
    const enc = encodeURIComponent(q);

    // Preferred: a configured search API. The host resolves the effective
    // provider + key (the user's own key, else a built-in default). On ANY
    // error we fall through to the free cascade below, so search never
    // hard-fails and a bad/expired key degrades gracefully.
    const sc = opts?.search;
    if (sc?.apiKey && (sc.provider === "tavily" || sc.provider === "brave")) {
      try {
        const results =
          sc.provider === "tavily"
            ? await tavilySearch(bridge, q, sc.apiKey)
            : await braveSearch(bridge, q, sc.apiKey);
        if (results.length) return ok({ query: q, source: sc.provider, results });
      } catch {
        /* fall through to the keyless cascade */
      }
    }

    // Cascade keyless sources; return the first that yields results. On a user's
    // device DuckDuckGo usually answers (general web); some networks bot-challenge
    // it (empty/202 body), so Wikipedia is a reliable structured floor for
    // entity/concept queries. web_fetch covers any specific URL beyond these.

    // 1. DuckDuckGo Instant Answer JSON (structured, stable shape).
    try {
      const ia = await bridge.fetchText(
        `https://api.duckduckgo.com/?q=${enc}&format=json&no_html=1&no_redirect=1&t=exfer-agent`,
        { headers: { "user-agent": "Mozilla/5.0 (exfer-agent)" } },
      );
      if (ia.status < 400 && ia.body.trim()) {
        const results = parseInstantAnswer(JSON.parse(ia.body) as DdgIa).slice(0, 8);
        if (results.length) return ok({ query: q, source: "duckduckgo-instant-answer", results });
      }
    } catch {
      /* next source */
    }
    // 2. DuckDuckGo lite (minimal, stable HTML) for general web results.
    try {
      const r = await bridge.fetchText(`https://lite.duckduckgo.com/lite/?q=${enc}`, {
        headers: { "user-agent": "Mozilla/5.0 (exfer-agent)" },
      });
      if (r.status < 400) {
        const results = parseDdgLite(r.body).slice(0, 8);
        if (results.length) return ok({ query: q, source: "duckduckgo-lite", results });
      }
    } catch {
      /* next source */
    }
    // 3. Wikipedia REST search (reliable, keyless, never bot-challenged).
    try {
      const w = await bridge.fetchText(
        `https://en.wikipedia.org/w/rest.php/v1/search/page?q=${enc}&limit=8`,
        { headers: { "user-agent": "exfer-agent/0.1 (in-wallet assistant; https://exfer.dev)" } },
      );
      if (w.status < 400) {
        const results = parseWikipedia(JSON.parse(w.body) as WikiSearch).slice(0, 8);
        if (results.length) return ok({ query: q, source: "wikipedia", results });
      }
    } catch {
      /* fall through to the empty note */
    }
    return ok({
      query: q,
      results: [],
      note: "No results from keyless search sources right now. Try web_fetch on a specific URL.",
    });
  },
};

const time: Capability = {
  def: {
    name: "time",
    description: "The current date and time (device clock: UTC + local + unix seconds). Read-only.",
    parameters: { type: "object", properties: {} },
  },
  async run() {
    const now = new Date();
    return ok({
      iso_utc: now.toISOString(),
      unix_seconds: Math.floor(now.getTime() / 1000),
      local: now.toString(),
    });
  },
};

// ── mining: native in-app miner (migrated here from each app's agentHost) ────
function miner(name: string, cmd: string, description: string, params: Record<string, unknown>): Capability {
  return {
    def: { name, description, parameters: params },
    async run(args, bridge) {
      try {
        return ok(await bridge.command(cmd, args));
      } catch (e) {
        return fail(`miner error: ${String(e)}`);
      }
    },
  };
}

const mineStart = miner(
  "exfer_mine_start",
  "mine_start",
  "Start mining EXFER on this device's CPU, paying out to your address. Defaults to the SOLO pool (full block reward to you; no shared-pool threshold). Uses CPU. Generate an address first with exfer_generate_address.",
  {
    type: "object",
    properties: {
      address: { type: "string", description: "Your 64-hex payout address." },
      pool: { type: "string", description: "Optional stratum pool URL (ssl://host:port). Default: the solo pool." },
      threads: { type: "number", description: "CPU threads (1-4). Default 1 — Argon2id is memory-hard." },
    },
    required: ["address"],
  },
);
const mineStop = miner("exfer_mine_stop", "mine_stop", "Stop the in-app miner.", {
  type: "object",
  properties: {},
});
const mineStatus = miner(
  "exfer_mine_status",
  "mine_status",
  "Current in-app miner status: running, hashrate, shares accepted/rejected, pool authorization, uptime.",
  { type: "object", properties: {} },
);

const CAPABILITIES: Capability[] = [
  price,
  networkStatus,
  getBlock,
  getTransaction,
  webFetch,
  webSearch,
  time,
  mineStart,
  mineStop,
  mineStatus,
];

/** All first-party capability tool names (stable list for the host + tests). */
export const CAPABILITY_NAMES: string[] = CAPABILITIES.map((c) => c.def.name);

/** Build the first-party capability tool source over a host's primitives. The
 *  host merges `defs` into `listTools` and routes any `has(name)` call to
 *  `call(...)`; everything else falls through to the remote (mcp/httptool)
 *  layer. Runs identically on desktop and mobile. */
export function capabilityTools(
  bridge: HostBridge,
  opts?: CapabilityOpts,
): {
  defs: ToolDef[];
  has(name: string): boolean;
  call(name: string, args: Record<string, unknown>): Promise<AgentToolResult>;
} {
  const byName = new Map(CAPABILITIES.map((c) => [c.def.name, c]));
  return {
    defs: CAPABILITIES.map((c) => c.def),
    has: (name) => byName.has(name),
    call: (name, args) => {
      const c = byName.get(name);
      return c ? c.run(args ?? {}, bridge, opts) : Promise.resolve(fail(`unknown capability: ${name}`));
    },
  };
}

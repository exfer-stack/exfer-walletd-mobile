// Consent policy for exfer tools.
//
// The agent gets tool *schemas* at runtime from exfer-mcp (the app injects
// `listTools`), so this file holds only the SECURITY POLICY: which tools move
// funds / sign value and therefore need explicit user consent (biometric on
// mobile, passphrase/OS auth on desktop) before they run. The 35 exfer-mcp
// tools split three ways.

export type ConsentClass = "auto" | "gated" | "earn";

/** A consent policy: explicit per-tool class + a fail-closed default for tools
 *  the policy doesn't recognize. This is what makes the agent multi-source — the
 *  host can build one policy per MCP server / skill and merge them, so tools the
 *  core has never heard of are still classified (unknown → the strict default).
 */
export interface ToolPolicy {
  classes: Record<string, ConsentClass>;
  /** Class for an unrecognized tool. Keep "gated" for any source that can move
   *  funds, so a newly added write tool asks for consent instead of running. */
  default: ConsentClass;
}

/** Tools that move funds or sign a value-bearing credential — require consent. */
const GATED = new Set<string>([
  "exfer_transfer",
  "exfer_swap_execute",
  "exfer_htlc_lock",
  "exfer_htlc_claim",
  "exfer_htlc_reclaim",
  "exfer_quote_issue", // signs a value credential (Spend scope)
  "exfer_sign_message", // value-bearing proof of ownership (Spend scope)
  "exfer_swap_refund",
]);

/** Mining — confirm once to start, then runs in the background. */
// exfer_mine_* are native in-app miner commands (mobile), injected by the host
// alongside the exfer-mcp tools. Starting the miner spends CPU/battery, so it is
// consent-gated like exfer_earn; stop/status are read-only.
const EARN = new Set<string>(["exfer_earn", "exfer_earn_probe", "exfer_earn_status", "exfer_earn_stop", "exfer_mine_start"]);

/** Read-only tools — safe to run without a prompt. */
const KNOWN_AUTO = new Set<string>([
  "exfer_get_balance",
  "exfer_get_block_height",
  "exfer_list_addresses",
  "exfer_generate_address",
  "exfer_get_address_history",
  "exfer_get_output_datum",
  "exfer_find_settlements_by_quote_id",
  "exfer_simulate_transfer",
  "exfer_quote_verify",
  "exfer_swap_pool_info",
  "exfer_swap_get_quote",
  "exfer_swap_status",
  "exfer_swap_list",
  "exfer_htlc_status",
  "exfer_htlc_list",
  "exfer_wait_for_tx",
  "exfer_wait_for_payment",
  "exfer_payment_uri_encode",
  "exfer_payment_uri_decode",
  "exfer_verify_message",
  "exfer_bsc_get_address",
  "exfer_bsc_get_balance",
  "exfer_check_update",
  // Read-only network/explorer data (node JSON-RPC): status, hashrate estimate,
  // and explorer-grade lookup of any block/tx. No funds, no signing.
  "exfer_network_status",
  "exfer_network_hashrate",
  "exfer_get_block",
  "exfer_get_transaction",
  // Read-only mining-pool stats (pool's public stats API): accrued unpaid
  // balance, payout threshold, hashrate, online status. No funds, no signing.
  "exfer_earn_pool_stats",
  // Native in-app miner controls (mobile): stop + status are read-only/safe.
  "exfer_mine_stop",
  "exfer_mine_status",
  // First-party capability tools (host-side, no funds/signing): market price,
  // and reading the public web. Public reads — safe to run without a prompt.
  "exfer_price",
  "web_fetch",
  "web_search",
  "time",
  // Crypto discovery (public DEX/security APIs, read-only): new/trending pools,
  // token overview, safety check, and the fused gem scan. No funds, no signing.
  "crypto_new_pools",
  "crypto_trending",
  "crypto_search_token",
  "crypto_token_overview",
  "crypto_token_security",
  "crypto_token_holders",
  "crypto_token_trades",
  "crypto_gem_scan",
]);

/** The built-in policy for exfer-mcp's tools. Fail-closed: an unrecognized tool
 *  defaults to "gated". Used when the host injects no policy. */
export const EXFER_POLICY: ToolPolicy = {
  classes: {
    ...Object.fromEntries([...GATED].map((n) => [n, "gated" as ConsentClass])),
    ...Object.fromEntries([...EARN].map((n) => [n, "earn" as ConsentClass])),
    ...Object.fromEntries([...KNOWN_AUTO].map((n) => [n, "auto" as ConsentClass])),
  },
  default: "gated",
};

const STRICTNESS: Record<ConsentClass, number> = { auto: 0, earn: 1, gated: 2 };

/** Merge per-source policies (one per MCP server / skill) into one. Tool classes
 *  union (later sources win on conflict); the merged default is the STRICTEST of
 *  the sources' defaults, so adding any fund-moving source keeps unknown tools
 *  gated. With no sources, defaults to gated (fail-closed). */
export function mergePolicies(...policies: ToolPolicy[]): ToolPolicy {
  if (policies.length === 0) return { classes: {}, default: "gated" };
  const classes: Record<string, ConsentClass> = {};
  let def: ConsentClass = "auto";
  for (const p of policies) {
    Object.assign(classes, p.classes);
    if (STRICTNESS[p.default] > STRICTNESS[def]) def = p.default;
  }
  return { classes, default: def };
}

/** Resolve a tool's consent class against a policy (default = the exfer policy).
 *  Unknown tools fall to the policy's fail-closed default. */
export function consentClassFor(toolName: string, policy: ToolPolicy = EXFER_POLICY): ConsentClass {
  return policy.classes[toolName] ?? policy.default;
}

/** How the UI should render a field's value. `amount` = money-format + unit
 *  (value is base exfers); `address` = full, wrappable, copyable. */
export type ConsentFieldKind = "text" | "amount" | "address";

export interface ConsentField {
  label: string;
  value: string;
  /** Stable token; host resolves `t(\`agent.consent.field.${labelKey}\`)`, falling back to `label`. */
  labelKey?: string;
  kind?: ConsentFieldKind;
}

/** A human-readable confirmation card, built from the tool name + args. The
 *  English `title`/`label`s are always present as a fallback; the host localizes
 *  via the `titleKey`/`labelKey` tokens so the money decision reads in the
 *  user's language. */
export interface ConsentCard {
  toolName: string;
  title: string;
  /** Stable token; host resolves `t(\`agent.consent.title.${titleKey}\`)`, falling back to `title`. */
  titleKey?: string;
  fields: ConsentField[];
  consentClass: ConsentClass;
}

function s(v: unknown): string {
  if (v == null) return "";
  return typeof v === "string" ? v : JSON.stringify(v);
}

/**
 * Turn a gated tool call into a confirmation card. Falls back to a generic
 * args dump for tools without a bespoke renderer — so a new gated tool still
 * surfaces a card (just less pretty) rather than running silently.
 */
export function consentCardFor(toolName: string, args: Record<string, unknown>): ConsentCard {
  const cls = consentClassFor(toolName);
  switch (toolName) {
    case "exfer_transfer":
      // exfer-mcp arg names: to_address / amount (base exfers) / fee.
      return {
        toolName,
        title: "Confirm transfer",
        titleKey: "transfer",
        consentClass: cls,
        fields: [
          { label: "To", labelKey: "to", kind: "address", value: s(args.to_address ?? args.to ?? args.recipient) },
          { label: "Amount", labelKey: "amount", kind: "amount", value: s(args.amount ?? args.exfer_amount) },
          { label: "Fee", labelKey: "fee", kind: "amount", value: s(args.fee ?? args.fee_rate) },
        ],
      };
    case "exfer_swap_execute":
      // Only swap_id is in the args; the host enriches with the quote economics
      // (direction / pay / receive / fee) it saw on the preceding get_quote.
      return {
        toolName,
        title: "Confirm swap",
        titleKey: "swap",
        consentClass: cls,
        fields: [{ label: "Swap id", labelKey: "swap_id", value: s(args.swap_id) }],
      };
    case "exfer_htlc_lock":
      return {
        toolName,
        title: "Confirm HTLC lock",
        titleKey: "htlc_lock",
        consentClass: cls,
        fields: [
          { label: "Amount", labelKey: "amount", kind: "amount", value: s(args.amount) },
          { label: "Counterparty", labelKey: "counterparty", kind: "address", value: s(args.receiver ?? args.counterparty) },
          { label: "Timeout height", labelKey: "timeout_height", value: s(args.timeout ?? args.timeout_height) },
        ],
      };
    case "exfer_htlc_claim":
      // Claims a locked HTLC into `from`. NEVER surface the preimage on the
      // money sheet — it is the spending secret; the user is approving the claim,
      // not auditing the secret.
      return {
        toolName,
        title: "Confirm HTLC claim",
        titleKey: "htlc_claim",
        consentClass: cls,
        fields: [
          { label: "Lock tx", labelKey: "lock_tx_id", value: s(args.lock_tx_id ?? args.lock_tx) },
          { label: "Claim to", labelKey: "from", kind: "address", value: s(args.from) },
        ],
      };
    case "exfer_htlc_reclaim":
      // Reclaims a timed-out HTLC back to `from` after `timeout` height.
      return {
        toolName,
        title: "Confirm HTLC reclaim",
        titleKey: "htlc_reclaim",
        consentClass: cls,
        fields: [
          { label: "Lock tx", labelKey: "lock_tx_id", value: s(args.lock_tx_id ?? args.lock_tx) },
          { label: "Reclaim to", labelKey: "from", kind: "address", value: s(args.from) },
          { label: "Timeout height", labelKey: "timeout_height", value: s(args.timeout ?? args.timeout_height) },
        ],
      };
    case "exfer_swap_refund":
      // Mirrors exfer_swap_execute: only the swap_id is in args; the host may
      // enrich with the original swap economics it saw earlier.
      return {
        toolName,
        title: "Confirm swap refund",
        titleKey: "swap_refund",
        consentClass: cls,
        fields: [{ label: "Swap id", labelKey: "swap_id", value: s(args.swap_id) }],
      };
    case "exfer_quote_issue":
      return {
        toolName,
        title: "Sign a price quote",
        titleKey: "quote_issue",
        consentClass: cls,
        fields: [
          { label: "Payee", labelKey: "payee", kind: "address", value: s(args.payee_pubkey) },
          { label: "EXFER amount", labelKey: "amount", kind: "amount", value: s(args.exfer_amount) },
          { label: "Currency", labelKey: "currency", value: s(args.currency) },
        ],
      };
    case "exfer_sign_message":
      return {
        toolName,
        title: "Sign a message (proof of ownership)",
        titleKey: "sign",
        consentClass: cls,
        fields: [{ label: "Message", labelKey: "message", value: s(args.message) }],
      };
    case "exfer_earn":
      return {
        toolName,
        title: "Start mining EXFER",
        titleKey: "earn",
        consentClass: cls,
        fields: [{ label: "Note", labelKey: "earn_note", value: "Uses CPU/battery; pays out to your address." }],
      };
    case "exfer_mine_start":
      return {
        toolName,
        title: "Start mining EXFER",
        titleKey: "earn",
        consentClass: cls,
        fields: [
          { label: "Pool", labelKey: "pool", value: s(args.pool ?? "solo pool (default)") },
          { label: "Payout to", labelKey: "from", value: s(args.address) },
          { label: "Note", labelKey: "earn_note", value: "Uses CPU/battery; pays out to your address." },
        ],
      };
    default:
      return {
        toolName,
        title: `Confirm ${toolName}`,
        consentClass: cls,
        fields: Object.entries(args).map(([k, v]) => ({ label: k, value: s(v) })),
      };
  }
}

// Provider layer — implemented on the Vercel AI SDK (v6).
//
// One unified `LLMProvider.stream()` over `streamText().fullStream`, for both
// the openai-compatible wire format (DeepSeek, OpenRouter, Groq, Ollama, … —
// anything exposing /chat/completions) and Anthropic. Tools are passed WITHOUT
// an `execute` fn so the SDK surfaces each tool call back to `AgentSession`,
// which applies the consent policy before the host executes it. The host
// injects a custom `fetch` (Tauri HTTP) to bypass webview CORS.

import { streamText, tool, jsonSchema } from "ai";
import type { ModelMessage, LanguageModel, ToolSet } from "ai";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { createAnthropic } from "@ai-sdk/anthropic";
import type {
  ChatMessage,
  FetchLike,
  LLMProvider,
  ProviderConfig,
  ProviderKind,
  StreamEvent,
  StreamParams,
  ToolDef,
} from "../types.ts";

function buildModel(cfg: ProviderConfig, fetchImpl: FetchLike): LanguageModel {
  if (cfg.kind === "anthropic") {
    const anthropic = createAnthropic({
      apiKey: cfg.apiKey,
      baseURL: cfg.baseUrl || undefined,
      fetch: fetchImpl,
    });
    return anthropic(cfg.model);
  }
  const provider = createOpenAICompatible({
    name: cfg.id || "user-endpoint",
    baseURL: cfg.baseUrl,
    apiKey: cfg.apiKey,
    fetch: fetchImpl,
  });
  return provider(cfg.model);
}

function toModelMessages(msgs: ChatMessage[]): ModelMessage[] {
  return msgs.map((m): ModelMessage => {
    if (m.role === "user") {
      return { role: "user", content: m.content };
    }
    if (m.role === "assistant") {
      const parts: Array<
        { type: "text"; text: string } | { type: "tool-call"; toolCallId: string; toolName: string; input: unknown }
      > = [];
      if (m.content) parts.push({ type: "text", text: m.content });
      for (const c of m.toolCalls ?? []) {
        parts.push({ type: "tool-call", toolCallId: c.id, toolName: c.name, input: c.args });
      }
      return { role: "assistant", content: parts };
    }
    // tool result
    return {
      role: "tool",
      content: [
        { type: "tool-result", toolCallId: m.toolCallId, toolName: m.name, output: { type: "text", value: m.content } },
      ],
    };
  });
}

// Permissive output schema: tool results come back as arbitrary JSON/text from
// exfer-mcp, so we don't constrain them.
const ANY_OUTPUT = jsonSchema<unknown>({});

function toAiTools(tools?: ToolDef[]): ToolSet | undefined {
  if (!tools?.length) return undefined;
  const out: ToolSet = {};
  for (const t of tools) {
    // No `execute`: streamText emits the tool-call and stops the step, so
    // AgentSession can consent-gate and run it via the injected executeTool.
    // v6 requires an `outputSchema` on a no-execute (app-side) tool.
    out[t.name] = tool({
      description: t.description,
      inputSchema: jsonSchema(t.parameters as Record<string, unknown>),
      outputSchema: ANY_OUTPUT,
    });
  }
  return out;
}

function mapFinish(r: string): "end_turn" | "tool_use" | "max_tokens" | "refusal" | "other" {
  switch (r) {
    case "stop":
      return "end_turn";
    case "tool-calls":
      return "tool_use";
    case "length":
      return "max_tokens";
    case "content-filter":
      return "refusal";
    default:
      return "other";
  }
}

function errMsg(e: unknown): string {
  if (e instanceof Error) return e.message;
  if (typeof e === "string") return e;
  try {
    return JSON.stringify(e);
  } catch {
    return String(e);
  }
}

export function createProvider(cfg: ProviderConfig, fetchImpl: FetchLike = fetch): LLMProvider {
  return {
    kind: cfg.kind,
    async *stream(params: StreamParams): AsyncIterable<StreamEvent> {
      let result: ReturnType<typeof streamText>;
      try {
        result = streamText({
          model: buildModel(cfg, fetchImpl),
          system: params.system,
          messages: toModelMessages(params.messages),
          tools: toAiTools(params.tools),
          maxOutputTokens: params.maxTokens,
          abortSignal: params.signal,
        });
      } catch (e) {
        yield { type: "error", message: errMsg(e) };
        return;
      }

      try {
        for await (const part of result.fullStream) {
          switch (part.type) {
            case "reasoning-delta":
              yield { type: "thinking_delta", text: part.text };
              break;
            case "text-delta":
              yield { type: "text_delta", text: part.text };
              break;
            case "tool-call":
              yield {
                type: "tool_call",
                call: {
                  id: part.toolCallId,
                  name: part.toolName,
                  args: (part.input ?? {}) as Record<string, unknown>,
                },
              };
              break;
            case "finish":
              yield {
                type: "done",
                stopReason: mapFinish(part.finishReason),
                usage: { inputTokens: part.totalUsage?.inputTokens, outputTokens: part.totalUsage?.outputTokens },
              };
              break;
            case "error":
              yield { type: "error", message: errMsg(part.error) };
              return;
          }
        }
      } catch (e) {
        yield { type: "error", message: errMsg(e) };
      }
    },
  };
}

/**
 * Presets to seed the config UI. `kind` picks the wire format; the user supplies
 * their own apiKey (and may override baseUrl/model). The openai-compatible kind
 * covers the long tail — anything exposing /chat/completions.
 */
export interface ProviderPreset {
  /** English label; always present as a fallback. */
  label: string;
  /** Stable token the host resolves via its own t() (falling back to `label`).
   *  Only set where the label is non-proper-noun prose that needs translating
   *  (e.g. "Ollama (local)" → "Ollama（本地）"); brand names omit it. */
  labelKey?: string;
  kind: ProviderKind;
  baseUrl: string;
  defaultModel: string;
  /** English note; always present as a fallback. */
  note?: string;
  /** Stable token the host resolves via its own t() (falling back to `note`).
   *  Core only emits the key; per-app i18n owns the ZH string. */
  noteKey?: string;
}

export const PROVIDER_PRESETS: ProviderPreset[] = [
  { label: "DeepSeek", kind: "openai", baseUrl: "https://api.deepseek.com", defaultModel: "deepseek-chat" },
  { label: "OpenAI", kind: "openai", baseUrl: "https://api.openai.com/v1", defaultModel: "gpt-4o" },
  { label: "OpenRouter", kind: "openai", baseUrl: "https://openrouter.ai/api/v1", defaultModel: "anthropic/claude-sonnet-4.6" },
  { label: "Groq", kind: "openai", baseUrl: "https://api.groq.com/openai/v1", defaultModel: "llama-3.3-70b-versatile" },
  { label: "Together", kind: "openai", baseUrl: "https://api.together.xyz/v1", defaultModel: "meta-llama/Llama-3.3-70B-Instruct-Turbo" },
  { label: "Ollama (local)", labelKey: "providerLabel.ollama", kind: "openai", baseUrl: "http://localhost:11434/v1", defaultModel: "llama3.1", note: "local runtime; apiKey can be any string", noteKey: "providerNote.ollama" },
  { label: "Anthropic (Claude)", kind: "anthropic", baseUrl: "https://api.anthropic.com/v1", defaultModel: "claude-sonnet-4-6" },
  { label: "Custom (OpenAI-compatible)", labelKey: "providerLabel.custom", kind: "openai", baseUrl: "", defaultModel: "", note: "any provider exposing /chat/completions", noteKey: "providerNote.custom" },
];

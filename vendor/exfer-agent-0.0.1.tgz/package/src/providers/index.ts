// Provider layer — implemented on the Vercel AI SDK (v6).
//
// One unified `LLMProvider.stream()` over `streamText().fullStream`, for both
// the openai-compatible wire format (DeepSeek, OpenRouter, Groq, Ollama, … —
// anything exposing /chat/completions) and Anthropic. Tools are passed WITHOUT
// an `execute` fn so the SDK surfaces each tool call back to `AgentSession`,
// which applies the consent policy before the host executes it. The host
// injects a custom `fetch` (Tauri HTTP) to bypass webview CORS.

import { streamText, tool, jsonSchema } from "ai";
import type { ModelMessage, LanguageModel, ToolSet } from "ai";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { createAnthropic } from "@ai-sdk/anthropic";
import type {
  ChatMessage,
  FetchLike,
  LLMProvider,
  ProviderConfig,
  ProviderKind,
  StreamEvent,
  StreamParams,
  ToolDef,
} from "../types.ts";

function buildModel(cfg: ProviderConfig, fetchImpl: FetchLike): LanguageModel {
  if (cfg.kind === "anthropic") {
    const anthropic = createAnthropic({
      apiKey: cfg.apiKey,
      baseURL: cfg.baseUrl || undefined,
      fetch: fetchImpl,
    });
    return anthropic(cfg.model);
  }
  const provider = createOpenAICompatible({
    name: cfg.id || "user-endpoint",
    baseURL: cfg.baseUrl,
    apiKey: cfg.apiKey,
    fetch: fetchImpl,
  });
  return provider(cfg.model);
}

function toModelMessages(msgs: ChatMessage[]): ModelMessage[] {
  return msgs.map((m): ModelMessage => {
    if (m.role === "user") {
      return { role: "user", content: m.content };
    }
    if (m.role === "assistant") {
      const parts: Array<
        { type: "text"; text: string } | { type: "tool-call"; toolCallId: string; toolName: string; input: unknown }
      > = [];
      if (m.content) parts.push({ type: "text", text: m.content });
      for (const c of m.toolCalls ?? []) {
        parts.push({ type: "tool-call", toolCallId: c.id, toolName: c.name, input: c.args });
      }
      return { role: "assistant", content: parts };
    }
    // tool result
    return {
      role: "tool",
      content: [
        { type: "tool-result", toolCallId: m.toolCallId, toolName: m.name, output: { type: "text", value: m.content } },
      ],
    };
  });
}

// Permissive output schema: tool results come back as arbitrary JSON/text from
// exfer-mcp, so we don't constrain them.
const ANY_OUTPUT = jsonSchema<unknown>({});

function toAiTools(tools?: ToolDef[]): ToolSet | undefined {
  if (!tools?.length) return undefined;
  const out: ToolSet = {};
  for (const t of tools) {
    // No `execute`: streamText emits the tool-call and stops the step, so
    // AgentSession can consent-gate and run it via the injected executeTool.
    // v6 requires an `outputSchema` on a no-execute (app-side) tool.
    out[t.name] = tool({
      description: t.description,
      inputSchema: jsonSchema(t.parameters as Record<string, unknown>),
      outputSchema: ANY_OUTPUT,
    });
  }
  return out;
}

function mapFinish(r: string): "end_turn" | "tool_use" | "max_tokens" | "refusal" | "other" {
  switch (r) {
    case "stop":
      return "end_turn";
    case "tool-calls":
      return "tool_use";
    case "length":
      return "max_tokens";
    case "content-filter":
      return "refusal";
    default:
      return "other";
  }
}

// DeepSeek's `deepseek-chat` intermittently emits its tool calls as PLAIN TEXT in
// an Anthropic-style XML markup (fullwidth ｜ = U+FF5C separators) instead of the
// OpenAI `tool_calls` field. The AI SDK then never surfaces them as tool-call
// parts, the turn ends with no executed call, and a whole research run dies with
// no answer (observed in ~half of multi-step runs). We detect that markup and
// recover the intended calls. Shape:
//   <｜｜DSML｜｜tool_calls>
//     <｜｜DSML｜｜invoke name="TOOL">
//       <｜｜DSML｜｜parameter name="p" string="true">VALUE</｜｜DSML｜｜parameter>
//     </｜｜DSML｜｜invoke>
//   </｜｜DSML｜｜tool_calls>
const DSML_PREFIX = "<｜｜DSML｜｜";
const DSML_OPEN = `${DSML_PREFIX}tool_calls>`;

function coerceArg(raw: string): unknown {
  const v = raw.trim();
  try {
    return JSON.parse(v); // numbers/bools/objects; a URL/address/query throws → stays a string
  } catch {
    return v;
  }
}

/** Recover tool calls DeepSeek leaked as DSML text markup. Returns [] if none.
 *  Exported for unit testing the recovery regex. */
export function parseDsmlToolCalls(text: string): Array<{ name: string; args: Record<string, unknown> }> {
  const calls: Array<{ name: string; args: Record<string, unknown> }> = [];
  const invokeRe = /<｜｜DSML｜｜invoke name="([^"]+)">([\s\S]*?)<\/｜｜DSML｜｜invoke>/g;
  let m: RegExpExecArray | null;
  while ((m = invokeRe.exec(text)) !== null) {
    const args: Record<string, unknown> = {};
    const paramRe = /<｜｜DSML｜｜parameter name="([^"]+)"[^>]*>([\s\S]*?)<\/｜｜DSML｜｜parameter>/g;
    let p: RegExpExecArray | null;
    while ((p = paramRe.exec(m[2])) !== null) {
      args[p[1]] = coerceArg(p[2]);
    }
    calls.push({ name: m[1], args });
  }
  return calls;
}

function errMsg(e: unknown): string {
  if (e instanceof Error) return e.message;
  if (typeof e === "string") return e;
  try {
    return JSON.stringify(e);
  } catch {
    return String(e);
  }
}

export function createProvider(cfg: ProviderConfig, fetchImpl: FetchLike = fetch): LLMProvider {
  return {
    kind: cfg.kind,
    async *stream(params: StreamParams): AsyncIterable<StreamEvent> {
      let result: ReturnType<typeof streamText>;
      try {
        result = streamText({
          model: buildModel(cfg, fetchImpl),
          system: params.system,
          messages: toModelMessages(params.messages),
          tools: toAiTools(params.tools),
          maxOutputTokens: params.maxTokens,
          abortSignal: params.signal,
        });
      } catch (e) {
        yield { type: "error", message: errMsg(e) };
        return;
      }

      // Buffer assistant text so we can recover DeepSeek's leaked-as-text tool
      // calls (see parseDsmlToolCalls). Clean text still streams live; once the
      // DSML marker appears we stop emitting and hold the rest for the finish.
      let full = "";
      let emitted = 0;
      let suppress = false;
      let sawStructuredCall = false;
      let dsmlSeq = 0;

      try {
        for await (const part of result.fullStream) {
          switch (part.type) {
            case "reasoning-delta":
              yield { type: "thinking_delta", text: part.text };
              break;
            case "text-delta": {
              full += part.text;
              if (suppress) break;
              const mi = full.indexOf(DSML_PREFIX);
              if (mi >= 0) {
                suppress = true;
                if (mi > emitted) yield { type: "text_delta", text: full.slice(emitted, mi) };
                emitted = full.length; // drop the marker + everything after it
              } else {
                // Hold back a tail that could be a partial marker split across deltas.
                const safe = full.length - DSML_PREFIX.length;
                if (safe > emitted) {
                  yield { type: "text_delta", text: full.slice(emitted, safe) };
                  emitted = safe;
                }
              }
              break;
            }
            case "tool-call":
              sawStructuredCall = true;
              yield {
                type: "tool_call",
                call: {
                  id: part.toolCallId,
                  name: part.toolName,
                  args: (part.input ?? {}) as Record<string, unknown>,
                },
              };
              break;
            case "finish": {
              const usage = { inputTokens: part.totalUsage?.inputTokens, outputTokens: part.totalUsage?.outputTokens };
              // Recover DeepSeek tool calls leaked as text → keep the loop alive.
              if (!sawStructuredCall && full.includes(DSML_OPEN)) {
                const calls = parseDsmlToolCalls(full);
                if (calls.length) {
                  for (const c of calls) {
                    dsmlSeq += 1;
                    yield { type: "tool_call", call: { id: `dsml_${dsmlSeq}`, name: c.name, args: c.args } };
                  }
                  yield { type: "done", stopReason: "tool_use", usage };
                  break;
                }
              }
              if (!suppress && emitted < full.length) yield { type: "text_delta", text: full.slice(emitted) };
              yield { type: "done", stopReason: mapFinish(part.finishReason), usage };
              break;
            }
            case "error":
              yield { type: "error", message: errMsg(part.error) };
              return;
          }
        }
      } catch (e) {
        yield { type: "error", message: errMsg(e) };
      }
    },
  };
}

/**
 * Presets to seed the config UI. `kind` picks the wire format; the user supplies
 * their own apiKey (and may override baseUrl/model). The openai-compatible kind
 * covers the long tail — anything exposing /chat/completions.
 */
export interface ProviderPreset {
  /** English label; always present as a fallback. */
  label: string;
  /** Stable token the host resolves via its own t() (falling back to `label`).
   *  Only set where the label is non-proper-noun prose that needs translating
   *  (e.g. "Ollama (local)" → "Ollama（本地）"); brand names omit it. */
  labelKey?: string;
  kind: ProviderKind;
  baseUrl: string;
  defaultModel: string;
  /** English note; always present as a fallback. */
  note?: string;
  /** Stable token the host resolves via its own t() (falling back to `note`).
   *  Core only emits the key; per-app i18n owns the ZH string. */
  noteKey?: string;
  /** Where the user gets an API key for this provider — for a "get a key ↗"
   *  link in the settings UI. Omitted for local runtimes (no key). */
  keyUrl?: string;
}

export const PROVIDER_PRESETS: ProviderPreset[] = [
  { label: "DeepSeek", kind: "openai", baseUrl: "https://api.deepseek.com", defaultModel: "deepseek-chat", keyUrl: "https://platform.deepseek.com/api_keys" },
  { label: "OpenAI", kind: "openai", baseUrl: "https://api.openai.com/v1", defaultModel: "gpt-4o", keyUrl: "https://platform.openai.com/api-keys" },
  { label: "OpenRouter", kind: "openai", baseUrl: "https://openrouter.ai/api/v1", defaultModel: "anthropic/claude-sonnet-4.6", keyUrl: "https://openrouter.ai/keys" },
  { label: "Groq", kind: "openai", baseUrl: "https://api.groq.com/openai/v1", defaultModel: "llama-3.3-70b-versatile", keyUrl: "https://console.groq.com/keys" },
  { label: "Together", kind: "openai", baseUrl: "https://api.together.xyz/v1", defaultModel: "meta-llama/Llama-3.3-70B-Instruct-Turbo", keyUrl: "https://api.together.xyz/settings/api-keys" },
  { label: "Ollama (local)", labelKey: "providerLabel.ollama", kind: "openai", baseUrl: "http://localhost:11434/v1", defaultModel: "llama3.1", note: "local runtime; apiKey can be any string", noteKey: "providerNote.ollama" },
  { label: "Anthropic (Claude)", kind: "anthropic", baseUrl: "https://api.anthropic.com/v1", defaultModel: "claude-sonnet-4-6", keyUrl: "https://console.anthropic.com/settings/keys" },
  { label: "Custom (OpenAI-compatible)", labelKey: "providerLabel.custom", kind: "openai", baseUrl: "", defaultModel: "", note: "any provider exposing /chat/completions", noteKey: "providerNote.custom" },
];

// A tiny, dependency-free, XSS-safe Markdown parser shared by the wallet apps.
//
// LLM chat output is markdown-shaped (DeepSeek/Claude lean on **bold**, lists,
// `code`, and especially tables for balances/quotes). The apps render the
// streamed text, so we need a parser that:
//   - is safe BY CONSTRUCTION: it never emits raw HTML. Every run of source is
//     either matched as a known construct or carried as plain text, and link
//     hrefs are scheme-allowlisted (http/https/mailto). There is no HTML
//     passthrough to sanitize.
//   - is stream-safe: half-arrived input must not flash garbage. An unterminated
//     code fence is auto-closed; a table is only promoted once its `|---|`
//     separator row has arrived (until then its lines render as paragraphs).
//   - returns a plain data AST (no React/DOM) so the headless core stays
//     portable and each front-end renders the nodes in its own design system.
//
// Scope is deliberately small (the subset an agent actually emits): ATX
// headings, fenced code blocks, unordered/ordered lists, GFM pipe tables,
// paragraphs; inline bold/italic/code/links. No nested lists, no blockquotes,
// no images — add them only if real output needs them.

export type MdInline =
  | { t: "text"; v: string }
  | { t: "strong"; c: MdInline[] }
  | { t: "em"; c: MdInline[] }
  | { t: "code"; v: string }
  | { t: "link"; href: string; c: MdInline[] };

export type MdAlign = "left" | "center" | "right" | null;

export type MdBlock =
  | { t: "p"; c: MdInline[] }
  | { t: "h"; level: number; c: MdInline[] }
  | { t: "ul"; items: MdInline[][] }
  | { t: "ol"; start: number; items: MdInline[][] }
  | { t: "code"; lang: string | null; v: string }
  | { t: "table"; header: MdInline[][]; align: MdAlign[]; rows: MdInline[][][] }
  | { t: "quote"; c: MdInline[] }
  | { t: "hr" };

/** Only these link schemes are allowed to become anchors; anything else (e.g.
 *  javascript:, data:) is rendered as inert text. Relative/anchor-less hrefs are
 *  rejected too — an agent has no business deep-linking inside the wallet. */
function safeHref(raw: string): string | null {
  const href = raw.trim();
  if (/^(https?:|mailto:)/i.test(href)) return href;
  return null;
}

// ── inline ──────────────────────────────────────────────────────────────────

/** Parse inline markdown within a single block of text. Unmatched markers are
 *  emitted literally, so a lone `*` or half-typed `[link` never disappears. */
export function parseInline(src: string): MdInline[] {
  const out: MdInline[] = [];
  let buf = "";
  const flush = () => {
    if (buf) out.push({ t: "text", v: buf });
    buf = "";
  };
  let i = 0;
  while (i < src.length) {
    const ch = src[i];

    // inline code: `...` (no nesting). A run of N backticks closes on the next
    // run of exactly N backticks.
    if (ch === "`") {
      let ticks = 0;
      while (src[i + ticks] === "`") ticks++;
      const fence = "`".repeat(ticks);
      const end = src.indexOf(fence, i + ticks);
      if (end !== -1) {
        flush();
        out.push({ t: "code", v: src.slice(i + ticks, end) });
        i = end + ticks;
        continue;
      }
    }

    // links: [text](href)
    if (ch === "[") {
      const close = src.indexOf("]", i + 1);
      if (close !== -1 && src[close + 1] === "(") {
        const end = src.indexOf(")", close + 2);
        if (end !== -1) {
          const href = safeHref(src.slice(close + 2, end));
          const label = src.slice(i + 1, close);
          if (href) {
            flush();
            out.push({ t: "link", href, c: parseInline(label) });
            i = end + 1;
            continue;
          }
        }
      }
    }

    // strong: **...** or __...__
    if ((ch === "*" || ch === "_") && src[i + 1] === ch) {
      const marker = ch + ch;
      const end = src.indexOf(marker, i + 2);
      if (end !== -1 && end > i + 2) {
        flush();
        out.push({ t: "strong", c: parseInline(src.slice(i + 2, end)) });
        i = end + 2;
        continue;
      }
    }

    // emphasis: *...* or _..._ (single marker). Require a non-space right after
    // the opener so "a * b" and mid-word underscores stay literal.
    if ((ch === "*" || ch === "_") && src[i + 1] && src[i + 1] !== ch && src[i + 1] !== " ") {
      const end = src.indexOf(ch, i + 1);
      if (end !== -1 && src[end - 1] !== " ") {
        flush();
        out.push({ t: "em", c: parseInline(src.slice(i + 1, end)) });
        i = end + 1;
        continue;
      }
    }

    buf += ch;
    i++;
  }
  flush();
  return out;
}

// ── tables ──────────────────────────────────────────────────────────────────

function splitRow(line: string): string[] {
  let s = line.trim();
  if (s.startsWith("|")) s = s.slice(1);
  if (s.endsWith("|")) s = s.slice(0, -1);
  // Split on unescaped pipes.
  const cells: string[] = [];
  let cur = "";
  for (let i = 0; i < s.length; i++) {
    if (s[i] === "\\" && s[i + 1] === "|") {
      cur += "|";
      i++;
    } else if (s[i] === "|") {
      cells.push(cur);
      cur = "";
    } else {
      cur += s[i];
    }
  }
  cells.push(cur);
  return cells.map((c) => c.trim());
}

/** A GFM alignment row: every cell is `:?-+:?` (e.g. `---`, `:--`, `:-:`). */
function parseAlignRow(line: string): MdAlign[] | null {
  if (!line.includes("-") || !line.includes("|")) return null;
  const cells = splitRow(line);
  const align: MdAlign[] = [];
  for (const c of cells) {
    if (!/^:?-+:?$/.test(c)) return null;
    const l = c.startsWith(":");
    const r = c.endsWith(":");
    align.push(l && r ? "center" : r ? "right" : l ? "left" : null);
  }
  return align;
}

// ── blocks ──────────────────────────────────────────────────────────────────

const ORDERED_RE = /^(\d+)[.)]\s+(.*)$/;
const UNORDERED_RE = /^[-*+]\s+(.*)$/;
const HEADING_RE = /^(#{1,6})\s+(.*)$/;
// Thematic break (horizontal rule): a line of 3+ of the SAME `-`, `*`, or `_`,
// optionally space-separated, and nothing else — e.g. `---`, `***`, `- - -`.
// A table's `| --- |` separator has pipes so it never matches (and is consumed
// by the table branch anyway).
const THEMATIC_RE = /^ {0,3}(?:-[ \t]*){3,}$|^ {0,3}(?:\*[ \t]*){3,}$|^ {0,3}(?:_[ \t]*){3,}$/;
const QUOTE_RE = /^ {0,3}>\s?(.*)$/;

/** Parse a full markdown document into a block AST. */
export function parseMarkdown(src: string): MdBlock[] {
  const lines = src.replace(/\r\n?/g, "\n").split("\n");
  const blocks: MdBlock[] = [];
  let i = 0;
  let para: string[] = [];

  const flushPara = () => {
    if (!para.length) return;
    blocks.push({ t: "p", c: parseInline(para.join(" ").trim()) });
    para = [];
  };

  while (i < lines.length) {
    const line = lines[i];

    // blank line → paragraph break
    if (!line.trim()) {
      flushPara();
      i++;
      continue;
    }

    // fenced code: ``` or ~~~ (auto-closes at EOF for stream safety)
    const fence = line.match(/^\s*(```+|~~~+)\s*(.*)$/);
    if (fence) {
      flushPara();
      const marker = fence[1][0].repeat(3);
      const lang = fence[2].trim() || null;
      const body: string[] = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith(marker)) {
        body.push(lines[i]);
        i++;
      }
      if (i < lines.length) i++; // consume closing fence (if present)
      blocks.push({ t: "code", lang, v: body.join("\n") });
      continue;
    }

    // heading
    const h = line.match(HEADING_RE);
    if (h) {
      flushPara();
      blocks.push({ t: "h", level: h[1].length, c: parseInline(h[2].trim()) });
      i++;
      continue;
    }

    // thematic break (---, ***, ___) → horizontal rule (was rendered as a
    // literal "---" paragraph before this case existed).
    if (THEMATIC_RE.test(line)) {
      flushPara();
      blocks.push({ t: "hr" });
      i++;
      continue;
    }

    // blockquote: one or more consecutive `>` lines → a single quote block
    // (single-level; nested `>` are flattened). Was rendered as a literal "> ".
    if (QUOTE_RE.test(line)) {
      flushPara();
      const buf: string[] = [];
      while (i < lines.length && QUOTE_RE.test(lines[i])) {
        buf.push(lines[i].replace(QUOTE_RE, "$1"));
        i++;
      }
      blocks.push({ t: "quote", c: parseInline(buf.join(" ").trim()) });
      continue;
    }

    // table: a pipe row immediately followed by an alignment row
    if (line.includes("|") && i + 1 < lines.length) {
      const align = parseAlignRow(lines[i + 1]);
      if (align) {
        flushPara();
        const header = splitRow(line).map(parseInline);
        i += 2;
        const rows: MdInline[][][] = [];
        while (i < lines.length && lines[i].includes("|") && lines[i].trim()) {
          rows.push(splitRow(lines[i]).map(parseInline));
          i++;
        }
        blocks.push({ t: "table", header, align, rows });
        continue;
      }
    }

    // unordered list
    if (UNORDERED_RE.test(line)) {
      flushPara();
      const items: MdInline[][] = [];
      while (i < lines.length) {
        const m = lines[i].match(UNORDERED_RE);
        if (!m) break;
        items.push(parseInline(m[1].trim()));
        i++;
      }
      blocks.push({ t: "ul", items });
      continue;
    }

    // ordered list
    if (ORDERED_RE.test(line)) {
      flushPara();
      const startM = line.match(ORDERED_RE);
      const start = startM ? parseInt(startM[1], 10) : 1;
      const items: MdInline[][] = [];
      while (i < lines.length) {
        const m = lines[i].match(ORDERED_RE);
        if (!m) break;
        items.push(parseInline(m[2].trim()));
        i++;
      }
      blocks.push({ t: "ol", start: Number.isFinite(start) ? start : 1, items });
      continue;
    }

    // otherwise: accumulate into the current paragraph
    para.push(line.trim());
    i++;
  }
  flushPara();
  return blocks;
}

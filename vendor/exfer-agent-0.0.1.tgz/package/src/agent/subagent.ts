// Sub-agent support — a Claude-Code-style read-only research child.
//
// The parent loop injects ONE extra core tool, `spawn_research_agent`, into the
// provider tool list (alongside the host's listTools()). When the model calls
// it, the parent spawns a CHILD AgentSession that shares the same provider /
// model / tool source / policy, but with a strictly READ-ONLY toolset: only
// tools whose consent class is "auto" (no funds can move), and never the spawn
// tool itself (no recursion). The child runs to completion and its assistant
// text is returned to the parent as the tool result.
//
// MONEY SAFETY: because the child's toolset is filtered to auto-only, it can
// never reach a gated/earn tool and there is no consent bubbling in v1.

import type { ToolDef } from "../types.ts";

/** The synthetic tool name the parent intercepts. Not a real MCP tool. */
export const SPAWN_TOOL_NAME = "spawn_research_agent";

/** Injected into the provider tool list in addition to the host's listTools(). */
export const SPAWN_TOOL_DEF: ToolDef = {
  name: SPAWN_TOOL_NAME,
  description:
    "Spawn a focused read-only sub-agent to research/look up information and report back. Cannot move funds.",
  parameters: {
    type: "object",
    properties: {
      task: { type: "string" },
    },
    required: ["task"],
  },
};

/** System prompt the research child runs under. Read-only, report-back framing. */
export const RESEARCH_SYSTEM_PROMPT =
  "You are a focused, read-only research sub-agent for the exfer wallet. " +
  "Use only the read-only tools available to gather facts and look things up. " +
  "You cannot move funds, sign, or change any state. " +
  "Investigate the task you are given, then report a concise, factual summary of what you found. " +
  "Do not ask follow-up questions; work with what you have and conclude with your findings.";

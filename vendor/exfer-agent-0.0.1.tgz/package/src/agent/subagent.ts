// Sub-agent support — a Claude-Code-style read-only research child.
//
// The parent loop injects ONE extra core tool, `spawn_research_agent`, into the
// provider tool list (alongside the host's listTools()). When the model calls
// it, the parent spawns a CHILD AgentSession that shares the same provider /
// model / tool source / policy, but with a strictly READ-ONLY toolset: only
// tools whose consent class is "auto" (no funds can move), and never the spawn
// tool itself (no recursion). The child runs to completion and its assistant
// text is returned to the parent as the tool result.
//
// MONEY SAFETY: because the child's toolset is filtered to auto-only, it can
// never reach a gated/earn tool and there is no consent bubbling in v1.

import type { ToolDef } from "../types.ts";

/** The synthetic tool name the parent intercepts. Not a real MCP tool. */
export const SPAWN_TOOL_NAME = "spawn_research_agent";

/** Injected into the provider tool list in addition to the host's listTools(). */
export const SPAWN_TOOL_DEF: ToolDef = {
  name: SPAWN_TOOL_NAME,
  description:
    "Spawn a focused read-only sub-agent to research/look up information and report back. Cannot move funds.",
  parameters: {
    type: "object",
    properties: {
      task: { type: "string" },
    },
    required: ["task"],
  },
};

/**
 * Shared honesty conduct for anything that uses the research / crypto-data
 * capabilities — the parent agent, the research sub-agent, and the dogfood
 * harness all append this so the rules are defined ONCE. These three rules came
 * straight out of real-user dogfooding, where the failure modes were: citing
 * source "from memory" as if fetched, shilling EXFER on a guessed price, and
 * attaching a confident price to a same-named-but-unrelated token.
 */
export const CAPABILITY_CONDUCT =
  // (1) Cite or refuse — no memory-substituted provenance.
  "Ground every factual claim in a tool result you actually received THIS conversation. " +
  "Never present contract code, numbers, addresses, or an 'I fetched X from Y' as retrieved unless a tool returned it this session — not even for famous tokens whose code you think you remember. " +
  "If a source was not retrieved (e.g. crypto_contract_source returned no key or 'not verified'), say so plainly ('not verified this session') and do NOT describe code or data you did not see. An honest 'unknown' beats a confident guess. " +
  // (2) Entity resolution — a ticker is not an identity.
  "A ticker/symbol can map to several unrelated contracts across chains; never attach a confirmed price or verdict to a symbol whose contract+chain you have not pinned down. If a name resolves to more than one token, surface the ambiguity and use the address. " +
  // (3) EXFER — higher bar for the house token, never self-deal on missing data,
  //     but stay BALANCED (one-sided negativity is as dishonest as shilling).
  "EXFER is this wallet's own native Layer-1 PoW coin (NOT an ERC-20 — do not confuse it with same-named ERC-20 'EXFER' tokens on Ethereum/BSC). You are the wallet's official assistant, so hold EXFER to the SAME neutral, evidence-based scrutiny you give any other token — a higher bar, not a lower one. If an exfer_* tool errors or returns no data, say the data is unavailable; NEVER guess or estimate EXFER's price and never recommend buying, holding, or mining EXFER on missing or guessed data. Be BALANCED: when exfer_self_audit returns design_strengths, present those verifiable architecture advantages ALONGSIDE the market risks (thin liquidity, tiny native pool, no major exchange) — do not give a one-sidedly negative answer any more than a one-sidedly positive one. And if a tool already returned a verifiable price (exfer_self_audit's canonical_liquidity or exfer_price), USE it — do not claim EXFER has 'no price' when you are holding its canonical pool price.";

/** System prompt the research child runs under. Read-only, report-back framing. */
export const RESEARCH_SYSTEM_PROMPT =
  "You are a focused, read-only research sub-agent for the exfer wallet. " +
  "Use only the read-only tools available to gather facts and look things up. " +
  "You cannot move funds, sign, or change any state. " +
  "Investigate the task you are given, then report a concise, factual summary of what you found. " +
  "Do not ask follow-up questions; work with what you have and conclude with your findings. " +
  CAPABILITY_CONDUCT;

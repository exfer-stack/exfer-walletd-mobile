// The agent loop — the heart of the exfer agent abstraction.
//
// Drives one user turn to completion: stream the LLM, surface thinking/text,
// and on each tool call enforce the consent policy before executing. Every
// external effect is injected, so the same loop runs unchanged in desktop,
// mobile, or a test (mock LLM + mock tools).

import type { ChatMessage, LLMProvider, ToolCall, ToolDef } from "../types.ts";
import { consentCardFor, consentClassFor, type ToolPolicy } from "../tools/policy.ts";
import type { AgentEvent, ConsentRequest } from "./events.ts";
import { RESEARCH_SYSTEM_PROMPT, SPAWN_TOOL_DEF, SPAWN_TOOL_NAME } from "./subagent.ts";

export interface AgentToolResult {
  content: string;
  isError?: boolean;
}

// The UI renders tool_result.summary: it humanizes by JSON.parse-ing the full
// result, so the summary must hold the WHOLE payload (a tighter cap truncates
// rich tools like exfer_network_status / exfer_earn_pool_stats mid-JSON, which
// fails the parse and dumps raw text). The LLM gets the untruncated content via
// history regardless; this only bounds a pathologically large event.
const SUMMARY_MAX = 8192;

/** Everything the loop needs from the host app, injected at construction. */
export interface AgentDeps {
  provider: LLMProvider;
  model: string;
  /** Tool schemas, fetched from exfer-mcp by the host. */
  listTools(): Promise<ToolDef[]>;
  /** Run a tool (host wires this to exfer-mcp / walletd). */
  executeTool(name: string, args: Record<string, unknown>): Promise<AgentToolResult>;
  /**
   * Ask the user to approve a gated action. Host implements with biometric
   * (mobile) / passphrase / OS auth (desktop). Resolves true = approved.
   */
  requestConsent(req: ConsentRequest): Promise<boolean>;
  systemPrompt?: string;
  /** Safety cap on tool-call rounds per user turn. */
  maxToolRounds?: number;
  maxTokens?: number;
  /** Consent policy across all mounted tool sources (MCP servers / skills). The
   *  host merges per-source policies into one; defaults to the exfer policy
   *  (fail-closed) when omitted. */
  policy?: ToolPolicy;
  /** Seed the conversation from a prior snapshot, so a rebuilt session resumes
   *  mid-conversation (multi-session UI, and surviving a lang/provider/MCP config
   *  change without losing history). Copied at construction; never mutated by ref. */
  initialMessages?: ChatMessage[];
}

/** Token usage for one turn plus the session running total. Provider-agnostic:
 *  any field a provider omits is `undefined`, and the cumulative simply skips it. */
export interface TurnUsage {
  inputTokens?: number;
  outputTokens?: number;
  totalTokens?: number;
}

let idCounter = 0;
function nextId(prefix: string): string {
  idCounter += 1;
  return `${prefix}_${idCounter}`;
}

/** Fold a provider's reported token counts into a running TurnUsage. Each field
 *  is summed independently and only when present, so a provider that omits one
 *  (or all) of them never zeroes out what other rounds reported. */
function addUsage(acc: TurnUsage, inputTokens?: number, outputTokens?: number): void {
  if (typeof inputTokens === "number") acc.inputTokens = (acc.inputTokens ?? 0) + inputTokens;
  if (typeof outputTokens === "number") acc.outputTokens = (acc.outputTokens ?? 0) + outputTokens;
  if (typeof inputTokens === "number" || typeof outputTokens === "number") {
    acc.totalTokens = (acc.inputTokens ?? 0) + (acc.outputTokens ?? 0);
  }
}

export class AgentSession {
  private readonly deps: AgentDeps;
  /** Seeded from deps.initialMessages (copied) so a rebuilt session resumes
   *  mid-conversation; thereafter only the loop appends to it (never reassigned). */
  private history: ChatMessage[];
  private toolsCache: ToolDef[] | null = null;
  /** Sub-agents are read-only and must NOT be able to spawn (no recursion). The
   *  parent flips this off when constructing a research child. */
  private readonly canSpawn: boolean;
  /** Session-cumulative token usage across all turns (best-effort; a provider
   *  that omits usage contributes nothing). */
  private readonly cumulativeUsage: TurnUsage = {};

  constructor(deps: AgentDeps, opts?: { canSpawn?: boolean }) {
    this.deps = deps;
    this.history = deps.initialMessages ? [...deps.initialMessages] : [];
    this.canSpawn = opts?.canSpawn ?? true;
  }

  /** Conversation so far (for persistence / display). */
  get messages(): readonly ChatMessage[] {
    return this.history;
  }

  /** A detached copy of the conversation, for persistence (rehydrate via
   *  AgentDeps.initialMessages on a rebuilt session). */
  get snapshot(): ChatMessage[] {
    return this.history.slice();
  }

  private async tools(): Promise<ToolDef[]> {
    if (!this.toolsCache) this.toolsCache = await this.deps.listTools();
    return this.toolsCache;
  }

  /**
   * Send a user message and stream the agent's response through to completion,
   * including any (consent-gated) tool calls. Yields UI events.
   */
  async *send(userText: string, signal?: AbortSignal): AsyncIterable<AgentEvent> {
    this.history.push({ role: "user", content: userText });
    // Offer the host's tools plus the built-in read-only sub-agent tool. The
    // spawn tool is core-injected; it is never part of listTools()/executeTool().
    // A research child has canSpawn=false, so it cannot recurse.
    const tools = this.canSpawn ? [...(await this.tools()), SPAWN_TOOL_DEF] : await this.tools();
    const maxRounds = this.deps.maxToolRounds ?? 8;
    // Per-turn usage accumulates across every provider round (a turn may stream
    // the model multiple times when tools are called). Provider-agnostic: a
    // provider that omits usage leaves these undefined.
    const turnUsage: TurnUsage = {};
    let toolCallCount = 0;

    for (let round = 0; round < maxRounds; round++) {
      let assistantText = "";
      const toolCalls: ToolCall[] = [];
      let stopReason = "other";

      const stream = this.deps.provider.stream({
        model: this.deps.model,
        system: this.deps.systemPrompt,
        messages: this.history,
        tools,
        maxTokens: this.deps.maxTokens,
        signal,
      });

      for await (const ev of stream) {
        switch (ev.type) {
          case "thinking_delta":
            yield { type: "thinking_delta", text: ev.text };
            break;
          case "text_delta":
            assistantText += ev.text;
            yield { type: "text_delta", text: ev.text };
            break;
          case "tool_call":
            toolCalls.push(ev.call);
            break;
          case "done":
            stopReason = ev.stopReason;
            if (ev.usage) {
              addUsage(turnUsage, ev.usage.inputTokens, ev.usage.outputTokens);
              addUsage(this.cumulativeUsage, ev.usage.inputTokens, ev.usage.outputTokens);
            }
            break;
          case "error":
            yield { type: "error", message: ev.message };
            return;
        }
      }

      // Record the assistant turn (text + any tool_use) before tool results.
      this.history.push({ role: "assistant", content: assistantText, toolCalls: toolCalls.length ? toolCalls : undefined });

      if (toolCalls.length === 0) {
        yield {
          type: "turn_done",
          stopReason,
          usage: { ...turnUsage },
          cumulativeUsage: { ...this.cumulativeUsage },
          toolCalls: toolCallCount,
        };
        return;
      }
      toolCallCount += toolCalls.length;

      // Execute each tool call, gating money-moving ones behind consent.
      for (const call of toolCalls) {
        // Built-in sub-agent: intercept BEFORE the consent gate. Spawning a
        // read-only research child is always auto (it can never move funds), so
        // it must never prompt. We still emit the normal tool_call_started /
        // tool_result for this call so the parent's block model stays consistent.
        if (call.name === SPAWN_TOOL_NAME) {
          yield { type: "tool_call_started", id: call.id, name: call.name, args: call.args, consentClass: "auto" };
          const summary = yield* this.runResearchChild(call, signal);
          yield { type: "tool_result", id: call.id, name: call.name, ok: true, summary: summary.slice(0, SUMMARY_MAX) };
          this.history.push({ role: "tool", toolCallId: call.id, name: call.name, content: summary });
          continue;
        }

        const cls = consentClassFor(call.name, this.deps.policy);

        // Consent gate FIRST for gated/earn — so nothing visibly "runs" before
        // the user approves (the tool card + spinner appear only at execution).
        if (cls === "gated" || cls === "earn") {
          const card = consentCardFor(call.name, call.args);
          const reqId = nextId("consent");
          yield { type: "consent_request", id: reqId, card };
          let approved = false;
          try {
            approved = await this.deps.requestConsent({ id: reqId, card });
          } catch {
            approved = false;
          }
          yield { type: "consent_resolved", id: reqId, approved };
          if (!approved) {
            yield { type: "tool_call_started", id: call.id, name: call.name, args: call.args, consentClass: cls };
            yield { type: "tool_result", id: call.id, name: call.name, ok: false, summary: "declined" };
            this.history.push({ role: "tool", toolCallId: call.id, name: call.name, content: "User declined this action.", isError: true });
            continue;
          }
        }

        // Approved (or an auto/read-only tool): now it is actually executing.
        yield { type: "tool_call_started", id: call.id, name: call.name, args: call.args, consentClass: cls };
        let result: AgentToolResult;
        try {
          result = await this.deps.executeTool(call.name, call.args);
        } catch (e) {
          result = { content: `Tool error: ${String(e)}`, isError: true };
        }
        yield {
          type: "tool_result",
          id: call.id,
          name: call.name,
          ok: !result.isError,
          summary: result.content.slice(0, SUMMARY_MAX),
        };
        this.history.push({ role: "tool", toolCallId: call.id, name: call.name, content: result.content, isError: result.isError });
      }
      // Loop: feed tool results back to the model for the next round.
    }

    // Tool-round budget exhausted. Don't fail with an error and no answer —
    // make ONE final call with NO tools so the model must synthesize a reply
    // from everything it already gathered (this is what a long research task
    // hits). The user gets a summary instead of "stopped after N rounds".
    {
      let assistantText = "";
      let stopReason = "end_turn";
      const stream = this.deps.provider.stream({
        model: this.deps.model,
        system: `${this.deps.systemPrompt}\n\nYou have reached your tool-use limit for this turn. Do NOT call any more tools. Answer now with your best summary from the information already gathered, and say plainly if something could not be confirmed.`,
        messages: this.history,
        tools: [],
        maxTokens: this.deps.maxTokens,
        signal,
      });
      for await (const ev of stream) {
        switch (ev.type) {
          case "thinking_delta":
            yield { type: "thinking_delta", text: ev.text };
            break;
          case "text_delta":
            assistantText += ev.text;
            yield { type: "text_delta", text: ev.text };
            break;
          case "done":
            stopReason = ev.stopReason;
            if (ev.usage) {
              addUsage(turnUsage, ev.usage.inputTokens, ev.usage.outputTokens);
              addUsage(this.cumulativeUsage, ev.usage.inputTokens, ev.usage.outputTokens);
            }
            break;
          case "error":
            yield { type: "error", message: ev.message };
            return;
        }
      }
      this.history.push({ role: "assistant", content: assistantText });
      yield {
        type: "turn_done",
        stopReason,
        usage: { ...turnUsage },
        cumulativeUsage: { ...this.cumulativeUsage },
        toolCalls: toolCallCount,
      };
    }
  }

  /**
   * Run a read-only research sub-agent for one `spawn_research_agent` call.
   *
   * Spawns a CHILD AgentSession sharing this session's provider / model / tool
   * source / policy, but with a READ-ONLY toolset (only auto-class tools, and
   * never the spawn tool itself — no recursion) and a research system prompt.
   * Drives it to completion, forwards each child AgentEvent wrapped in
   * `subagent_event`, and returns the child's accumulated assistant text so the
   * caller can record it as the parent tool result.
   */
  private async *runResearchChild(call: ToolCall, signal?: AbortSignal): AsyncGenerator<AgentEvent, string> {
    const task = typeof call.args.task === "string" ? call.args.task : String(call.args.task ?? "");
    const childId = nextId("subagent");
    yield { type: "subagent_started", id: childId, task };

    const policy = this.deps.policy;
    const child = new AgentSession({
      provider: this.deps.provider,
      model: this.deps.model,
      // READ-ONLY: only auto-class tools survive, and the spawn tool is excluded
      // (the child's send() would re-add SPAWN_TOOL_DEF, but consentClassFor on
      // the parent list already keeps it out of the executable subset; the child
      // simply cannot reach a gated tool because none are offered to it).
      listTools: async () => {
        const all = await this.deps.listTools();
        return all.filter(
          (t) => t.name !== SPAWN_TOOL_NAME && consentClassFor(t.name, policy) === "auto",
        );
      },
      executeTool: this.deps.executeTool,
      // The child has no gated tools, so consent is never reached. A defensive
      // deny keeps the money-safety invariant even if a tool slipped through.
      requestConsent: async () => false,
      systemPrompt: RESEARCH_SYSTEM_PROMPT,
      maxToolRounds: 6,
      maxTokens: this.deps.maxTokens,
      policy,
    }, { canSpawn: false });

    let summary = "";
    for await (const ev of child.send(task, signal)) {
      if (ev.type === "text_delta") summary += ev.text;
      yield { type: "subagent_event", id: childId, event: ev };
    }

    yield { type: "subagent_done", id: childId, summary };
    return summary;
  }
}

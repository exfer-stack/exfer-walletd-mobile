// UI-facing event stream the agent loop emits for one user turn.
//
// Distinct from the provider-level `StreamEvent`: these carry the consent gate
// and tool lifecycle the wallet UI renders (thinking, tool-call cards, the
// approval card, results). The desktop/mobile apps render these; they never
// talk to the LLM directly.

import type { ConsentCard, ConsentClass } from "../tools/policy.ts";
import type { TurnUsage } from "./session.ts";

export type AgentEvent =
  | { type: "thinking_delta"; text: string }
  | { type: "text_delta"; text: string }
  | { type: "tool_call_started"; id: string; name: string; args: Record<string, unknown>; consentClass: ConsentClass }
  | { type: "consent_request"; id: string; card: ConsentCard }
  | { type: "consent_resolved"; id: string; approved: boolean }
  | { type: "tool_result"; id: string; name: string; ok: boolean; summary: string }
  // Sub-agent lifecycle: a read-only research child the parent spawns via the
  // built-in `spawn_research_agent` tool. The child runs to completion inside
  // the parent's turn; each of its own AgentEvents is forwarded wrapped in
  // `subagent_event` so a UI can render a nested transcript.
  | { type: "subagent_started"; id: string; task: string }
  | { type: "subagent_event"; id: string; event: AgentEvent }
  | { type: "subagent_done"; id: string; summary: string }
  // `usage` = tokens for THIS turn; `cumulativeUsage` = session running total;
  // `toolCalls` = how many tools ran this turn. All best-effort: a provider that
  // omits token counts leaves the usage fields undefined. Lets a UI render a
  // compact "N tok · M tools · Xs" footer.
  | { type: "turn_done"; stopReason: string; usage?: TurnUsage; cumulativeUsage?: TurnUsage; toolCalls?: number }
  | { type: "error"; message: string };

/** What the app's consent prompt receives and must resolve to a boolean. */
export interface ConsentRequest {
  id: string;
  card: ConsentCard;
}

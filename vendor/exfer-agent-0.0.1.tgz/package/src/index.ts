// exfer-agent — portable, headless agent core shared by the exfer wallet apps
// (desktop, mobile). The host injects fetch, a tool source (exfer-mcp), a tool
// executor, and a consent prompt; the core runs the LLM ⇄ tools ⇄ consent loop
// and emits UI events. No React, no Tauri, no Node — pure TS over web `fetch`.

export type {
  ChatMessage,
  FetchLike,
  LLMProvider,
  ProviderConfig,
  ProviderKind,
  StreamEvent,
  StreamParams,
  ToolCall,
  ToolDef,
  Usage,
} from "./types.ts";

export { createProvider, PROVIDER_PRESETS } from "./providers/index.ts";
export type { ProviderPreset } from "./providers/index.ts";

export { consentClassFor, consentCardFor, mergePolicies, EXFER_POLICY } from "./tools/policy.ts";
export type { ConsentClass, ConsentCard, ConsentField, ConsentFieldKind, ToolPolicy } from "./tools/policy.ts";

export { AgentSession } from "./agent/session.ts";
export type { AgentDeps, AgentToolResult } from "./agent/session.ts";
export type { AgentEvent, ConsentRequest } from "./agent/events.ts";
export { SPAWN_TOOL_DEF, SPAWN_TOOL_NAME, RESEARCH_SYSTEM_PROMPT, CAPABILITY_CONDUCT } from "./agent/subagent.ts";

export { parseMarkdown, parseInline } from "./markdown.ts";
export type { MdBlock, MdInline, MdAlign } from "./markdown.ts";

export { capabilityTools, CAPABILITY_NAMES } from "./capabilities/index.ts";
export type { HostBridge, SearchConfig, CapabilityOpts } from "./capabilities/index.ts";

export { walletTools, WALLET_NAMES } from "./wallet-tools/index.ts";

# exfer-agent

Portable, headless **agent core** shared by the exfer wallet apps (desktop and
mobile). One implementation so the in-wallet AI agent is identical everywhere —
same conversation, same LLM config, same consent model.

It is **headless**: no React, no Tauri, no Node — pure TypeScript over the web
`fetch` API. Every external effect is injected by the host app, so the same loop
runs unchanged in desktop, mobile, or a unit test.

## What's in it

- **Bring-your-own-LLM adapters** — a unified `LLMProvider` over the
  **Vercel AI SDK 6** (`@ai-sdk/openai-compatible` + `@ai-sdk/anthropic`): the
  `openai` kind covers OpenAI, OpenRouter, Groq, DeepSeek, Together, Ollama /
  LM Studio / vLLM, … (anything exposing `/chat/completions`) and `anthropic`
  covers Claude. Users configure `baseUrl + apiKey + model`; a custom `fetch`
  is injectable (Tauri HTTP, to bypass webview CORS).
- **The agent loop** (`AgentSession`) — drives one user turn to completion:
  streams the LLM, surfaces thinking/text, and on each tool call enforces the
  consent policy before executing. Emits a typed `AgentEvent` stream the UI
  renders.
- **Consent policy** — classifies the exfer-mcp tools `auto` / `gated` / `earn`.
  Money-moving and signing tools (`exfer_transfer`, `exfer_swap_execute`,
  `exfer_quote_issue`, …) are **gated**: the loop pauses and asks the host to
  confirm (biometric on mobile, passphrase / OS auth on desktop) before they
  run. Unknown tools fail closed (gated).

## The boundary (host injects)

```ts
const session = new AgentSession({
  provider,                 // createProvider(config, fetchImpl)
  model,
  listTools,                // () => ToolDef[]              from exfer-mcp
  executeTool,              // (name, args) => result       to exfer-mcp / walletd
  requestConsent,           // (req) => Promise<boolean>    biometric / passphrase
  systemPrompt,
});

for await (const ev of session.send("swap 0.1 BNB for EXFER")) {
  // ev: thinking_delta | text_delta | tool_call_started | consent_request
  //   | consent_resolved | tool_result | turn_done | error
}
```

The host provides: a `fetch` (Tauri HTTP to skip browser CORS), the exfer-mcp
tool source + executor, the platform consent prompt, and the UI that renders the
event stream. The core decides *which tool, gated or not, what to stream* — the
host decides *how to prompt, how to execute, what it looks like*.

## Develop

```sh
npm install
npm run typecheck
npm test          # node-native TS test runner, mock LLM + mock tools
npm run build     # tsup → dist/ (esm + d.ts)
```

Status: **v0 core** — provider (AI SDK 6) + loop + consent policy. Unit-tested
with a mock LLM, and verified live against a real DeepSeek endpoint: a plain
streamed answer (`examples/llm-smoke.ts`) and the full consent-gated tool loop
where a real model's `exfer_transfer` call pauses for approval before running
(`examples/agent-tool-smoke.ts`). exfer-mcp wiring and the desktop/mobile
assistant-ui integration are the next phases (see `docs/IMPLEMENTATION_SPEC.md`).
